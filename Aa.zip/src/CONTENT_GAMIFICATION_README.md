# 🎓📚 دليل نظام المحتوى التعليمي ونظام التحفيز - أكاديمية الذهب المالية

## 📋 جدول المحتويات
1. [نظام المحتوى التعليمي](#content-system)
2. [نظام التحفيز (Gamification)](#gamification-system)
3. [API Endpoints](#api-endpoints)
4. [أمثلة الاستخدام](#usage-examples)

---

## 🎬 نظام المحتوى التعليمي {#content-system}

### الميزات الرئيسية
- ✅ إدارة الفيديوهات التعليمية
- ✅ نظام اختبارات تفاعلي
- ✅ شهادات إلكترونية مع رموز تحقق
- ✅ نظام تقييمات ومشاهدات
- ✅ توصيات محتوى ذكية

### 🎥 الفيديوهات

#### هيكل البيانات
```typescript
interface Video {
  id: string;
  title: string;
  description: string;
  duration: number; // بالثواني
  category: 'تداول' | 'عقارات' | 'ريادة أعمال' | 'تخطيط مالي';
  level: 'مبتدئ' | 'متوسط' | 'متقدم';
  thumbnail: string;
  videoUrl: string;
  transcript?: string; // نص الفيديو
  resources: Array<{ title: string; url: string }>;
  owner: string;
  views: number;
  averageRating: number;
  ratings: Array<{ userId: string; value: number }>;
  isVerified: boolean;
  createdAt: string;
  updatedAt: string;
}
```

#### Endpoints للفيديوهات

**إنشاء فيديو جديد**
```http
POST /content/videos/create
Content-Type: application/json

{
  "title": "مقدمة في تداول الأسهم",
  "description": "تعلم أساسيات تداول الأسهم من الصفر",
  "duration": 1200,
  "category": "تداول",
  "level": "مبتدئ",
  "videoUrl": "https://cdn.example.com/video123.mp4",
  "owner": "user_123",
  "thumbnail": "https://cdn.example.com/thumb123.jpg",
  "transcript": "نص الفيديو...",
  "resources": [
    {
      "title": "دليل PDF للتداول",
      "url": "https://cdn.example.com/guide.pdf"
    }
  ]
}
```

**جلب فيديو**
```http
GET /content/videos/:videoId
```

**قائمة الفيديوهات مع الفلترة**
```http
GET /content/videos?category=تداول&level=مبتدئ
```

**تسجيل مشاهدة**
```http
POST /content/videos/:videoId/view
```

**تقييم فيديو**
```http
POST /content/videos/:videoId/rate
Content-Type: application/json

{
  "userId": "user_123",
  "rating": 5
}
```

---

### 📝 الاختبارات

#### هيكل البيانات
```typescript
interface Quiz {
  id: string;
  title: string;
  questions: Array<{
    id: string;
    text: string;
    options: string[];
    correctAnswer: number;
    explanation: string;
  }>;
  passingScore: number;
  timeLimit: number; // بالدقائق
  relatedVideoId?: string;
  category: string;
  level: string;
  createdAt: string;
}
```

#### Endpoints للاختبارات

**إنشاء اختبار**
```http
POST /content/quizzes/create
Content-Type: application/json

{
  "title": "اختبار التداول الأساسي",
  "questions": [
    {
      "text": "ما هو السهم؟",
      "options": [
        "حصة ملكية في شركة",
        "قرض للشركة",
        "سند حكومي",
        "عملة رقمية"
      ],
      "correctAnswer": 0,
      "explanation": "السهم هو حصة ملكية في شركة..."
    }
  ],
  "passingScore": 70,
  "timeLimit": 30,
  "relatedVideoId": "video_123",
  "category": "تداول",
  "level": "مبتدئ"
}
```

**بدء جلسة اختبار**
```http
POST /content/quizzes/:quizId/start
Content-Type: application/json

{
  "userId": "user_123"
}

Response:
{
  "id": "session_abc123",
  "userId": "user_123",
  "quizId": "quiz_xyz",
  "startTime": "2024-01-15T10:00:00Z",
  "endTime": "2024-01-15T10:30:00Z",
  "answers": [],
  "isCompleted": false
}
```

**تسجيل إجابة**
```http
POST /content/quizzes/sessions/:sessionId/answer
Content-Type: application/json

{
  "questionId": "q_1",
  "answer": 0
}
```

**إنهاء الاختبار**
```http
POST /content/quizzes/sessions/:sessionId/complete

Response:
{
  "score": 85,
  "passed": true,
  "correctAnswers": 17,
  "totalQuestions": 20,
  "certificate": {
    "id": "cert_xyz789",
    "verificationCode": "ABC123XYZ789",
    ...
  }
}
```

---

### 🏅 الشهادات

#### هيكل البيانات
```typescript
interface Certificate {
  id: string;
  userId: string;
  courseId: string;
  courseName: string;
  issueDate: string;
  expirationDate?: string;
  verificationCode: string;
  grade: number;
  nftMetadata?: {
    tokenId?: string;
    contractAddress?: string;
    explorerUrl?: string;
  };
}
```

#### Endpoints للشهادات

**جلب شهادات المستخدم**
```http
GET /content/certificates/:userId

Response:
{
  "certificates": [
    {
      "id": "cert_123",
      "userId": "user_123",
      "courseId": "quiz_xyz",
      "courseName": "اختبار التداول الأساسي",
      "issueDate": "2024-01-15T10:35:00Z",
      "expirationDate": "2025-01-15T10:35:00Z",
      "verificationCode": "ABC123XYZ789",
      "grade": 85
    }
  ]
}
```

**التحقق من شهادة**
```http
GET /content/certificates/verify/:code

Response:
{
  "valid": true,
  "certificate": {
    ...
  }
}
```

---

### 🎯 توصيات المحتوى

```http
GET /content/recommendations/:userId?limit=5

Response:
{
  "recommendations": [
    {
      "id": "video_456",
      "title": "استراتيجيات التداول المتقدمة",
      "category": "تداول",
      "level": "متوسط",
      "averageRating": 4.8,
      "views": 15423
    }
  ]
}
```

---

## 🎮 نظام التحفيز (Gamification) {#gamification-system}

### الميزات الرئيسية
- ✅ نظام XP (نقاط الخبرة) متعدد المصادر
- ✅ مستويات ديناميكية
- ✅ شارات الإنجاز
- ✅ لوحات الصدارة
- ✅ سلسلة الدخول اليومي
- ✅ حماية من التلاعب

### 💎 نظام XP

#### مصادر XP
```typescript
{
  daily_login: { base: 10, streakBonus: 5 },
  video_watch: { base: 20, completionBonus: 10 },
  quiz_complete: { base: 50, perfectBonus: 25 },
  content_creation: { base: 100, qualityMultiplier: 2 },
  trading: { base: 30, profitBased: true },
  real_estate: { base: 40, roiBased: true },
  decisions: { base: 25, accuracyBased: true },
  referral: { base: 100 },
  badge: { base: 0 }, // يأتي من الشارة نفسها
  event: { base: 0 }
}
```

#### حدود الأمان
```typescript
{
  MAX_XP_PER_HOUR: 1000,
  MAX_SAME_SOURCE_PER_HOUR: 10,
  SOURCE_COOLDOWN: 5 * 60 * 1000, // 5 دقائق
  FARMING_THRESHOLD: 20
}
```

#### Endpoints لنظام XP

**منح XP**
```http
POST /gamification/xp/grant
Content-Type: application/json

{
  "userId": "user_123",
  "source": "video_watch",
  "details": {
    "watchedPercentage": 100,
    "videoId": "video_456"
  }
}

Response:
{
  "success": true,
  "xpGained": 30,
  "newTotal": 1530
}
```

**تحديث سلسلة الدخول**
```http
POST /gamification/login/:userId

Response:
{
  "streak": 7,
  "xpGained": 45
}
```

**سجل XP**
```http
GET /gamification/xp/history/:userId?limit=20

Response:
{
  "history": [
    {
      "id": "xp_tx_123",
      "userId": "user_123",
      "amount": 30,
      "source": "video_watch",
      "sourceDetails": { "videoId": "video_456" },
      "timestamp": "2024-01-15T10:00:00Z"
    }
  ]
}
```

---

### 🏆 الشارات

#### الشارات الافتراضية
```javascript
[
  {
    name: 'المبتدئ',
    description: 'ابدأ رحلتك التعليمية',
    tier: 'bronze',
    xpReward: 50,
    criteria: { totalXP: 100 }
  },
  {
    name: 'المتعلم النشط',
    description: 'شاهد 10 فيديوهات',
    tier: 'silver',
    xpReward: 100,
    criteria: { videosWatched: 10 }
  },
  {
    name: 'خبير الاختبارات',
    description: 'أكمل 5 اختبارات بنجاح',
    tier: 'gold',
    xpReward: 200,
    criteria: { quizzesCompleted: 5 }
  },
  {
    name: 'المثابر',
    description: 'سجل دخول لمدة 7 أيام متتالية',
    tier: 'gold',
    xpReward: 250,
    criteria: { loginStreak: 7 }
  },
  {
    name: 'صانع المحتوى',
    description: 'أنشئ 5 محتويات تعليمية',
    tier: 'platinum',
    xpReward: 500,
    criteria: { contentCreated: 5 }
  },
  {
    name: 'المحترف',
    description: 'اجمع 5000 XP',
    tier: 'platinum',
    xpReward: 1000,
    criteria: { totalXP: 5000 }
  }
]
```

#### Endpoints للشارات

**إنشاء شارة**
```http
POST /gamification/badges/create
Content-Type: application/json

{
  "name": "ملك التداول",
  "description": "حقق 10 صفقات رابحة متتالية",
  "icon": "trading-king.png",
  "tier": "platinum",
  "xpReward": 500,
  "criteria": {
    "consecutiveWins": 10
  },
  "isSecret": false
}
```

**جلب جميع الشارات**
```http
GET /gamification/badges
```

**جلب شارات المستخدم**
```http
GET /gamification/badges/:userId

Response:
{
  "badges": [
    {
      "id": "badge_123",
      "name": "المبتدئ",
      "tier": "bronze",
      "xpReward": 50,
      ...
    }
  ]
}
```

**تهيئة الشارات الافتراضية**
```http
POST /gamification/init
```

---

### 📊 لوحات الصدارة

#### Endpoints

**تحديث لوحة الصدارة**
```http
POST /gamification/leaderboard/update/:period
// period: daily, weekly, monthly, all-time

Response:
{
  "id": "leaderboard_weekly_123",
  "period": "weekly",
  "startDate": "2024-01-15T00:00:00Z",
  "rankings": [
    {
      "userId": "user_456",
      "username": "أحمد_محمد",
      "score": 5420,
      "position": 1
    },
    {
      "userId": "user_789",
      "username": "سارة_علي",
      "score": 4850,
      "position": 2
    }
  ],
  "lastUpdated": "2024-01-15T12:00:00Z"
}
```

**جلب لوحة الصدارة**
```http
GET /gamification/leaderboard/:period
```

**جلب ترتيب المستخدم**
```http
GET /gamification/leaderboard/:period/position/:userId

Response:
{
  "position": 15,
  "totalUsers": 1234
}
```

---

### 👤 تقدم المستخدم

```http
GET /gamification/progress/:userId

Response:
{
  "userId": "user_123",
  "totalXP": 1530,
  "level": 4,
  "badges": ["badge_123", "badge_456"],
  "loginStreak": 7,
  "lastLoginDate": "2024-01-15T08:00:00Z",
  "stats": {
    "videosWatched": 15,
    "quizzesCompleted": 8,
    "certificatesEarned": 3,
    "contentCreated": 2,
    "tradingProfits": 1250,
    "referrals": 5
  },
  "updatedAt": "2024-01-15T12:30:00Z"
}
```

---

## 🔗 API Endpoints الكاملة {#api-endpoints}

### المحتوى التعليمي

| Method | Endpoint | الوصف |
|--------|----------|-------|
| POST | `/content/videos/create` | إنشاء فيديو |
| GET | `/content/videos/:videoId` | جلب فيديو |
| GET | `/content/videos` | قائمة الفيديوهات |
| POST | `/content/videos/:videoId/view` | تسجيل مشاهدة |
| POST | `/content/videos/:videoId/rate` | تقييم فيديو |
| POST | `/content/quizzes/create` | إنشاء اختبار |
| GET | `/content/quizzes/:quizId` | جلب اختبار |
| POST | `/content/quizzes/:quizId/start` | بدء جلسة اختبار |
| POST | `/content/quizzes/sessions/:sessionId/answer` | تسجيل إجابة |
| POST | `/content/quizzes/sessions/:sessionId/complete` | إنهاء اختبار |
| GET | `/content/certificates/:userId` | جلب شهادات المستخدم |
| GET | `/content/certificates/verify/:code` | التحقق من شهادة |
| GET | `/content/recommendations/:userId` | توصيات محتوى |

### التحفيز (Gamification)

| Method | Endpoint | الوصف |
|--------|----------|-------|
| GET | `/gamification/progress/:userId` | تقدم المستخدم |
| POST | `/gamification/xp/grant` | منح XP |
| POST | `/gamification/login/:userId` | تحديث سلسلة الدخول |
| GET | `/gamification/xp/history/:userId` | سجل XP |
| POST | `/gamification/badges/create` | إنشاء شارة |
| GET | `/gamification/badges` | جميع الشارات |
| GET | `/gamification/badges/:userId` | شارات المستخدم |
| POST | `/gamification/leaderboard/update/:period` | تحديث لوحة الصدارة |
| GET | `/gamification/leaderboard/:period` | جلب لوحة الصدارة |
| GET | `/gamification/leaderboard/:period/position/:userId` | ترتيب المستخدم |
| POST | `/gamification/init` | تهيئة الشارات الافتراضية |

---

## 💡 أمثلة الاستخدام {#usage-examples}

### مثال 1: رحلة مستخدم كاملة

```typescript
// 1. تسجيل الدخول اليومي
await fetch(`${API_URL}/gamification/login/user_123`, {
  method: 'POST'
});
// Response: { streak: 3, xpGained: 25 }

// 2. مشاهدة فيديو
const video = await fetch(`${API_URL}/content/videos/video_456`);
await fetch(`${API_URL}/content/videos/video_456/view`, {
  method: 'POST'
});

// 3. منح XP للمشاهدة الكاملة
await fetch(`${API_URL}/gamification/xp/grant`, {
  method: 'POST',
  body: JSON.stringify({
    userId: 'user_123',
    source: 'video_watch',
    details: { watchedPercentage: 100 }
  })
});
// Response: { success: true, xpGained: 30, newTotal: 1055 }

// 4. بدء اختبار
const session = await fetch(`${API_URL}/content/quizzes/quiz_789/start`, {
  method: 'POST',
  body: JSON.stringify({ userId: 'user_123' })
});

// 5. إجابة الأسئلة
for (const question of quiz.questions) {
  await fetch(`${API_URL}/content/quizzes/sessions/${session.id}/answer`, {
    method: 'POST',
    body: JSON.stringify({
      questionId: question.id,
      answer: userAnswers[question.id]
    })
  });
}

// 6. إنهاء الاختبار
const result = await fetch(
  `${API_URL}/content/quizzes/sessions/${session.id}/complete`,
  { method: 'POST' }
);
// Response: { score: 90, passed: true, certificate: {...} }

// 7. فحص الشارات المفتوحة تلقائياً
const progress = await fetch(`${API_URL}/gamification/progress/user_123`);
// قد يحتوي على شارات جديدة!
```

### مثال 2: إنشاء دورة تعليمية كاملة

```typescript
// 1. إنشاء فيديو
const video = await fetch(`${API_URL}/content/videos/create`, {
  method: 'POST',
  body: JSON.stringify({
    title: 'استراتيجيات التداول اليومي',
    description: 'تعلم كيف تتداول بشكل يومي بأمان',
    duration: 1800,
    category: 'تداول',
    level: 'متوسط',
    videoUrl: 'https://cdn.example.com/trading-course.mp4',
    owner: 'instructor_456',
    resources: [
      {
        title: 'ملف Excel لتتبع الصفقات',
        url: 'https://cdn.example.com/tracker.xlsx'
      }
    ]
  })
});

// 2. إنشاء اختبار مرتبط
const quiz = await fetch(`${API_URL}/content/quizzes/create`, {
  method: 'POST',
  body: JSON.stringify({
    title: 'اختبار التداول اليومي',
    questions: [
      {
        text: 'ما هي أفضل استراتيجية للتداول اليومي؟',
        options: [
          'شراء والاحتفاظ',
          'التداول بناءً على الأخبار',
          'التحليل الفني',
          'التداول العشوائي'
        ],
        correctAnswer: 2,
        explanation: 'التحليل الفني هو الأساس للتداول اليومي...'
      }
    ],
    passingScore: 70,
    timeLimit: 20,
    relatedVideoId: video.id,
    category: 'تداول',
    level: 'متوسط'
  })
});

// 3. منح XP للمدرس
await fetch(`${API_URL}/gamification/xp/grant`, {
  method: 'POST',
  body: JSON.stringify({
    userId: 'instructor_456',
    source: 'content_creation',
    details: { quality: 'gold', contentId: video.id }
  })
});
```

### مثال 3: نظام مكافآت التحفيز

```typescript
// إنشاء شارة مخصصة لحدث خاص
await fetch(`${API_URL}/gamification/badges/create`, {
  method: 'POST',
  body: JSON.stringify({
    name: 'نجم رمضان 2024',
    description: 'شارك في تحدي التعلم الرمضاني',
    icon: 'ramadan-star.png',
    tier: 'gold',
    xpReward: 500,
    criteria: {
      videosWatched: 30,
      quizzesCompleted: 10,
      loginStreak: 20
    },
    isSecret: false
  })
});

// تحديث لوحة الصدارة الأسبوعية
await fetch(`${API_URL}/gamification/leaderboard/update/weekly`, {
  method: 'POST'
});

// جلب المتصدرين
const leaderboard = await fetch(
  `${API_URL}/gamification/leaderboard/weekly`
);

// التحقق من ترتيب مستخدم معين
const position = await fetch(
  `${API_URL}/gamification/leaderboard/weekly/position/user_123`
);
// Response: { position: 8, totalUsers: 1500 }
```

---

## 🛡️ الأمان والحماية

### حماية نظام XP
```typescript
// الحدود الزمنية
MAX_XP_PER_HOUR: 1000 // أقصى XP في الساعة

// الحدود لكل مصدر
MAX_SAME_SOURCE_PER_HOUR: 10 // أقصى 10 نشاطات من نفس المصدر

// فترة التهدئة
SOURCE_COOLDOWN: 5 * 60 * 1000 // 5 دقائق بين الأنشطة

// كشف التصيد
FARMING_THRESHOLD: 20 // كشف الأنماط المشبوهة
```

### آلية كشف التلاعب
- ✅ تتبع IP للمستخدمين
- ✅ كشف الأنماط الزمنية المشبوهة
- ✅ حد أقصى للنقاط في فترة زمنية
- ✅ تنبيهات تلقائية للإدارة

---

## 📊 إحصائيات الأداء

### متوسط XP للأنشطة
| النشاط | XP الأساسي | مكافأة إضافية |
|--------|-----------|---------------|
| تسجيل دخول يومي | 10 | +5 لكل يوم متتالي |
| مشاهدة فيديو | 20 | +10 للمشاهدة الكاملة |
| إكمال اختبار | 50 | +25 لعلامة كاملة |
| إنشاء محتوى | 100 | ×2 للجودة الذهبية |
| صفقة تداول | 30 | حسب الربح |
| إحالة صديق | 100 | - |

### معادلة المستويات
```typescript
Level = floor(sqrt(totalXP / 100)) + 1

// أمثلة:
// 100 XP = Level 2
// 400 XP = Level 3
// 900 XP = Level 4
// 1600 XP = Level 5
// 2500 XP = Level 6
// 10000 XP = Level 11
```

---

## 🚀 خطوات البدء

### 1. تهيئة النظام
```bash
# تهيئة الشارات الافتراضية
curl -X POST ${API_URL}/gamification/init

# تحديث لوحة الصدارة
curl -X POST ${API_URL}/gamification/leaderboard/update/weekly
```

### 2. إنشاء محتوى تجريبي
```bash
# إنشاء فيديو
curl -X POST ${API_URL}/content/videos/create \
  -H "Content-Type: application/json" \
  -d '{
    "title": "مقدمة في التمويل الشخصي",
    "duration": 900,
    "category": "تخطيط مالي",
    "level": "مبتدئ",
    "videoUrl": "https://example.com/video.mp4",
    "owner": "admin"
  }'
```

### 3. اختبار رحلة المستخدم
```bash
# تسجيل دخول
curl -X POST ${API_URL}/gamification/login/test_user_1

# جلب التقدم
curl ${API_URL}/gamification/progress/test_user_1
```

---

## 📝 ملاحظات مهمة

1. **الشهادات**: صالحة لمدة سنة واحدة افتراضياً
2. **التقييمات**: من 1 إلى 5 نجوم
3. **الاختبارات**: حد أدنى للنجاح 70% افتراضياً
4. **لوحات الصدارة**: تُحدث تلقائياً كل 24 ساعة
5. **الشارات**: يتم فحصها تلقائياً عند أي نشاط يمنح XP

---

**تم البناء بحب من فريق أكاديمية الذهب المالية** 🏆✨
