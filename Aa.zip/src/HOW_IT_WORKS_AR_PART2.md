# 📚 كيف تعمل أنظمة أكاديمية الذهب المالية؟ (الجزء 2)

## 🤝 7. نظام الشراكات {#partnerships}

### 💡 الفكرة الأساسية
نظام متكامل لإدارة الشراكات مع الجامعات والبنوك والشركات والمؤثرين.

### 🔄 كيف يعمل؟

#### الخطوة 1️⃣: التسجيل كشريك
```javascript
// عندما تريد جامعة الانضمام كشريك
async function registerPartner(data) {
  
  // 1. التحقق من البيانات
  if (!data.type || !data.contactInfo) {
    throw new Error("بيانات غير مكتملة");
  }
  
  // 2. توليد كود إحالة فريد
  const referralCode = generateUniqueCode(data.name);
  // مثال: "KSUUNIV2024" لجامعة الملك سعود
  
  // 3. تحديد مستوى الشراكة والعمولة
  const tier = determineInitialTier(data.type);
  const commissionRate = getCommissionRate(data.type, tier);
  
  // مثال للجامعات:
  // Bronze: 5%, Silver: 8%, Gold: 12%, Platinum: 15%
  
  // 4. إنشاء حساب الشريك
  const partner = {
    id: `partner_${Date.now()}`,
    type: data.type, // university, bank, corporate, influencer
    name: data.name,
    contactInfo: data.contactInfo,
    referralCode: referralCode,
    tier: tier, // bronze
    commissionRate: commissionRate, // 5%
    status: "pending", // pending, active, suspended
    totalReferrals: 0,
    completedReferrals: 0,
    totalRevenue: 0,
    totalCommission: 0,
    createdAt: new Date(),
    metadata: data.metadata // بيانات إضافية حسب النوع
  };
  
  // 5. حفظ في قاعدة البيانات
  await savePartner(partner);
  
  // 6. إرسال بريد ترحيبي
  await sendWelcomeEmail(partner);
  
  return {
    partnerId: partner.id,
    referralCode: referralCode,
    dashboardUrl: `/partner/dashboard/${partner.id}`
  };
}
```

#### الخطوة 2️⃣: تتبع الإحالات
```javascript
// عندما يستخدم طالب كود الإحالة
async function trackReferral(referralCode, newUserId, activityType) {
  
  // 1. جلب معلومات الشريك
  const partner = await getPartnerByCode(referralCode);
  if (!partner) {
    throw new Error("كود إحالة غير صحيح");
  }
  
  // 2. إنشاء سجل إحالة
  const referral = {
    id: `ref_${Date.now()}`,
    partnerId: partner.id,
    referralCode: referralCode,
    userId: newUserId,
    status: "pending", // pending, completed, cancelled
    activityType: activityType, // signup, subscription, course_purchase
    referralDate: new Date(),
    completionDate: null,
    transactionAmount: 0,
    commissionAmount: 0
  };
  
  await saveReferral(referral);
  
  // 3. تحديث إحصائيات الشريك
  partner.totalReferrals++;
  await updatePartner(partner.id, partner);
  
  // 4. إشعار الشريك
  await notifyPartner(partner.id, {
    type: "new_referral",
    message: `إحالة جديدة! المستخدم ${newUserId} انضم عبر كودك`
  });
  
  return referral;
}
```

#### الخطوة 3️⃣: حساب العمولات
```javascript
// عندما يقوم المستخدم المُحال بعملية شراء
async function calculateCommission(referralId, transactionAmount) {
  
  // 1. جلب الإحالة والشريك
  const referral = await getReferral(referralId);
  const partner = await getPartner(referral.partnerId);
  
  // 2. حساب العمولة
  const commissionAmount = transactionAmount * (partner.commissionRate / 100);
  
  // مثال:
  // مبلغ الاشتراك: 500 ريال
  // نسبة العمولة: 12% (Gold tier)
  // العمولة: 500 * 0.12 = 60 ريال
  
  // 3. تطبيق الحد الأقصى إن وجد
  const maxCommission = getMaxCommission(partner.type, partner.tier);
  const finalCommission = Math.min(commissionAmount, maxCommission);
  
  // 4. تحديث الإحالة
  referral.status = "completed";
  referral.completionDate = new Date();
  referral.transactionAmount = transactionAmount;
  referral.commissionAmount = finalCommission;
  
  await updateReferral(referralId, referral);
  
  // 5. تحديث إحصائيات الشريك
  partner.completedReferrals++;
  partner.totalRevenue += transactionAmount;
  partner.totalCommission += finalCommission;
  partner.pendingCommission = (partner.pendingCommission || 0) + finalCommission;
  
  await updatePartner(partner.id, partner);
  
  // 6. فحص إمكانية الترقية
  await checkTierUpgrade(partner.id);
  
  return {
    commissionAmount: finalCommission,
    totalCommission: partner.totalCommission
  };
}
```

#### الخطوة 4️⃣: نظام الترقيات التلقائي
```javascript
// فحص إمكانية ترقية الشريك لمستوى أعلى
async function checkTierUpgrade(partnerId) {
  const partner = await getPartner(partnerId);
  
  // معايير الترقية (مثال للجامعات)
  const tierRequirements = {
    silver: { minReferrals: 50, minRevenue: 25000 },
    gold: { minReferrals: 200, minRevenue: 100000 },
    platinum: { minReferrals: 500, minRevenue: 250000 }
  };
  
  // تحديد المستوى المناسب
  let newTier = partner.tier;
  
  if (partner.completedReferrals >= tierRequirements.platinum.minReferrals &&
      partner.totalRevenue >= tierRequirements.platinum.minRevenue) {
    newTier = "platinum";
  } else if (partner.completedReferrals >= tierRequirements.gold.minReferrals &&
             partner.totalRevenue >= tierRequirements.gold.minRevenue) {
    newTier = "gold";
  } else if (partner.completedReferrals >= tierRequirements.silver.minReferrals &&
             partner.totalRevenue >= tierRequirements.silver.minRevenue) {
    newTier = "silver";
  }
  
  // إذا كان هناك ترقية
  if (newTier !== partner.tier) {
    await upgradePartner(partnerId, newTier);
    
    // إرسال تهنئة
    await sendCongratulationsEmail(partner, newTier);
    
    // منح مكافأة
    const bonus = getTierUpgradeBonus(newTier);
    partner.pendingCommission += bonus;
  }
}
```

#### الخطوة 5️⃣: لوحة تحكم الشريك
```javascript
// عندما يفتح الشريك لوحة التحكم
async function getPartnerDashboard(partnerId) {
  
  const partner = await getPartner(partnerId);
  const referrals = await getPartnerReferrals(partnerId);
  
  // 1. إحصائيات عامة
  const stats = {
    totalReferrals: partner.totalReferrals,
    completedReferrals: partner.completedReferrals,
    pendingReferrals: partner.totalReferrals - partner.completedReferrals,
    conversionRate: (partner.completedReferrals / partner.totalReferrals * 100) || 0,
    totalRevenue: partner.totalRevenue,
    totalCommission: partner.totalCommission,
    pendingCommission: partner.pendingCommission || 0,
    averageCommission: partner.totalCommission / partner.completedReferrals || 0
  };
  
  // 2. أداء شهري
  const monthlyPerformance = calculateMonthlyPerformance(referrals);
  
  // 3. أفضل 10 إحالات
  const topReferrals = referrals
    .sort((a, b) => b.commissionAmount - a.commissionAmount)
    .slice(0, 10);
  
  // 4. تقدم نحو المستوى التالي
  const nextTierProgress = calculateNextTierProgress(partner);
  
  return {
    partner: partner,
    stats: stats,
    monthlyPerformance: monthlyPerformance,
    topReferrals: topReferrals,
    nextTierProgress: nextTierProgress
  };
}
```

### 📊 مثال رحلة كاملة

```
الشريك: جامعة الملك سعود
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📅 يناير 2024
✅ تسجيل كشريك
🎫 كود الإحالة: KSUUNIV2024
🏅 المستوى: Bronze (عمولة 5%)

📅 فبراير 2024
👥 30 طالب انضموا عبر الكود
💰 قيمة الاشتراكات: 15,000 ريال
💵 العمولة المكتسبة: 750 ريال

📅 مارس 2024
👥 إجمالي الطلاب: 65
💰 إجمالي الإيرادات: 32,500 ريال
🎉 ترقية تلقائية لمستوى Silver!
🏅 المستوى الجديد: Silver (عمولة 8%)
🎁 مكافأة الترقية: +500 ريال

📅 يونيو 2024
👥 إجمالي الطلاب: 220
💰 إجمالي الإيرادات: 110,000 ريال
🎉 ترقية تلقائية لمستوى Gold!
🏅 المستوى الجديد: Gold (عمولة 12%)
💎 العمولة الإجمالية: 10,200 ريال

📊 لوحة التحكم (يونيو 2024):
┌─────────────────────────────────────┐
│  جامعة الملك سعود                  │
│  🏅 Gold Partner                    │
├─────────────────────────────────────┤
│  📊 الإحصائيات:                    │
│  👥 إجمالي الإحالات: 220           │
│  ✅ المكتملة: 198 (90%)            │
│  ⏳ قيد الانتظار: 22               │
│                                     │
│  💰 الإيرادات:                      │
│  📈 الإجمالي: 110,000 ريال         │
│  💵 العمولة الكلية: 10,200 ريال    │
│  ⏰ عمولة معلقة: 1,200 ريال        │
│  💳 متوسط العمولة: 51.5 ريال       │
│                                     │
│  🎯 التقدم نحو Platinum:           │
│  الإحالات: 220/500 (44%) ███░░░░   │
│  الإيرادات: 110K/250K (44%) ███░░░ │
│                                     │
│  📈 الأداء الشهري:                 │
│  Jan: 750 ريال                      │
│  Feb: 1,200 ريال                    │
│  Mar: 2,100 ريال (+ ترقية)         │
│  Apr: 2,400 ريال                    │
│  May: 2,550 ريال                    │
│  Jun: 2,700 ريال (+ ترقية)         │
└─────────────────────────────────────┘
```

---

## 📚 8. نظام المحتوى التعليمي {#content-system}

### 💡 الفكرة الأساسية
منصة شاملة للفيديوهات التعليمية والاختبارات والشهادات.

### 🔄 كيف يعمل؟

#### الخطوة 1️⃣: إضافة محتوى
```javascript
// المدرب يرفع فيديو جديد
async function uploadVideo(instructorId, videoData) {
  
  // 1. معالجة الفيديو
  const processedVideo = await processVideoFile(videoData.file, {
    quality: '1080p',
    watermark: true, // علامة مائية للحماية
    compression: 'high'
  });
  
  // 2. إنشاء سجل الفيديو
  const video = {
    id: `video_${Date.now()}`,
    title: videoData.title,
    description: videoData.description,
    duration: processedVideo.duration, // بالثواني
    category: videoData.category, // تداول، عقارات، etc.
    level: videoData.level, // مبتدئ، متوسط، متقدم
    thumbnail: processedVideo.thumbnail,
    videoUrl: processedVideo.url,
    transcript: videoData.transcript, // نص الفيديو (مشفر)
    resources: videoData.resources, // ملفات PDF مرفقة
    owner: instructorId,
    views: 0,
    averageRating: 0,
    ratings: [],
    isVerified: false, // يحتاج موافقة الإدارة
    createdAt: new Date()
  };
  
  // 3. حفظ في قاعدة البيانات
  await saveVideo(video);
  
  // 4. منح XP للمدرب
  await grantXP(instructorId, 'content_creation', {
    contentId: video.id,
    quality: 'gold'
  });
  // يحصل على 200 XP
  
  return video;
}
```

#### الخطوة 2️⃣: مشاهدة الفيديو
```javascript
// عندما يشاهد طالب الفيديو
async function watchVideo(userId, videoId) {
  
  // 1. جلب الفيديو
  const video = await getVideo(videoId);
  if (!video) {
    throw new Error("الفيديو غير موجود");
  }
  
  // 2. التحقق من الصلاحيات
  const hasAccess = await checkUserAccess(userId, video);
  if (!hasAccess) {
    throw new Error("ليس لديك صلاحية لمشاهدة هذا الفيديو");
  }
  
  // 3. توليد رابط مشفر مؤقت (DRM)
  const streamTicket = generateStreamTicket(video, userId, {
    expiresIn: 3600, // ساعة واحدة
    deviceId: getUserDeviceId(userId),
    maxViews: 1
  });
  
  // 4. تسجيل المشاهدة
  await incrementViews(videoId);
  
  // 5. تتبع التقدم
  const watchSession = {
    userId: userId,
    videoId: videoId,
    startTime: new Date(),
    progress: 0, // نسبة المشاهدة
    completed: false
  };
  await saveWatchSession(watchSession);
  
  // 6. منح XP عند الانتهاء (يتم تحديثه من الواجهة)
  
  return {
    video: video,
    streamUrl: video.videoUrl,
    streamTicket: streamTicket
  };
}

// عندما ينهي المستخدم المشاهدة
async function completeVideoWatch(userId, videoId, watchPercentage) {
  
  // إذا شاهد 90% أو أكثر
  if (watchPercentage >= 90) {
    // منح XP كامل
    await grantXP(userId, 'video_watch', {
      videoId: videoId,
      watchedPercentage: watchPercentage
    });
    // 30 XP
    
    // تحديث الإحصائيات
    const progress = await getUserProgress(userId);
    progress.stats.videosWatched++;
    await updateUserProgress(userId, progress);
  }
}
```

#### الخطوة 3️⃣: الاختبارات
```javascript
// إنشاء اختبار مرتبط بفيديو
async function createQuiz(videoId, quizData) {
  
  const quiz = {
    id: `quiz_${Date.now()}`,
    title: quizData.title,
    relatedVideoId: videoId,
    category: quizData.category,
    level: quizData.level,
    
    // الأسئلة
    questions: quizData.questions.map((q, index) => ({
      id: `q_${index + 1}`,
      text: q.text,
      options: q.options, // 4 خيارات
      correctAnswer: q.correctAnswer, // 0-3
      explanation: q.explanation // شرح الإجابة الصحيحة
    })),
    
    passingScore: 70, // 70% للنجاح
    timeLimit: 30, // 30 دقيقة
    createdAt: new Date()
  };
  
  await saveQuiz(quiz);
  return quiz;
}

// بدء جلسة اختبار
async function startQuiz(userId, quizId) {
  
  const quiz = await getQuiz(quizId);
  
  // إنشاء جلسة
  const session = {
    id: `session_${Date.now()}`,
    userId: userId,
    quizId: quizId,
    startTime: new Date(),
    endTime: new Date(Date.now() + quiz.timeLimit * 60000),
    answers: [],
    score: null,
    isCompleted: false
  };
  
  await saveQuizSession(session);
  
  return {
    sessionId: session.id,
    quiz: quiz,
    timeLimit: quiz.timeLimit,
    endTime: session.endTime
  };
}

// تسجيل إجابة
async function submitAnswer(sessionId, questionId, answer) {
  
  const session = await getQuizSession(sessionId);
  
  // التحقق من الوقت
  if (new Date() > new Date(session.endTime)) {
    throw new Error("انتهى وقت الاختبار");
  }
  
  // التحقق من عدم الإجابة مسبقاً
  const alreadyAnswered = session.answers.some(a => a.questionId === questionId);
  if (alreadyAnswered) {
    throw new Error("تم الإجابة على هذا السؤال مسبقاً");
  }
  
  // حفظ الإجابة
  session.answers.push({
    questionId: questionId,
    answer: answer,
    timestamp: new Date()
  });
  
  await updateQuizSession(sessionId, session);
  
  return { success: true };
}

// إنهاء الاختبار
async function completeQuiz(sessionId) {
  
  const session = await getQuizSession(sessionId);
  const quiz = await getQuiz(session.quizId);
  
  // حساب النتيجة
  let correctAnswers = 0;
  for (const answer of session.answers) {
    const question = quiz.questions.find(q => q.id === answer.questionId);
    if (question && question.correctAnswer === answer.answer) {
      correctAnswers++;
    }
  }
  
  const score = Math.round((correctAnswers / quiz.questions.length) * 100);
  const passed = score >= quiz.passingScore;
  
  // تحديث الجلسة
  session.score = score;
  session.isCompleted = true;
  await updateQuizSession(sessionId, session);
  
  // منح XP
  let xpAmount = 50; // XP أساسي
  if (score === 100) {
    xpAmount += 25; // مكافأة العلامة الكاملة
  }
  
  await grantXP(session.userId, 'quiz_complete', {
    quizId: quiz.id,
    score: score
  });
  
  // إصدار شهادة إذا نجح
  let certificate = null;
  if (passed) {
    certificate = await issueCertificate(
      session.userId,
      quiz.relatedVideoId || quiz.id,
      quiz.title,
      score
    );
  }
  
  return {
    score: score,
    passed: passed,
    correctAnswers: correctAnswers,
    totalQuestions: quiz.questions.length,
    certificate: certificate,
    xpGained: xpAmount
  };
}
```

#### الخطوة 4️⃣: الشهادات
```javascript
// إصدار شهادة للمستخدم
async function issueCertificate(userId, courseId, courseName, grade) {
  
  // التحقق من عدم وجود شهادة سابقة
  const existing = await getCertificate(userId, courseId);
  if (existing) {
    return existing; // لا يمكن إصدار شهادة مرتين لنفس الدورة
  }
  
  // إنشاء الشهادة
  const certificate = {
    id: `cert_${Date.now()}`,
    userId: userId,
    courseId: courseId,
    courseName: courseName,
    grade: grade,
    issueDate: new Date(),
    expirationDate: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000), // سنة
    verificationCode: generateVerificationCode(), // "ABC123XYZ789"
    
    // معلومات NFT (اختياري)
    nftMetadata: {
      tokenId: null, // سيتم توليده لاحقاً
      contractAddress: null,
      explorerUrl: null
    }
  };
  
  // حفظ الشهادة
  await saveCertificate(certificate);
  
  // تحديث إحصائيات المستخدم
  const progress = await getUserProgress(userId);
  progress.stats.certificatesEarned++;
  await updateUserProgress(userId, progress);
  
  // إرسال إشعار
  await sendCertificateNotification(userId, certificate);
  
  return certificate;
}

// التحقق من صحة شهادة
async function verifyCertificate(verificationCode) {
  
  const certificate = await getCertificateByCode(verificationCode);
  
  if (!certificate) {
    return {
      valid: false,
      message: "رمز التحقق غير صحيح"
    };
  }
  
  // التحقق من الصلاحية
  if (certificate.expirationDate && new Date() > new Date(certificate.expirationDate)) {
    return {
      valid: false,
      message: "الشهادة منتهية الصلاحية"
    };
  }
  
  return {
    valid: true,
    certificate: certificate
  };
}
```

### 📊 مثال رحلة كاملة

```
المستخدم: عبدالله
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📅 الإثنين
🎥 يشاهد: "مقدمة في التداول" (20 دقيقة)
✅ إكمال 100%
💎 +30 XP

📅 الثلاثاء
🎥 يشاهد: "استراتيجيات التداول" (35 دقيقة)
✅ إكمال 95%
💎 +30 XP

📅 الأربعاء
📝 يبدأ اختبار: "أساسيات التداول"
⏱️ الوقت: 30 دقيقة
❓ عدد الأسئلة: 20 سؤال

السؤال 1/20:
"ما هو السهم؟"
أ) حصة ملكية في شركة ✅
ب) قرض للشركة
ج) سند حكومي
د) عملة رقمية

⏰ بعد 25 دقيقة...
✅ انتهى من جميع الأسئلة

📊 النتيجة:
- الإجابات الصحيحة: 18/20
- النقاط: 90/100
- الحالة: نجح! ✅
- XP المكتسب: +50 (أساسي) +0 (ليس 100%)

🎓 إصدار الشهادة...
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🏆 شهادة إتمام دورة
"أساسيات التداول"

👤 المتدرب: عبدالله أحمد
📅 تاريخ الإصدار: 5 ديسمبر 2024
📊 الدرجة: 90/100
🔐 كود التحقق: ABC123XYZ789
⏳ صالحة حتى: 5 ديسمبر 2025
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📊 تقدم عبدالله الإجمالي:
- الفيديوهات المشاهدة: 2
- الاختبارات المكتملة: 1
- الشهادات المكتسبة: 1
- إجمالي XP: 110
```

---

## 🎮 9. نظام التحفيز Gamification {#gamification}

### 💡 الفكرة الأساسية
نظام نقاط ومستويات وشارات لتحفيز المستخدمين على التعلم المستمر.

### 🔄 كيف يعمل؟

#### الخطوة 1️⃣: نظام XP (نقاط الخبرة)
```javascript
// مصادر كسب XP
const XP_SOURCES = {
  daily_login: { base: 10, streakBonus: 5 },
  video_watch: { base: 20, completionBonus: 10 },
  quiz_complete: { base: 50, perfectBonus: 25 },
  content_creation: { base: 100, qualityMultiplier: 2 },
  trading: { base: 30, profitBased: true },
  real_estate: { base: 40, roiBased: true },
  decisions: { base: 25, accuracyBased: true },
  referral: { base: 100 }
};

// حساب XP ديناميكياً
function calculateXP(source, details) {
  const config = XP_SOURCES[source];
  let xp = config.base;
  
  // مثال 1: تسجيل دخول يومي
  if (source === 'daily_login') {
    // مكافأة إضافية للأيام المتتالية
    xp += details.streakDays * config.streakBonus;
    // يوم 1: 10 XP
    // يوم 2: 15 XP
    // يوم 3: 20 XP
    // ...
    // يوم 7: 45 XP
  }
  
  // مثال 2: مشاهدة فيديو
  if (source === 'video_watch') {
    if (details.watchedPercentage >= 100) {
      xp += config.completionBonus;
      // مشاهدة كاملة: 20 + 10 = 30 XP
    }
  }
  
  // مثال 3: اختبار
  if (source === 'quiz_complete') {
    if (details.score === 100) {
      xp += config.perfectBonus;
      // علامة كاملة: 50 + 25 = 75 XP
    }
  }
  
  // مثال 4: تداول
  if (source === 'trading' && config.profitBased) {
    xp += Math.min(details.profitPercentage * 10, 200);
    // ربح 5%: 30 + 50 = 80 XP
    // ربح 15%: 30 + 150 = 180 XP
    // ربح 25%: 30 + 200 = 230 XP (الحد الأقصى)
  }
  
  return Math.min(xp, 500); // حد أقصى 500 XP لكل نشاط
}
```

#### الخطوة 2️⃣: نظام الحماية من التلاعب
```javascript
// التحقق من عدم وجود تلاعب
async function checkXPAbuse(userId, amount, source) {
  
  const now = Date.now();
  const oneHourAgo = now - 3600000;
  
  // 1. جلب نشاطات الساعة الأخيرة
  const recentActivities = await getUserActivities(userId, oneHourAgo, now);
  
  // 2. حساب XP في الساعة الأخيرة
  let hourlyXP = 0;
  for (const activity of recentActivities) {
    hourlyXP += activity.xpGained;
  }
  
  // 3. فحص الحد الأقصى
  if (hourlyXP + amount > 1000) {
    return {
      allowed: false,
      reason: "تجاوز الحد الأقصى لـ XP في الساعة (1000 XP)"
    };
  }
  
  // 4. فحص تكرار نفس المصدر
  const sameSourceCount = recentActivities.filter(a => a.source === source).length;
  if (sameSourceCount >= 10) {
    return {
      allowed: false,
      reason: "تكرار نفس النشاط كثيراً في وقت قصير"
    };
  }
  
  // 5. فحص نمط التصيد (Farming)
  const activityTimes = recentActivities.map(a => new Date(a.timestamp).getTime());
  if (activityTimes.length >= 5) {
    // فحص إذا كانت 5 أنشطة في أقل من دقيقة
    const timeSpan = Math.max(...activityTimes) - Math.min(...activityTimes);
    if (timeSpan < 60000) {
      return {
        allowed: false,
        reason: "نمط مشبوه - نشاطات سريعة جداً"
      };
    }
  }
  
  return { allowed: true };
}
```

#### الخطوة 3️⃣: المستويات
```javascript
// حساب المستوى من XP
function calculateLevel(totalXP) {
  // صيغة: Level = floor(sqrt(XP / 100)) + 1
  return Math.floor(Math.sqrt(totalXP / 100)) + 1;
}

// أمثلة:
calculateLevel(0);      // Level 1
calculateLevel(100);    // Level 2
calculateLevel(400);    // Level 3
calculateLevel(900);    // Level 4
calculateLevel(1600);   // Level 5
calculateLevel(10000);  // Level 11
calculateLevel(40000);  // Level 21

// حساب XP المطلوب للمستوى التالي
function getXPForNextLevel(currentLevel) {
  const nextLevel = currentLevel + 1;
  return Math.pow(nextLevel - 1, 2) * 100;
}

// مثال:
// المستخدم في Level 5 (لديه 1600 XP)
// للوصول إلى Level 6 يحتاج: 6^2 * 100 = 3600 XP
// XP متبقية: 3600 - 1600 = 2000 XP
```

#### الخطوة 4️⃣: الشارات (Badges)
```javascript
// الشارات الافتراضية
const DEFAULT_BADGES = [
  {
    name: "المبتدئ",
    description: "ابدأ رحلتك التعليمية",
    tier: "bronze",
    icon: "beginner.png",
    xpReward: 50,
    criteria: { totalXP: 100 }
  },
  {
    name: "المتعلم النشط",
    description: "شاهد 10 فيديوهات",
    tier: "silver",
    xpReward: 100,
    criteria: { videosWatched: 10 }
  },
  {
    name: "خبير الاختبارات",
    description: "أكمل 5 اختبارات بنجاح",
    tier: "gold",
    xpReward: 200,
    criteria: { quizzesCompleted: 5 }
  },
  {
    name: "المثابر",
    description: "سجل دخول لمدة 7 أيام متتالية",
    tier: "gold",
    xpReward: 250,
    criteria: { loginStreak: 7 }
  },
  {
    name: "صانع المحتوى",
    description: "أنشئ 5 محتويات تعليمية",
    tier: "platinum",
    xpReward: 500,
    criteria: { contentCreated: 5 }
  },
  {
    name: "المحترف",
    description: "اجمع 5000 XP",
    tier: "platinum",
    xpReward: 1000,
    criteria: { totalXP: 5000 }
  }
];

// فحص فتح الشارات تلقائياً
async function checkBadgeUnlocks(userId) {
  
  const progress = await getUserProgress(userId);
  const allBadges = await getAllBadges();
  const unlockedBadges = [];
  
  for (const badge of allBadges) {
    // تخطي إذا فتحها مسبقاً
    if (progress.badges.includes(badge.id)) continue;
    
    // فحص المعايير
    let meetsAllCriteria = true;
    
    for (const [key, requiredValue] of Object.entries(badge.criteria)) {
      let currentValue = 0;
      
      switch (key) {
        case 'totalXP':
          currentValue = progress.totalXP;
          break;
        case 'videosWatched':
          currentValue = progress.stats.videosWatched;
          break;
        case 'quizzesCompleted':
          currentValue = progress.stats.quizzesCompleted;
          break;
        case 'loginStreak':
          currentValue = progress.loginStreak;
          break;
        case 'contentCreated':
          currentValue = progress.stats.contentCreated;
          break;
      }
      
      if (currentValue < requiredValue) {
        meetsAllCriteria = false;
        break;
      }
    }
    
    // إذا استوفى المعايير
    if (meetsAllCriteria) {
      unlockedBadges.push(badge);
      
      // إضافة للمستخدم
      progress.badges.push(badge.id);
      
      // منح XP كمكافأة
      progress.totalXP += badge.xpReward;
      
      // إشعار
      await sendBadgeUnlockNotification(userId, badge);
    }
  }
  
  if (unlockedBadges.length > 0) {
    await updateUserProgress(userId, progress);
  }
  
  return unlockedBadges;
}
```

#### الخطوة 5️⃣: لوحة الصدارة
```javascript
// تحديث لوحة الصدارة
async function updateLeaderboard(period) {
  
  // جلب جميع المستخدمين
  const allUsers = await getAllUserProgress();
  
  // ترتيب حسب XP
  allUsers.sort((a, b) => b.totalXP - a.totalXP);
  
  // أخذ أفضل 100
  const top100 = allUsers.slice(0, 100);
  
  // إنشاء الترتيب
  const rankings = top100.map((user, index) => ({
    position: index + 1,
    userId: user.userId,
    username: user.username || `مستخدم_${user.userId.slice(-4)}`,
    score: user.totalXP,
    level: user.level,
    avatar: user.avatar
  }));
  
  // حفظ اللوحة
  const leaderboard = {
    id: `leaderboard_${period}_${Date.now()}`,
    period: period, // daily, weekly, monthly, all-time
    startDate: getStartDate(period),
    endDate: new Date(),
    rankings: rankings,
    lastUpdated: new Date()
  };
  
  await saveLeaderboard(leaderboard);
  
  // مكافآت للمتصدرين
  await distributeLeaderboardRewards(leaderboard);
  
  return leaderboard;
}

// توزيع مكافآت المتصدرين
async function distributeLeaderboardRewards(leaderboard) {
  
  // المركز الأول
  if (leaderboard.rankings[0]) {
    await grantXP(leaderboard.rankings[0].userId, 'event', {
      eventType: 'leaderboard_1st',
      period: leaderboard.period
    });
    // +1000 XP
    
    // شارة خاصة
    await awardSpecialBadge(leaderboard.rankings[0].userId, "الملك");
  }
  
  // المراكز 2-10
  for (let i = 1; i < 10 && i < leaderboard.rankings.length; i++) {
    await grantXP(leaderboard.rankings[i].userId, 'event', {
      eventType: 'leaderboard_top10',
      period: leaderboard.period
    });
    // +500 XP
    
    await awardSpecialBadge(leaderboard.rankings[i].userId, "النخبة");
  }
  
  // المراكز 11-100
  for (let i = 10; i < 100 && i < leaderboard.rankings.length; i++) {
    await grantXP(leaderboard.rankings[i].userId, 'event', {
      eventType: 'leaderboard_top100',
      period: leaderboard.period
    });
    // +250 XP
    
    await awardSpecialBadge(leaderboard.rankings[i].userId, "المتميز");
  }
}
```

### 📊 مثال رحلة كاملة

```
المستخدم: نورة
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📅 اليوم 1 - الأحد
🔐 تسجيل دخول: +10 XP
📊 الرصيد: 10 XP | المستوى: 1

📅 اليوم 2 - الإثنين
🔐 تسجيل دخول (سلسلة 2): +15 XP
🎥 مشاهدة فيديو كاملة: +30 XP
📊 الرصيد: 55 XP | المستوى: 1

📅 اليوم 3 - الثلاثاء
🔐 تسجيل دخول (سلسلة 3): +20 XP
📝 اختبار (نجح بـ 80%): +50 XP
🎉 فتحت شارة "المبتدئ"! +50 XP
📊 الرصيد: 175 XP | المستوى: 2 ⬆️

📅 اليوم 7 - السبت
🔐 تسجيل دخول (سلسلة 7): +45 XP
🎉 فتحت شارة "المثابر"! +250 XP
🎥 مشاهدة 10 فيديوهات
🎉 فتحت شارة "المتعلم النشط"! +100 XP
📊 الرصيد: 1,205 XP | المستوى: 4 ⬆️

📅 بعد شهر
📊 إحصائيات نورة:
┌─────────────────────────────────────┐
│  👤 نورة أحمد                      │
│  ⭐ المستوى: 7                     │
│  💎 XP: 4,250                       │
│  🏆 الترتيب: #42 من 1,234         │
├─────────────────────────────────────┤
│  📊 الإحصائيات:                    │
│  🔥 سلسلة الدخول: 23 يوم          │
│  🎥 فيديوهات: 28                   │
│  📝 اختبارات: 12                   │
│  🎓 شهادات: 4                       │
│  💼 صفقات رابحة: 15                │
├─────────────────────────────────────┤
│  🏅 الشارات (7/15):                │
│  🥉 المبتدئ                         │
│  🥈 المتعلم النشط                  │
│  🥇 خبير الاختبارات                │
│  🥇 المثابر                         │
│  🥈 المتداول الماهر                │
│  🥉 مستثمر عقاري                   │
│  🥈 صانع قرارات حكيمة              │
├─────────────────────────────────────┤
│  🎯 التقدم نحو المستوى 8:         │
│  ███████░░░ 4,250 / 6,400         │
│  متبقي: 2,150 XP                   │
└─────────────────────────────────────┘
```

---

## 🔗 10. كيف تتكامل الأنظمة؟ {#integration}

### 💡 الفكرة الأساسية
جميع الأنظمة مترابطة ومتكاملة لتوفير تجربة تعليمية شاملة.

### 🔄 سيناريو التكامل الكامل

```
المستخدم: يوسف (طالب جامعي)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📅 اليوم 1
──────────────────────────────────────
1️⃣ التسجيل عبر كود جامعته
   🎫 كود الإحالة: KSUUNIV2024
   ✅ حساب جديد تم إنشاؤه
   
   [نظام الشراكات]
   → تسجيل إحالة جديدة للجامعة
   → عداد الإحالات: +1
   
   [نظام التحفيز]
   → رصيد XP الأولي: 0
   → المستوى: 1

2️⃣ تسجيل الدخول الأول
   [نظام التحفيز]
   → منح XP تسجيل دخول: +10
   → تحديث سلسلة الدخول: 1 يوم
   
   [نظام AI]
   → إنشاء ملف شخصي جديد
   → مستوى المعرفة: 0/10
   → اهتمامات: غير محددة

3️⃣ مشاهدة فيديو تعليمي
   [نظام المحتوى]
   → فتح: "مقدمة في التداول"
   → تسجيل مشاهدة
   → تتبع التقدم: 0% → 100%
   
   [نظام التحفيز]
   → منح XP مشاهدة: +30
   → تحديث stats.videosWatched: 1
   
   [نظام AI]
   → تحديث اهتمامات: ["تداول"]
   → تحديث نمط التعلم: "visual"
   → زيادة مستوى المعرفة: 1/10
   
   [نظام التوصيات]
   → تسجيل نشاط: video_watch
   → بناء الملف الشخصي
   → توليد توصيات أولية

📅 اليوم 2
──────────────────────────────────────
4️⃣ إكمال اختبار
   [نظام المحتوى]
   → بدء: "اختبار التداول الأساسي"
   → إجابة 20 سؤال
   → النتيجة: 85/100 ✅
   
   [نظام التحفيز]
   → منح XP اختبار: +50
   → فتح شارة "المبتدئ": +50
   → المستوى الجديد: 2 ⬆️
   
   [نظام المحتوى]
   → إصدار شهادة
   → كود التحقق: ABC123
   
   [نظام AI]
   → تحليل الأداء
   → نقاط القوة: التحليل الأساسي
   → نقاط الضعف: التحليل الفني

5️⃣ التدرب على المحاكاة
   [نظام التداول]
   → فتح صفقة: AAPL
   → شراء 50 سهم @ $150
   → إغلاق بربح: +$60
   
   [نظام التحفيز]
   → منح XP تداول: +36
   → تحديث stats.tradingProfits
   
   [نظام التحليلات]
   → تسجيل الصفقة
   → تحديث winRate: 100%
   → تحليل الأداء
   
   [نظام AI]
   → اكتشاف نمط: تداول حذر
   → توصية: جرب صفقات أكبر

📅 اليوم 7
──────────────────────────────────────
6️⃣ سلسلة دخول 7 أيام
   [نظام التحفيز]
   → منح XP دخول: +45
   → فتح شارة "المثابر": +250
   → المستوى الجديد: 4 ⬆️
   
   [نظام AI]
   → تهنئة على الالتزام
   → نصيحة مخصصة

7️⃣ طلب توصيات
   [نظام التوصيات]
   → تحليل النشاط
   → الاهتمامات: تداول (70%), عقارات (20%)
   → المستوى: متوسط
   → نمط التعلم: عملي
   
   → التوصيات:
     1. "استراتيجيات التداول المتقدمة"
     2. "محاكاة تداول الخيارات"
     3. "إدارة المخاطر في التداول"
   
   [نظام AI]
   → شرح سبب كل توصية
   → اقتراح مسار تعليمي

📅 اليوم 30
──────────────────────────────────────
8️⃣ تقرير الأداء الشهري
   [نظام التحليلات]
   → جمع البيانات من جميع الأنظمة:
     
     📊 التداول:
     - صفقات: 45
     - winRate: 62%
     - ربح صافي: +$850
     
     🏠 العقارات:
     - عقارات: 2
     - ROI: 12%
     - دخل شهري: $400
     
     🎯 القرارات:
     - سيناريوهات: 15
     - متوسط النقاط: 78/100
     
     📚 التعليم:
     - فيديوهات: 22
     - اختبارات: 8
     - شهادات: 3
   
   → تقييم عام: 82/100 🌟
   → نقاط القوة: التداول، الالتزام
   → نقاط الضعف: القرارات السريعة
   
   [نظام AI]
   → توصيات مخصصة:
     1. تحسين سرعة اتخاذ القرار
     2. تنويع المحفظة الاستثمارية
     3. التركيز على التحليل الفني
   
   [نظام التحفيز]
   → الترتيب: #28 من 1,234
   → المستوى: 8
   → XP: 6,420

9️⃣ الاشتراك المدفوع
   [نظام الشراكات]
   → تسجيل عملية شراء
   → المبلغ: 500 ريال
   → حساب عمولة الجامعة:
     500 × 12% = 60 ريال
   → تحديث إحصائيات الجامعة:
     completedReferrals: +1
     totalRevenue: +500
     totalCommission: +60
   
   [نظام المحتوى]
   → فتح جميع الدورات المتقدمة
   → فتح المحاكاة المتقدمة
   
   [نظام التحفيز]
   → منح XP اشتراك: +100
   → شارة خاصة: "العضو الذهبي"

🔟 بعد 3 أشهر
──────────────────────────────────────
[لوحة الصدارة]
→ يوسف في المركز #12
→ مكافأة: +500 XP
→ شارة: "النخبة"

[نظام الشراكات - الجامعة]
→ إجمالي الطلاب: 250
→ الإيرادات: 125,000 ريال
→ العمولة: 15,000 ريال
→ ترقية تلقائية: Gold → Platinum
→ العمولة الجديدة: 15%

[تقرير يوسف النهائي]
┌─────────────────────────────────────┐
│  🎓 رحلة يوسف التعليمية (90 يوم)  │
├─────────────────────────────────────┤
│  📊 الإحصائيات:                    │
│  🎥 فيديوهات: 68                   │
│  📝 اختبارات: 24                   │
│  🎓 شهادات: 9                       │
│  💼 صفقات: 150                      │
│  🏠 عقارات: 5                       │
│  🎯 قرارات: 45                      │
│                                     │
│  🏆 الإنجازات:                      │
│  ⭐ المستوى: 12                    │
│  💎 XP: 15,420                      │
│  🏅 الشارات: 12/20                 │
│  📊 الترتيب: #12 من 1,500         │
│                                     │
│  💰 الأداء المالي (محاكاة):       │
│  📈 ربح تداول: +$4,250             │
│  🏠 دخل عقاري: +$1,200/شهر        │
│  💵 العائد الكلي: +18.5%           │
│                                     │
│  🎯 التقييم العام: 89/100         │
│  🌟🌟🌟🌟 ممتاز                    │
└─────────────────────────────────────┘
```

---

## 🎯 ملخص التكامل

### كيف تتحدث الأنظمة مع بعضها؟

```javascript
// مثال: عند إكمال فيديو
async function onVideoCompleted(userId, videoId) {
  
  // 1. نظام المحتوى
  await markVideoCompleted(userId, videoId);
  
  // 2. نظام التحفيز
  const xpResult = await grantXP(userId, 'video_watch', {
    videoId: videoId,
    watchedPercentage: 100
  });
  
  // 3. فحص الشارات (تلقائي)
  const newBadges = await checkBadgeUnlocks(userId);
  
  // 4. نظام AI
  await updateKnowledgeLevel(userId, {
    topic: video.category,
    depth: video.level
  });
  
  // 5. نظام التوصيات
  await trackActivity(userId, {
    type: 'video_watch',
    contentId: videoId,
    category: video.category,
    timeSpent: video.duration,
    completed: true
  });
  
  // 6. نظام التحليلات
  await recordLearningActivity(userId, {
    activityType: 'video',
    duration: video.duration,
    category: video.category
  });
  
  // 7. إرجاع النتيجة الكاملة
  return {
    xpGained: xpResult.xpGained,
    newLevel: xpResult.newLevel,
    newBadges: newBadges,
    recommendations: await getRecommendations(userId, 3)
  };
}
```

---

**🎉 هذا هو سحر التكامل! كل نظام يعمل بشكل مستقل، لكنهم جميعاً يتعاونون لتقديم تجربة متكاملة وسلسة للمستخدم.**
