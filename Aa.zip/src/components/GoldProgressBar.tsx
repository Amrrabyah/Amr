import { motion } from 'motion/react';

interface GoldProgressBarProps {
  progress: number;
  level: number;
  xp: number;
  maxXp: number;
}

export function GoldProgressBar({ progress, level, xp, maxXp }: GoldProgressBarProps) {
  return (
    <div className="glass-gold rounded-full p-6 relative overflow-hidden">
      {/* Animated background shimmer */}
      <div className="absolute inset-0 opacity-20">
        <div className="w-full h-full animate-shimmer"
          style={{
            background: 'linear-gradient(90deg, transparent, rgba(255,215,0,0.5), transparent)',
            backgroundSize: '200% 100%',
          }}
        />
      </div>

      <div className="relative z-10 flex items-center gap-6">
        {/* Circular Progress */}
        <div className="relative w-24 h-24">
          <svg className="transform -rotate-90 w-24 h-24">
            <circle
              cx="48"
              cy="48"
              r="40"
              stroke="rgba(255,215,0,0.2)"
              strokeWidth="8"
              fill="none"
            />
            <motion.circle
              cx="48"
              cy="48"
              r="40"
              stroke="url(#gold-gradient)"
              strokeWidth="8"
              fill="none"
              strokeLinecap="round"
              strokeDasharray={251.2}
              strokeDashoffset={251.2 * (1 - progress / 100)}
              initial={{ strokeDashoffset: 251.2 }}
              animate={{ strokeDashoffset: 251.2 * (1 - progress / 100) }}
              transition={{ duration: 1.5, ease: "easeOut" }}
            />
            <defs>
              <linearGradient id="gold-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#FFD700" />
                <stop offset="100%" stopColor="#D4AF37" />
              </linearGradient>
            </defs>
          </svg>
          
          {/* Level in center */}
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-center">
              <div className="text-xs opacity-70">المستوى</div>
              <div className="text-2xl font-bold text-[#FFD700]">{level}</div>
            </div>
          </div>

          {/* Rotating stars */}
          {[0, 120, 240].map((rotation, i) => (
            <motion.div
              key={i}
              className="absolute top-0 left-1/2 w-2 h-2"
              style={{
                transformOrigin: '50% 48px',
              }}
              animate={{
                rotate: [rotation, rotation + 360],
              }}
              transition={{
                duration: 3,
                repeat: Infinity,
                ease: "linear",
                delay: i * 0.3,
              }}
            >
              <div className="w-2 h-2 bg-[#FFD700] rounded-full blur-sm" />
            </motion.div>
          ))}
        </div>

        {/* XP Bar */}
        <div className="flex-1">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm opacity-80">نقاط الخبرة</span>
            <motion.span 
              className="text-lg font-bold text-[#FFD700] monospace"
              key={xp}
              initial={{ scale: 1.5, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ type: "spring", stiffness: 200 }}
            >
              {xp.toLocaleString('ar-SA')} / {maxXp.toLocaleString('ar-SA')}
            </motion.span>
          </div>

          {/* Progress track */}
          <div className="relative h-4 bg-black/50 rounded-full overflow-hidden">
            <motion.div
              className="absolute inset-y-0 right-0 rounded-full"
              style={{
                background: 'linear-gradient(90deg, #D4AF37 0%, #FFD700 50%, #FFED4E 100%)',
                boxShadow: '0 0 20px rgba(255, 215, 0, 0.6)',
              }}
              initial={{ width: 0 }}
              animate={{ width: `${(xp / maxXp) * 100}%` }}
              transition={{ duration: 1.5, ease: "easeOut" }}
            />

            {/* Animated shine */}
            <motion.div
              className="absolute inset-0"
              style={{
                background: 'linear-gradient(90deg, transparent, rgba(255,255,255,0.4), transparent)',
              }}
              animate={{
                x: ['-100%', '200%'],
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                repeatDelay: 1,
              }}
            />
          </div>

          {/* Coin fall animation */}
          <div className="relative h-0">
            {Array.from({ length: 3 }).map((_, i) => (
              <motion.div
                key={i}
                className="absolute text-2xl"
                style={{ right: `${20 + i * 30}%`, top: 0 }}
                initial={{ y: -50, rotate: 0, opacity: 0 }}
                animate={{ y: 20, rotate: 360, opacity: [0, 1, 0] }}
                transition={{
                  duration: 1,
                  delay: i * 0.2,
                  repeat: Infinity,
                  repeatDelay: 3,
                }}
              >
                🪙
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
