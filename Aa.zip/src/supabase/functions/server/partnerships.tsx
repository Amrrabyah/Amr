import * as kv from './kv_store.tsx';

interface Partner {
  id: string;
  name: string;
  type: 'university' | 'bank' | 'corporate' | 'influencer';
  tier: 'bronze' | 'silver' | 'gold' | 'platinum';
  contact: {
    email: string;
    phone?: string;
    representative?: string;
  };
  commissionRate: number;
  referralCode: string;
  usersReferred: string[];
  revenueGenerated: number;
  customBenefits: any;
  agreement: {
    signed: boolean;
    startDate: string;
    endDate?: string;
    terms?: string;
  };
  createdAt: string;
  updatedAt: string;
}

interface Referral {
  id: string;
  partnerId: string;
  userId: string;
  status: 'pending' | 'completed' | 'rejected';
  commissionEarned: number;
  transactionAmount?: number;
  activityType?: string;
  createdAt: string;
  completedAt?: string;
}

// Generate unique referral code
function generateReferralCode(partnerType: string, partnerName: string): string {
  const prefix = partnerType.substring(0, 3).toUpperCase();
  const random = Math.random().toString(36).substring(2, 8).toUpperCase();
  return `${prefix}-${random}`;
}

// Commission rates by tier and activity
const COMMISSION_MATRIX = {
  university: {
    course_enrollment: {
      bronze: 0.10,
      silver: 0.15,
      gold: 0.20,
      platinum: 0.25
    },
    certificate_issuance: {
      bronze: 50,
      silver: 75,
      gold: 100,
      platinum: 150
    },
    student_subscription: {
      bronze: 100,
      silver: 150,
      gold: 200,
      platinum: 300
    }
  },
  bank: {
    account_opening: {
      bronze: 200,
      silver: 300,
      gold: 500,
      platinum: 1000
    },
    loan_issuance: {
      bronze: 0.01,
      silver: 0.015,
      gold: 0.02,
      platinum: 0.025
    },
    investment_product: {
      bronze: 0.05,
      silver: 0.075,
      gold: 0.10,
      platinum: 0.15
    }
  },
  corporate: {
    bulk_subscription: {
      bronze: 0.15,
      silver: 0.20,
      gold: 0.25,
      platinum: 0.30
    },
    employee_referral: {
      bronze: 100,
      silver: 150,
      gold: 200,
      platinum: 300
    },
    training_program: {
      bronze: 0.12,
      silver: 0.18,
      gold: 0.25,
      platinum: 0.35
    }
  },
  influencer: {
    user_signup: {
      bronze: 50,
      silver: 75,
      gold: 100,
      platinum: 150
    },
    premium_conversion: {
      bronze: 0.20,
      silver: 0.25,
      gold: 0.30,
      platinum: 0.40
    },
    course_purchase: {
      bronze: 0.15,
      silver: 0.20,
      gold: 0.25,
      platinum: 0.35
    }
  }
};

// Create new partner
export async function createPartner(data: {
  name: string;
  type: Partner['type'];
  tier?: Partner['tier'];
  contact: Partner['contact'];
  customBenefits?: any;
  agreementTerms?: string;
}): Promise<Partner> {
  const partnerId = `partner_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  const referralCode = generateReferralCode(data.type, data.name);

  const partner: Partner = {
    id: partnerId,
    name: data.name,
    type: data.type,
    tier: data.tier || 'bronze',
    contact: data.contact,
    commissionRate: 15,
    referralCode,
    usersReferred: [],
    revenueGenerated: 0,
    customBenefits: data.customBenefits || {},
    agreement: {
      signed: true,
      startDate: new Date().toISOString(),
      terms: data.agreementTerms
    },
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };

  await kv.set(`partner:${partnerId}`, JSON.stringify(partner));
  await kv.set(`partner_code:${referralCode}`, partnerId);

  return partner;
}

// Get partner by ID
export async function getPartner(partnerId: string): Promise<Partner | null> {
  const data = await kv.get(`partner:${partnerId}`);
  return data ? JSON.parse(data) : null;
}

// Get partner by referral code
export async function getPartnerByCode(referralCode: string): Promise<Partner | null> {
  const partnerId = await kv.get(`partner_code:${referralCode}`);
  if (!partnerId) return null;
  
  return getPartner(partnerId);
}

// Update partner
export async function updatePartner(
  partnerId: string,
  updates: Partial<Partner>
): Promise<Partner | null> {
  const partner = await getPartner(partnerId);
  if (!partner) return null;

  const updatedPartner = {
    ...partner,
    ...updates,
    updatedAt: new Date().toISOString()
  };

  await kv.set(`partner:${partnerId}`, JSON.stringify(updatedPartner));
  return updatedPartner;
}

// Track referral
export async function trackReferral(
  referralCode: string,
  userId: string,
  activityType?: string,
  transactionAmount?: number
): Promise<Referral> {
  const partner = await getPartnerByCode(referralCode);
  if (!partner) {
    throw new Error('كود إحالة غير صالح');
  }

  const referralId = `referral_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  
  const referral: Referral = {
    id: referralId,
    partnerId: partner.id,
    userId,
    status: 'pending',
    commissionEarned: 0,
    activityType,
    transactionAmount,
    createdAt: new Date().toISOString()
  };

  // Save referral
  await kv.set(`referral:${referralId}`, JSON.stringify(referral));
  
  // Update partner's referred users
  if (!partner.usersReferred.includes(userId)) {
    partner.usersReferred.push(userId);
    await updatePartner(partner.id, { usersReferred: partner.usersReferred });
  }

  // Index by partner and user
  await kv.set(`referral_by_partner:${partner.id}:${referralId}`, referralId);
  await kv.set(`referral_by_user:${userId}`, partner.id);

  return referral;
}

// Calculate commission
export function calculateCommission(
  partnerType: Partner['type'],
  tier: Partner['tier'],
  activityType: string,
  amount?: number
): number {
  const matrix = COMMISSION_MATRIX[partnerType];
  if (!matrix || !matrix[activityType]) {
    return 0;
  }

  const rateConfig = matrix[activityType];
  const rate = rateConfig[tier];

  if (typeof rate === 'number') {
    // If rate is percentage (< 1), multiply by amount
    if (rate < 1 && amount) {
      return amount * rate;
    }
    // If rate is flat fee
    return rate;
  }

  return 0;
}

// Complete referral and assign commission
export async function completeReferral(
  referralId: string,
  activityType: string,
  transactionAmount?: number
): Promise<Referral | null> {
  const referralStr = await kv.get(`referral:${referralId}`);
  if (!referralStr) return null;

  const referral: Referral = JSON.parse(referralStr);
  const partner = await getPartner(referral.partnerId);
  if (!partner) return null;

  // Calculate commission
  const commission = calculateCommission(
    partner.type,
    partner.tier,
    activityType,
    transactionAmount
  );

  // Update referral
  referral.status = 'completed';
  referral.commissionEarned = commission;
  referral.activityType = activityType;
  referral.transactionAmount = transactionAmount;
  referral.completedAt = new Date().toISOString();

  await kv.set(`referral:${referralId}`, JSON.stringify(referral));

  // Update partner revenue
  await updatePartner(partner.id, {
    revenueGenerated: partner.revenueGenerated + commission
  });

  return referral;
}

// Get all referrals for a partner
export async function getPartnerReferrals(partnerId: string): Promise<Referral[]> {
  const prefix = `referral_by_partner:${partnerId}:`;
  const referralIds = await kv.getByPrefix(prefix);
  
  const referrals: Referral[] = [];
  for (const id of referralIds) {
    const referralStr = await kv.get(`referral:${id}`);
    if (referralStr) {
      referrals.push(JSON.parse(referralStr));
    }
  }

  return referrals.sort((a, b) => 
    new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  );
}

// Get partner statistics
export async function getPartnerStats(partnerId: string): Promise<{
  totalReferrals: number;
  completedReferrals: number;
  pendingReferrals: number;
  totalRevenue: number;
  pendingCommission: number;
  conversionRate: number;
  averageCommission: number;
}> {
  const partner = await getPartner(partnerId);
  if (!partner) {
    throw new Error('Partner not found');
  }

  const referrals = await getPartnerReferrals(partnerId);
  
  const completed = referrals.filter(r => r.status === 'completed');
  const pending = referrals.filter(r => r.status === 'pending');
  
  const totalCommission = completed.reduce((sum, r) => sum + r.commissionEarned, 0);
  const averageCommission = completed.length > 0 ? totalCommission / completed.length : 0;
  const conversionRate = referrals.length > 0 ? (completed.length / referrals.length) * 100 : 0;

  return {
    totalReferrals: referrals.length,
    completedReferrals: completed.length,
    pendingReferrals: pending.length,
    totalRevenue: partner.revenueGenerated,
    pendingCommission: pending.reduce((sum, r) => sum + (r.commissionEarned || 0), 0),
    conversionRate: parseFloat(conversionRate.toFixed(2)),
    averageCommission: parseFloat(averageCommission.toFixed(2))
  };
}

// List all partners
export async function listPartners(
  filters?: {
    type?: Partner['type'];
    tier?: Partner['tier'];
  }
): Promise<Partner[]> {
  const prefix = 'partner:partner_';
  const partnerStrs = await kv.getByPrefix(prefix);
  
  let partners: Partner[] = partnerStrs.map(str => JSON.parse(str));

  // Apply filters
  if (filters?.type) {
    partners = partners.filter(p => p.type === filters.type);
  }
  if (filters?.tier) {
    partners = partners.filter(p => p.tier === filters.tier);
  }

  return partners.sort((a, b) => 
    new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  );
}

// Upgrade partner tier
export async function upgradePartnerTier(
  partnerId: string,
  newTier: Partner['tier']
): Promise<Partner | null> {
  const partner = await getPartner(partnerId);
  if (!partner) return null;

  // Tier hierarchy
  const tierLevels = { bronze: 0, silver: 1, gold: 2, platinum: 3 };
  
  if (tierLevels[newTier] <= tierLevels[partner.tier]) {
    throw new Error('يمكن الترقية فقط لمستوى أعلى');
  }

  return updatePartner(partnerId, { tier: newTier });
}

// University-specific: Bulk student registration
export async function registerUniversityStudents(
  universityPartnerId: string,
  students: Array<{
    email: string;
    name: string;
    studentId: string;
  }>
): Promise<{
  registered: number;
  referralCodes: string[];
}> {
  const partner = await getPartner(universityPartnerId);
  if (!partner || partner.type !== 'university') {
    throw new Error('شريك غير صالح أو ليس جامعة');
  }

  const referralCodes: string[] = [];

  for (const student of students) {
    const userId = `student_${student.studentId}`;
    
    // Track referral
    const referral = await trackReferral(
      partner.referralCode,
      userId,
      'student_subscription',
      100 // Default subscription value
    );

    // Complete referral immediately for universities
    await completeReferral(
      referral.id,
      'student_subscription',
      100
    );

    referralCodes.push(partner.referralCode);
  }

  return {
    registered: students.length,
    referralCodes
  };
}

// Corporate-specific: Bulk employee enrollment
export async function enrollCorporateEmployees(
  corporatePartnerId: string,
  employeeCount: number,
  subscriptionAmount: number
): Promise<{
  enrolled: number;
  totalCommission: number;
}> {
  const partner = await getPartner(corporatePartnerId);
  if (!partner || partner.type !== 'corporate') {
    throw new Error('شريك غير صالح أو ليس شركة');
  }

  const totalAmount = subscriptionAmount * employeeCount;
  const commission = calculateCommission(
    partner.type,
    partner.tier,
    'bulk_subscription',
    totalAmount
  );

  // Create bulk referral
  const referralId = `referral_${Date.now()}_bulk`;
  const referral: Referral = {
    id: referralId,
    partnerId: partner.id,
    userId: `corporate_bulk_${Date.now()}`,
    status: 'completed',
    commissionEarned: commission,
    activityType: 'bulk_subscription',
    transactionAmount: totalAmount,
    createdAt: new Date().toISOString(),
    completedAt: new Date().toISOString()
  };

  await kv.set(`referral:${referralId}`, JSON.stringify(referral));

  // Update partner revenue
  await updatePartner(partner.id, {
    revenueGenerated: partner.revenueGenerated + commission
  });

  return {
    enrolled: employeeCount,
    totalCommission: commission
  };
}

// Generate partner report
export async function generatePartnerReport(
  partnerId: string,
  startDate?: string,
  endDate?: string
): Promise<{
  partner: Partner;
  stats: any;
  referrals: Referral[];
  revenue: {
    total: number;
    byActivity: Record<string, number>;
    byMonth: Record<string, number>;
  };
}> {
  const partner = await getPartner(partnerId);
  if (!partner) {
    throw new Error('Partner not found');
  }

  const stats = await getPartnerStats(partnerId);
  const referrals = await getPartnerReferrals(partnerId);

  // Filter by date if provided
  let filteredReferrals = referrals;
  if (startDate || endDate) {
    filteredReferrals = referrals.filter(r => {
      const refDate = new Date(r.createdAt);
      if (startDate && refDate < new Date(startDate)) return false;
      if (endDate && refDate > new Date(endDate)) return false;
      return true;
    });
  }

  // Revenue by activity type
  const byActivity: Record<string, number> = {};
  filteredReferrals.forEach(r => {
    if (r.status === 'completed' && r.activityType) {
      byActivity[r.activityType] = (byActivity[r.activityType] || 0) + r.commissionEarned;
    }
  });

  // Revenue by month
  const byMonth: Record<string, number> = {};
  filteredReferrals.forEach(r => {
    if (r.status === 'completed') {
      const month = new Date(r.createdAt).toISOString().substring(0, 7);
      byMonth[month] = (byMonth[month] || 0) + r.commissionEarned;
    }
  });

  return {
    partner,
    stats,
    referrals: filteredReferrals,
    revenue: {
      total: partner.revenueGenerated,
      byActivity,
      byMonth
    }
  };
}
