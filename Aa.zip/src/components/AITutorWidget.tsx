import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Send, Sparkles, Loader2, User, Bot, Lightbulb, BookOpen } from 'lucide-react';
import { api } from '../utils/api.tsx';

interface Message {
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
  suggestions?: string[];
}

export function AITutorWidget() {
  const userId = 'user_demo_123';
  
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [quickTip, setQuickTip] = useState('');
  const [progress, setProgress] = useState<any>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Scroll to bottom
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Fetch quick tip
  const fetchQuickTip = async () => {
    try {
      const data = await api.getQuickTip();
      setQuickTip(data.tip);
    } catch (error) {
      console.error('Error fetching quick tip:', error);
      // Set a default tip
      setQuickTip('استمر في التعلم! كل صفقة تداول هي فرصة للتعلم وتحسين مهاراتك.');
    }
  };

  // Fetch learning progress
  const fetchProgress = async () => {
    try {
      const data = await api.getLearningProgress(userId);
      setProgress(data);
    } catch (error) {
      console.error('Error fetching progress:', error);
      // Set default progress
      setProgress({
        knowledgeLevel: 3,
        totalQuestions: 0,
        correctAnswers: 0,
        strongAreas: ['التحليل الأساسي'],
        weakAreas: []
      });
    }
  };

  // Load initial data
  useEffect(() => {
    fetchQuickTip();
    fetchProgress();
    
    // Load conversation history
    loadHistory();
  }, []);

  // Load conversation history
  const loadHistory = async () => {
    try {
      const data = await api.getTutorHistory(userId, 5);
      
      if (data.history && data.history.length > 0) {
        const loadedMessages: Message[] = [];
        for (const entry of data.history) {
          loadedMessages.push({
            role: 'user',
            content: entry.question,
            timestamp: entry.timestamp
          });
          loadedMessages.push({
            role: 'assistant',
            content: entry.response,
            timestamp: entry.timestamp
          });
        }
        setMessages(loadedMessages);
      }
    } catch (error) {
      console.error('Error loading history:', error);
      // No default messages, just leave empty
    }
  };

  // Send message
  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage: Message = {
      role: 'user',
      content: input,
      timestamp: new Date().toISOString()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      const data = await api.askAITutor(userId, input);

      const aiMessage: Message = {
        role: 'assistant',
        content: data.response || 'عذراً، حدث خطأ في معالجة سؤالك.',
        timestamp: new Date().toISOString(),
        suggestions: data.suggestions
      };

      setMessages(prev => [...prev, aiMessage]);
      
      // Update progress
      fetchProgress();
    } catch (error) {
      console.error('Error sending message:', error);
      
      const errorMessage: Message = {
        role: 'assistant',
        content: 'عذراً، حدث خطأ في الاتصال. حاول مرة أخرى.',
        timestamp: new Date().toISOString()
      };
      
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  // Quick questions
  const quickQuestions = [
    'ما هو التداول؟',
    'كيف أبدأ الاستثمار؟',
    'ما هي إدارة المخاطر؟',
    'كيف أحلل السوق؟'
  ];

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="glass-gold rounded-t-2xl p-4">
        <div className="flex items-center gap-3">
          <div className="relative">
            <motion.div
              className="w-12 h-12 rounded-full bg-gradient-to-br from-[#FFD700] to-[#D4AF37] flex items-center justify-center"
              animate={{
                boxShadow: [
                  '0 0 20px rgba(255, 215, 0, 0.5)',
                  '0 0 40px rgba(255, 215, 0, 0.8)',
                  '0 0 20px rgba(255, 215, 0, 0.5)'
                ]
              }}
              transition={{ duration: 2, repeat: Infinity }}
            >
              <Bot className="w-6 h-6 text-black" />
            </motion.div>
            <motion.div
              className="absolute -top-1 -right-1 w-4 h-4 bg-green-500 rounded-full border-2 border-black"
              animate={{ scale: [1, 1.2, 1] }}
              transition={{ duration: 2, repeat: Infinity }}
            />
          </div>
          
          <div>
            <h3 className="font-bold text-[#FFD700]">المساعد التعليمي الذكي</h3>
            <div className="text-xs opacity-70">متصل • جاهز للمساعدة</div>
          </div>
        </div>
      </div>

      {/* Quick Tip */}
      {quickTip && (
        <motion.div
          className="glass rounded-xl p-3 m-4 mb-0"
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
        >
          <div className="flex items-start gap-2">
            <Lightbulb className="w-4 h-4 text-[#FFD700] mt-1 flex-shrink-0" />
            <div className="text-xs opacity-90">{quickTip}</div>
          </div>
        </motion.div>
      )}

      {/* Progress Bar */}
      {progress && (
        <motion.div
          className="glass rounded-xl p-3 m-4 mb-0"
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
        >
          <div className="flex items-center justify-between text-xs mb-2">
            <span>تقدمك التعليمي</span>
            <span className="text-[#FFD700]">المستوى {progress.knowledgeLevel}/10</span>
          </div>
          <div className="h-2 bg-black/30 rounded-full overflow-hidden">
            <motion.div
              className="h-full bg-gradient-to-r from-[#FFD700] to-[#D4AF37]"
              initial={{ width: 0 }}
              animate={{ width: `${(progress.knowledgeLevel / 10) * 100}%` }}
              transition={{ duration: 1, ease: 'easeOut' }}
            />
          </div>
          {progress.strongAreas && progress.strongAreas.length > 0 && (
            <div className="mt-2 text-xs opacity-70">
              نقاط قوة: {progress.strongAreas.slice(0, 2).join('، ')}
            </div>
          )}
        </motion.div>
      )}

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        <AnimatePresence>
          {messages.length === 0 ? (
            <motion.div
              className="text-center py-12"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
            >
              <Bot className="w-16 h-16 mx-auto mb-4 text-[#FFD700] opacity-50" />
              <h4 className="opacity-70 mb-4">مرحباً! كيف يمكنني مساعدتك اليوم؟</h4>
              
              <div className="grid grid-cols-2 gap-2 max-w-md mx-auto">
                {quickQuestions.map((q, i) => (
                  <motion.button
                    key={i}
                    className="glass rounded-xl px-3 py-2 text-sm text-right hover:bg-[#FFD700]/10"
                    onClick={() => setInput(q)}
                    initial={{ scale: 0, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    transition={{ delay: i * 0.1 }}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    {q}
                  </motion.button>
                ))}
              </div>
            </motion.div>
          ) : (
            messages.map((message) => (
              <motion.div
                key={message.timestamp}
                className={`flex gap-3 ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
              >
                {message.role === 'assistant' && (
                  <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#FFD700] to-[#D4AF37] flex items-center justify-center flex-shrink-0">
                    <Bot className="w-4 h-4 text-black" />
                  </div>
                )}

                <div className={`max-w-[80%] ${message.role === 'user' ? 'order-first' : ''}`}>
                  <motion.div
                    className={`rounded-2xl p-4 ${
                      message.role === 'user'
                        ? 'bg-[#FFD700]/20 text-[#FFD700]'
                        : 'glass'
                    }`}
                    whileHover={{ scale: 1.01 }}
                  >
                    <div className="text-sm whitespace-pre-wrap">{message.content}</div>
                  </motion.div>

                  {message.suggestions && message.suggestions.length > 0 && (
                    <div className="mt-2 space-y-1">
                      {message.suggestions.map((suggestion, i) => (
                        <motion.div
                          key={i}
                          className="glass rounded-xl px-3 py-2 text-xs flex items-start gap-2"
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: i * 0.1 }}
                        >
                          <Sparkles className="w-3 h-3 text-[#FFD700] mt-0.5 flex-shrink-0" />
                          <span className="opacity-90">{suggestion}</span>
                        </motion.div>
                      ))}
                    </div>
                  )}

                  <div className="text-xs opacity-50 mt-1 px-2">
                    {new Date(message.timestamp).toLocaleTimeString('ar-SA', {
                      hour: '2-digit',
                      minute: '2-digit'
                    })}
                  </div>
                </div>

                {message.role === 'user' && (
                  <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center flex-shrink-0">
                    <User className="w-4 h-4" />
                  </div>
                )}
              </motion.div>
            ))
          )}
        </AnimatePresence>

        {isLoading && (
          <motion.div
            className="flex gap-3"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
          >
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#FFD700] to-[#D4AF37] flex items-center justify-center">
              <Bot className="w-4 h-4 text-black" />
            </div>
            <div className="glass rounded-2xl p-4">
              <div className="flex gap-1">
                {[0, 1, 2].map((i) => (
                  <motion.div
                    key={i}
                    className="w-2 h-2 bg-[#FFD700] rounded-full"
                    animate={{
                      y: [-3, 3, -3],
                      opacity: [0.5, 1, 0.5]
                    }}
                    transition={{
                      duration: 0.6,
                      repeat: Infinity,
                      delay: i * 0.2
                    }}
                  />
                ))}
              </div>
            </div>
          </motion.div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div className="glass-gold rounded-b-2xl p-4">
        <div className="flex gap-2">
          <input
            type="text"
            className="flex-1 glass rounded-xl py-3 px-4 bg-black/30 border-none outline-none focus:ring-2 focus:ring-[#FFD700]"
            placeholder="اسأل أي سؤال عن التداول والاستثمار..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSend()}
            disabled={isLoading}
          />
          <motion.button
            className="glass rounded-xl px-6 py-3 bg-[#FFD700]/20 disabled:opacity-50"
            onClick={handleSend}
            disabled={!input.trim() || isLoading}
            whileHover={{ scale: input.trim() && !isLoading ? 1.05 : 1 }}
            whileTap={{ scale: input.trim() && !isLoading ? 0.95 : 1 }}
          >
            {isLoading ? (
              <Loader2 className="w-5 h-5 text-[#FFD700] animate-spin" />
            ) : (
              <Send className="w-5 h-5 text-[#FFD700]" />
            )}
          </motion.button>
        </div>
      </div>
    </div>
  );
}