import { createClient } from '@supabase/supabase-js';
import { projectId, publicAnonKey } from './info.tsx';

const supabaseUrl = `https://${projectId}.supabase.co`;

export const supabase = createClient(supabaseUrl, publicAnonKey);

export interface Simulation {
  id: string;
  name: string;
  description: string;
  type: 'stock' | 'real_estate' | 'business_decision';
  creator_id: string;
  is_public: boolean;
  initial_balance: number;
  leverage: number;
  commission_rate: number;
  created_at: string;
  updated_at: string;
}

export interface Trade {
  id: string;
  simulation_id: string;
  user_id: string;
  symbol: string;
  amount: number;
  direction: 'buy' | 'sell';
  entry_price: number;
  exit_price?: number;
  profit?: number;
  status: 'open' | 'closed';
  created_at: string;
  closed_at?: string;
}

export interface RealEstateProperty {
  id: string;
  simulation_id: string;
  location: string;
  current_price: number;
  rental_yield: number;
  growth_rate: number;
  property_type: string;
  size_sqm: number;
}

export interface UserSimulationData {
  id: string;
  user_id: string;
  simulation_id: string;
  current_balance: number;
  total_trades: number;
  winning_trades: number;
  total_profit: number;
  performance_score: number;
  achievements: string[];
}

export interface DecisionScenario {
  id: string;
  title: string;
  description: string;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  scenario_data: any;
  options: any[];
  correct_option_id: string;
  points: number;
}

export interface UserDecisionAttempt {
  id: string;
  user_id: string;
  scenario_id: string;
  selected_option_id: string;
  is_correct: boolean;
  score: number;
  time_taken: number;
  created_at: string;
}
