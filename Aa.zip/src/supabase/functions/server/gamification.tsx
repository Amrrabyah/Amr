import * as kv from './kv_store.tsx';

interface Badge {
  id: string;
  name: string;
  description: string;
  icon: string;
  tier: 'bronze' | 'silver' | 'gold' | 'platinum';
  xpReward: number;
  criteria: Record<string, number>;
  isSecret: boolean;
  createdAt: string;
}

interface XPTransaction {
  id: string;
  userId: string;
  amount: number;
  source: 'content_creation' | 'trading' | 'real_estate' | 'decisions' | 
          'referral' | 'daily_login' | 'badge' | 'event' | 'quiz' | 'video_watch';
  sourceDetails: Record<string, any>;
  timestamp: string;
}

interface UserProgress {
  userId: string;
  totalXP: number;
  level: number;
  badges: string[];
  loginStreak: number;
  lastLoginDate: string;
  stats: {
    videosWatched: number;
    quizzesCompleted: number;
    certificatesEarned: number;
    contentCreated: number;
    tradingProfits: number;
    referrals: number;
  };
  updatedAt: string;
}

interface Leaderboard {
  id: string;
  period: 'daily' | 'weekly' | 'monthly' | 'all-time';
  startDate: string;
  endDate?: string;
  rankings: Array<{
    userId: string;
    username: string;
    score: number;
    position: number;
    avatar?: string;
  }>;
  lastUpdated: string;
}

// XP Configuration
const XP_SOURCES = {
  daily_login: { base: 10, streakBonus: 5 },
  video_watch: { base: 20, completionBonus: 10 },
  quiz_complete: { base: 50, perfectBonus: 25 },
  content_creation: { base: 100, qualityMultiplier: 2 },
  trading: { base: 30, profitBased: true },
  real_estate: { base: 40, roiBased: true },
  decisions: { base: 25, accuracyBased: true },
  referral: { base: 100 },
  badge: { base: 0 }, // Badge reward is defined in badge itself
  event: { base: 0 }
};

// Security limits
const SECURITY_LIMITS = {
  MAX_XP_PER_HOUR: 1000,
  MAX_SAME_SOURCE_PER_HOUR: 10,
  SOURCE_COOLDOWN: 5 * 60 * 1000, // 5 minutes
  FARMING_THRESHOLD: 20
};

// Get or create user progress
export async function getUserProgress(userId: string): Promise<UserProgress> {
  const data = await kv.get(`user_progress:${userId}`);
  
  if (data) {
    return JSON.parse(data);
  }

  // Create new progress
  const progress: UserProgress = {
    userId,
    totalXP: 0,
    level: 1,
    badges: [],
    loginStreak: 0,
    lastLoginDate: '',
    stats: {
      videosWatched: 0,
      quizzesCompleted: 0,
      certificatesEarned: 0,
      contentCreated: 0,
      tradingProfits: 0,
      referrals: 0
    },
    updatedAt: new Date().toISOString()
  };

  await kv.set(`user_progress:${userId}`, JSON.stringify(progress));
  return progress;
}

// Calculate XP for source
function calculateXP(
  source: XPTransaction['source'],
  details: Record<string, any>
): number {
  const config = XP_SOURCES[source];
  if (!config) return 0;

  let xp = config.base;

  // Apply bonuses based on source
  switch (source) {
    case 'daily_login':
      if (details.streakDays) {
        xp += Math.min(details.streakDays * config.streakBonus, 100);
      }
      break;

    case 'video_watch':
      if (details.watchedPercentage >= 100) {
        xp += config.completionBonus;
      }
      break;

    case 'quiz_complete':
      if (details.score === 100) {
        xp += config.perfectBonus;
      }
      break;

    case 'content_creation':
      if (details.quality === 'gold') {
        xp *= config.qualityMultiplier;
      }
      break;

    case 'trading':
      if (config.profitBased && details.profitPercentage) {
        xp += Math.min(details.profitPercentage * 10, 200);
      }
      break;

    case 'decisions':
      if (config.accuracyBased && details.correctness) {
        xp = Math.round(xp * details.correctness);
      }
      break;
  }

  return Math.min(xp, 500); // Max 500 XP per transaction
}

// Check for XP abuse
async function checkXPAbuse(
  userId: string,
  amount: number,
  source: string
): Promise<{ allowed: boolean; reason?: string }> {
  const now = Date.now();
  const oneHourAgo = now - 3600000;

  // Get recent transactions
  const prefix = `xp_transaction_user:${userId}:`;
  const recentTxIds = await kv.getByPrefix(prefix);

  let hourlyTotal = 0;
  let sameSourceCount = 0;
  const recentTimes: number[] = [];

  for (const txId of recentTxIds) {
    const txStr = await kv.get(`xp_transaction:${txId}`);
    if (!txStr) continue;

    const tx: XPTransaction = JSON.parse(txStr);
    const txTime = new Date(tx.timestamp).getTime();

    if (txTime >= oneHourAgo) {
      hourlyTotal += tx.amount;
      
      if (tx.source === source) {
        sameSourceCount++;
      }

      recentTimes.push(txTime);
    }
  }

  // Check hourly limit
  if (hourlyTotal + amount > SECURITY_LIMITS.MAX_XP_PER_HOUR) {
    return {
      allowed: false,
      reason: 'تجاوز الحد الأقصى لـ XP في الساعة'
    };
  }

  // Check same source limit
  if (sameSourceCount >= SECURITY_LIMITS.MAX_SAME_SOURCE_PER_HOUR) {
    return {
      allowed: false,
      reason: 'تكرار نفس المصدر كثيراً'
    };
  }

  // Check for farming patterns (rapid clicks)
  if (recentTimes.length >= 5) {
    const sorted = recentTimes.sort((a, b) => b - a);
    const timeSpan = sorted[0] - sorted[4];
    if (timeSpan < 60000) { // 5 transactions in less than 1 minute
      return {
        allowed: false,
        reason: 'نمط مشبوه في الأنشطة'
      };
    }
  }

  return { allowed: true };
}

// Grant XP
export async function grantXP(
  userId: string,
  source: XPTransaction['source'],
  details: Record<string, any> = {}
): Promise<{ success: boolean; xpGained?: number; newTotal?: number; error?: string }> {
  try {
    // Calculate XP
    const amount = calculateXP(source, details);
    if (amount === 0) {
      return { success: false, error: 'لا يوجد XP لهذا النشاط' };
    }

    // Check for abuse
    const abuseCheck = await checkXPAbuse(userId, amount, source);
    if (!abuseCheck.allowed) {
      return { success: false, error: abuseCheck.reason };
    }

    // Create transaction
    const txId = `xp_tx_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const transaction: XPTransaction = {
      id: txId,
      userId,
      amount,
      source,
      sourceDetails: details,
      timestamp: new Date().toISOString()
    };

    await kv.set(`xp_transaction:${txId}`, JSON.stringify(transaction));
    await kv.set(`xp_transaction_user:${userId}:${txId}`, txId);

    // Update user progress
    const progress = await getUserProgress(userId);
    progress.totalXP += amount;
    progress.level = calculateLevel(progress.totalXP);
    progress.updatedAt = new Date().toISOString();

    // Update stats
    if (source === 'video_watch') progress.stats.videosWatched++;
    if (source === 'quiz_complete') progress.stats.quizzesCompleted++;
    if (source === 'content_creation') progress.stats.contentCreated++;
    if (source === 'referral') progress.stats.referrals++;

    await kv.set(`user_progress:${userId}`, JSON.stringify(progress));

    // Check for badge unlocks
    await checkBadgeUnlocks(userId);

    return {
      success: true,
      xpGained: amount,
      newTotal: progress.totalXP
    };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

// Calculate level from XP
function calculateLevel(xp: number): number {
  // Level formula: level = floor(sqrt(xp / 100))
  return Math.floor(Math.sqrt(xp / 100)) + 1;
}

// Update login streak
export async function updateLoginStreak(userId: string): Promise<{
  streak: number;
  xpGained: number;
}> {
  const progress = await getUserProgress(userId);
  const today = new Date().toISOString().split('T')[0];
  const lastLogin = progress.lastLoginDate.split('T')[0];

  let newStreak = 1;
  
  if (lastLogin) {
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    const yesterdayStr = yesterday.toISOString().split('T')[0];

    if (lastLogin === yesterdayStr) {
      newStreak = progress.loginStreak + 1;
    } else if (lastLogin === today) {
      // Already logged in today
      return { streak: progress.loginStreak, xpGained: 0 };
    }
  }

  progress.loginStreak = newStreak;
  progress.lastLoginDate = new Date().toISOString();
  await kv.set(`user_progress:${userId}`, JSON.stringify(progress));

  // Grant XP
  const result = await grantXP(userId, 'daily_login', { streakDays: newStreak });

  return {
    streak: newStreak,
    xpGained: result.xpGained || 0
  };
}

// Create badge
export async function createBadge(data: {
  name: string;
  description: string;
  icon: string;
  tier: Badge['tier'];
  xpReward: number;
  criteria: Record<string, number>;
  isSecret?: boolean;
}): Promise<Badge> {
  const badgeId = `badge_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

  const badge: Badge = {
    id: badgeId,
    name: data.name,
    description: data.description,
    icon: data.icon,
    tier: data.tier,
    xpReward: data.xpReward,
    criteria: data.criteria,
    isSecret: data.isSecret || false,
    createdAt: new Date().toISOString()
  };

  await kv.set(`badge:${badgeId}`, JSON.stringify(badge));

  return badge;
}

// Get all badges
export async function getAllBadges(): Promise<Badge[]> {
  const prefix = 'badge:badge_';
  const badgeStrs = await kv.getByPrefix(prefix);

  return badgeStrs.map(str => JSON.parse(str));
}

// Check badge unlock criteria
async function checkBadgeUnlocks(userId: string): Promise<string[]> {
  const progress = await getUserProgress(userId);
  const allBadges = await getAllBadges();
  const unlockedBadges: string[] = [];

  for (const badge of allBadges) {
    // Skip if already unlocked
    if (progress.badges.includes(badge.id)) continue;

    let meetsAllCriteria = true;

    for (const [key, requiredValue] of Object.entries(badge.criteria)) {
      let currentValue = 0;

      switch (key) {
        case 'totalXP':
          currentValue = progress.totalXP;
          break;
        case 'level':
          currentValue = progress.level;
          break;
        case 'loginStreak':
          currentValue = progress.loginStreak;
          break;
        case 'videosWatched':
          currentValue = progress.stats.videosWatched;
          break;
        case 'quizzesCompleted':
          currentValue = progress.stats.quizzesCompleted;
          break;
        case 'certificatesEarned':
          currentValue = progress.stats.certificatesEarned;
          break;
        case 'contentCreated':
          currentValue = progress.stats.contentCreated;
          break;
        case 'referrals':
          currentValue = progress.stats.referrals;
          break;
      }

      if (currentValue < requiredValue) {
        meetsAllCriteria = false;
        break;
      }
    }

    if (meetsAllCriteria) {
      unlockedBadges.push(badge.id);
      
      // Add badge to user
      progress.badges.push(badge.id);
      
      // Grant XP reward
      await grantXP(userId, 'badge', { badgeId: badge.id, badgeName: badge.name });
    }
  }

  if (unlockedBadges.length > 0) {
    await kv.set(`user_progress:${userId}`, JSON.stringify(progress));
  }

  return unlockedBadges;
}

// Get user badges
export async function getUserBadges(userId: string): Promise<Badge[]> {
  const progress = await getUserProgress(userId);
  const badges: Badge[] = [];

  for (const badgeId of progress.badges) {
    const badgeStr = await kv.get(`badge:${badgeId}`);
    if (badgeStr) {
      badges.push(JSON.parse(badgeStr));
    }
  }

  return badges;
}

// Update leaderboard
export async function updateLeaderboard(
  period: Leaderboard['period']
): Promise<Leaderboard> {
  const leaderboardId = `leaderboard_${period}_${Date.now()}`;
  
  // Get all users with progress
  const prefix = 'user_progress:';
  const progressStrs = await kv.getByPrefix(prefix);

  const users = progressStrs.map(str => JSON.parse(str) as UserProgress);

  // Filter by period if needed
  let filteredUsers = users;
  const now = new Date();
  
  if (period === 'daily') {
    const today = now.toISOString().split('T')[0];
    // In real app, filter by XP gained today
    filteredUsers = users;
  } else if (period === 'weekly') {
    // Filter by this week
    filteredUsers = users;
  } else if (period === 'monthly') {
    // Filter by this month
    filteredUsers = users;
  }

  // Sort by total XP
  filteredUsers.sort((a, b) => b.totalXP - a.totalXP);

  // Create rankings
  const rankings = filteredUsers.slice(0, 100).map((user, index) => ({
    userId: user.userId,
    username: user.userId.split('_').pop() || 'مستخدم', // Simple username
    score: user.totalXP,
    position: index + 1
  }));

  const leaderboard: Leaderboard = {
    id: leaderboardId,
    period,
    startDate: new Date().toISOString(),
    rankings,
    lastUpdated: new Date().toISOString()
  };

  await kv.set(`leaderboard:${period}`, JSON.stringify(leaderboard));

  return leaderboard;
}

// Get leaderboard
export async function getLeaderboard(
  period: Leaderboard['period']
): Promise<Leaderboard | null> {
  const data = await kv.get(`leaderboard:${period}`);
  return data ? JSON.parse(data) : null;
}

// Get user position in leaderboard
export async function getUserLeaderboardPosition(
  userId: string,
  period: Leaderboard['period']
): Promise<{ position: number; totalUsers: number } | null> {
  const leaderboard = await getLeaderboard(period);
  if (!leaderboard) return null;

  const userRanking = leaderboard.rankings.find(r => r.userId === userId);
  
  if (userRanking) {
    return {
      position: userRanking.position,
      totalUsers: leaderboard.rankings.length
    };
  }

  return null;
}

// Get XP history
export async function getXPHistory(
  userId: string,
  limit: number = 20
): Promise<XPTransaction[]> {
  const prefix = `xp_transaction_user:${userId}:`;
  const txIds = await kv.getByPrefix(prefix);

  const transactions: XPTransaction[] = [];
  for (const txId of txIds) {
    const txStr = await kv.get(`xp_transaction:${txId}`);
    if (txStr) {
      transactions.push(JSON.parse(txStr));
    }
  }

  transactions.sort((a, b) => 
    new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
  );

  return transactions.slice(0, limit);
}

// Initialize default badges
export async function initializeDefaultBadges(): Promise<void> {
  const defaultBadges = [
    {
      name: 'المبتدئ',
      description: 'ابدأ رحلتك التعليمية',
      icon: 'beginner.png',
      tier: 'bronze' as const,
      xpReward: 50,
      criteria: { totalXP: 100 }
    },
    {
      name: 'المتعلم النشط',
      description: 'شاهد 10 فيديوهات',
      icon: 'active-learner.png',
      tier: 'silver' as const,
      xpReward: 100,
      criteria: { videosWatched: 10 }
    },
    {
      name: 'خبير الاختبارات',
      description: 'أكمل 5 اختبارات بنجاح',
      icon: 'quiz-master.png',
      tier: 'gold' as const,
      xpReward: 200,
      criteria: { quizzesCompleted: 5 }
    },
    {
      name: 'المثابر',
      description: 'سجل دخول لمدة 7 أيام متتالية',
      icon: 'persistent.png',
      tier: 'gold' as const,
      xpReward: 250,
      criteria: { loginStreak: 7 }
    },
    {
      name: 'صانع المحتوى',
      description: 'أنشئ 5 محتويات تعليمية',
      icon: 'content-creator.png',
      tier: 'platinum' as const,
      xpReward: 500,
      criteria: { contentCreated: 5 }
    },
    {
      name: 'المحترف',
      description: 'اجمع 5000 XP',
      icon: 'professional.png',
      tier: 'platinum' as const,
      xpReward: 1000,
      criteria: { totalXP: 5000 }
    }
  ];

  for (const badgeData of defaultBadges) {
    await createBadge(badgeData);
  }
}
