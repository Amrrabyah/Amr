import * as kv from './kv_store.tsx';

interface Property {
  id: string;
  location: string;
  type: string;
  currentPrice: number;
  rentalYield: number;
  growthRate: number;
  sizeSqm: number;
  available: boolean;
}

interface PropertyPurchase {
  propertyId: string;
  financingType: 'cash' | 'mortgage';
  downPayment?: number;
}

// Initialize property market
export async function initializePropertyMarket(simulationId: string): Promise<void> {
  const properties: Property[] = [
    {
      id: `prop_${simulationId}_1`,
      location: 'الرياض - حي الملقا',
      type: 'apartment',
      currentPrice: 500000,
      rentalYield: 0.06,
      growthRate: 0.08,
      sizeSqm: 150,
      available: true
    },
    {
      id: `prop_${simulationId}_2`,
      location: 'جدة - الكورنيش',
      type: 'villa',
      currentPrice: 1200000,
      rentalYield: 0.05,
      growthRate: 0.07,
      sizeSqm: 300,
      available: true
    },
    {
      id: `prop_${simulationId}_3`,
      location: 'الدمام - الشاطئ',
      type: 'commercial',
      currentPrice: 800000,
      rentalYield: 0.08,
      growthRate: 0.06,
      sizeSqm: 200,
      available: true
    },
    {
      id: `prop_${simulationId}_4`,
      location: 'الرياض - العليا',
      type: 'penthouse',
      currentPrice: 2000000,
      rentalYield: 0.04,
      growthRate: 0.10,
      sizeSqm: 400,
      available: true
    },
    {
      id: `prop_${simulationId}_5`,
      location: 'مكة - أبراج البيت',
      type: 'apartment',
      currentPrice: 1500000,
      rentalYield: 0.07,
      growthRate: 0.05,
      sizeSqm: 120,
      available: true
    }
  ];

  for (const property of properties) {
    await kv.set(`property:${property.id}`, JSON.stringify(property));
  }
}

// Get available properties
export async function getAvailableProperties(simulationId: string): Promise<Property[]> {
  const prefix = `property:prop_${simulationId}`;
  const propertiesData = await kv.getByPrefix(prefix);
  
  return propertiesData
    .map(p => JSON.parse(p))
    .filter(p => p.available);
}

// Calculate property cost
function calculatePropertyCost(
  property: Property,
  financingType: 'cash' | 'mortgage',
  downPayment?: number
): number {
  if (financingType === 'cash') {
    return property.currentPrice;
  }

  // Mortgage calculation
  const downPaymentAmount = downPayment || property.currentPrice * 0.2; // 20% default
  return downPaymentAmount;
}

// Purchase property
export async function purchaseProperty(
  userId: string,
  simulationId: string,
  purchase: PropertyPurchase
): Promise<{
  success: boolean;
  transactionId?: string;
  newBalance?: number;
  message?: string;
}> {
  try {
    // Get property
    const propertyStr = await kv.get(`property:${purchase.propertyId}`);
    if (!propertyStr) {
      return {
        success: false,
        message: 'العقار غير موجود'
      };
    }

    const property: Property = JSON.parse(propertyStr);

    // Check availability
    if (!property.available) {
      return {
        success: false,
        message: 'العقار غير متوفر حالياً'
      };
    }

    // Calculate cost
    const totalCost = calculatePropertyCost(
      property,
      purchase.financingType,
      purchase.downPayment
    );

    // Check balance
    const balanceKey = `balance:${userId}:${simulationId}`;
    const balanceStr = await kv.get(balanceKey);
    const currentBalance = balanceStr ? parseFloat(balanceStr) : 10000;

    if (totalCost > currentBalance) {
      return {
        success: false,
        message: 'رصيد غير كافي لشراء العقار'
      };
    }

    // Create transaction
    const transactionId = `re_trans_${userId}_${Date.now()}`;
    const transaction = {
      id: transactionId,
      userId,
      simulationId,
      propertyId: purchase.propertyId,
      purchasePrice: property.currentPrice,
      financingType: purchase.financingType,
      downPayment: purchase.downPayment,
      totalCost,
      timestamp: new Date().toISOString(),
      type: 'purchase'
    };

    await kv.set(`re_transaction:${transactionId}`, JSON.stringify(transaction));

    // Update property availability
    property.available = false;
    await kv.set(`property:${purchase.propertyId}`, JSON.stringify(property));

    // Update user balance
    const newBalance = currentBalance - totalCost;
    await kv.set(balanceKey, newBalance.toString());

    // Add to user portfolio
    const portfolioKey = `re_portfolio:${userId}:${simulationId}`;
    const portfolioStr = await kv.get(portfolioKey);
    const portfolio = portfolioStr ? JSON.parse(portfolioStr) : { properties: [] };
    
    portfolio.properties.push({
      propertyId: purchase.propertyId,
      purchaseDate: new Date().toISOString(),
      purchasePrice: property.currentPrice,
      financingType: purchase.financingType,
      currentValue: property.currentPrice,
      totalReturn: 0
    });

    await kv.set(portfolioKey, JSON.stringify(portfolio));

    return {
      success: true,
      transactionId,
      newBalance,
      message: 'تم شراء العقار بنجاح'
    };
  } catch (error) {
    console.error('Error purchasing property:', error);
    return {
      success: false,
      message: 'خطأ في عملية الشراء'
    };
  }
}

// Sell property
export async function sellProperty(
  userId: string,
  simulationId: string,
  propertyId: string
): Promise<{
  success: boolean;
  profit?: number;
  newBalance?: number;
  message?: string;
}> {
  try {
    // Get user portfolio
    const portfolioKey = `re_portfolio:${userId}:${simulationId}`;
    const portfolioStr = await kv.get(portfolioKey);
    
    if (!portfolioStr) {
      return {
        success: false,
        message: 'لا توجد عقارات في المحفظة'
      };
    }

    const portfolio = JSON.parse(portfolioStr);
    const propertyIndex = portfolio.properties.findIndex(
      (p: any) => p.propertyId === propertyId
    );

    if (propertyIndex === -1) {
      return {
        success: false,
        message: 'العقار غير موجود في محفظتك'
      };
    }

    const ownedProperty = portfolio.properties[propertyIndex];

    // Get current property data
    const propertyStr = await kv.get(`property:${propertyId}`);
    if (!propertyStr) {
      return {
        success: false,
        message: 'بيانات العقار غير موجودة'
      };
    }

    const property: Property = JSON.parse(propertyStr);

    // Calculate appreciation (simulate market growth)
    const monthsHeld = Math.floor(
      (Date.now() - new Date(ownedProperty.purchaseDate).getTime()) / (1000 * 60 * 60 * 24 * 30)
    );
    const appreciation = property.currentPrice * (property.growthRate / 12) * monthsHeld;
    const rentalIncome = property.currentPrice * property.rentalYield * (monthsHeld / 12);
    
    const currentValue = property.currentPrice + appreciation;
    const profit = currentValue - ownedProperty.purchasePrice + rentalIncome;

    // Create sale transaction
    const transactionId = `re_trans_${userId}_${Date.now()}`;
    const transaction = {
      id: transactionId,
      userId,
      simulationId,
      propertyId,
      salePrice: currentValue,
      profit,
      timestamp: new Date().toISOString(),
      type: 'sale'
    };

    await kv.set(`re_transaction:${transactionId}`, JSON.stringify(transaction));

    // Update property availability
    property.available = true;
    await kv.set(`property:${propertyId}`, JSON.stringify(property));

    // Update balance
    const balanceKey = `balance:${userId}:${simulationId}`;
    const balanceStr = await kv.get(balanceKey);
    const currentBalance = balanceStr ? parseFloat(balanceStr) : 10000;
    const newBalance = currentBalance + currentValue;
    
    await kv.set(balanceKey, newBalance.toString());

    // Remove from portfolio
    portfolio.properties.splice(propertyIndex, 1);
    await kv.set(portfolioKey, JSON.stringify(portfolio));

    return {
      success: true,
      profit,
      newBalance,
      message: 'تم بيع العقار بنجاح'
    };
  } catch (error) {
    console.error('Error selling property:', error);
    return {
      success: false,
      message: 'خطأ في عملية البيع'
    };
  }
}

// Get user portfolio
export async function getUserPortfolio(
  userId: string,
  simulationId: string
): Promise<any> {
  const portfolioKey = `re_portfolio:${userId}:${simulationId}`;
  const portfolioStr = await kv.get(portfolioKey);
  
  if (!portfolioStr) {
    return { properties: [], totalValue: 0, totalReturn: 0 };
  }

  const portfolio = JSON.parse(portfolioStr);
  
  // Calculate current values
  let totalValue = 0;
  let totalReturn = 0;

  for (const prop of portfolio.properties) {
    const propertyStr = await kv.get(`property:${prop.propertyId}`);
    if (propertyStr) {
      const property: Property = JSON.parse(propertyStr);
      
      const monthsHeld = Math.floor(
        (Date.now() - new Date(prop.purchaseDate).getTime()) / (1000 * 60 * 60 * 24 * 30)
      );
      const appreciation = property.currentPrice * (property.growthRate / 12) * monthsHeld;
      const rentalIncome = property.currentPrice * property.rentalYield * (monthsHeld / 12);
      
      const currentValue = property.currentPrice + appreciation;
      const returnAmount = currentValue - prop.purchasePrice + rentalIncome;
      
      prop.currentValue = currentValue;
      prop.totalReturn = returnAmount;
      prop.rentalIncome = rentalIncome;
      prop.appreciation = appreciation;
      
      totalValue += currentValue;
      totalReturn += returnAmount;
    }
  }

  portfolio.totalValue = totalValue;
  portfolio.totalReturn = totalReturn;

  return portfolio;
}

// Analyze portfolio performance
export async function analyzePortfolioPerformance(
  userId: string,
  simulationId: string
): Promise<any> {
  const portfolio = await getUserPortfolio(userId, simulationId);
  
  if (portfolio.properties.length === 0) {
    return {
      message: 'لا توجد عقارات في المحفظة',
      metrics: {}
    };
  }

  // Calculate metrics
  const totalInvested = portfolio.properties.reduce(
    (sum: number, p: any) => sum + p.purchasePrice,
    0
  );
  
  const roi = ((portfolio.totalValue - totalInvested) / totalInvested) * 100;
  
  // Geographic distribution
  const locationDistribution: Record<string, number> = {};
  for (const prop of portfolio.properties) {
    const propertyStr = await kv.get(`property:${prop.propertyId}`);
    if (propertyStr) {
      const property: Property = JSON.parse(propertyStr);
      const location = property.location.split(' - ')[0];
      locationDistribution[location] = (locationDistribution[location] || 0) + 1;
    }
  }

  // Type distribution
  const typeDistribution: Record<string, number> = {};
  for (const prop of portfolio.properties) {
    const propertyStr = await kv.get(`property:${prop.propertyId}`);
    if (propertyStr) {
      const property: Property = JSON.parse(propertyStr);
      typeDistribution[property.type] = (typeDistribution[property.type] || 0) + 1;
    }
  }

  return {
    totalInvested,
    currentValue: portfolio.totalValue,
    totalReturn: portfolio.totalReturn,
    roi: roi.toFixed(2),
    propertyCount: portfolio.properties.length,
    locationDistribution,
    typeDistribution,
    averageReturn: (portfolio.totalReturn / portfolio.properties.length).toFixed(2),
    suggestions: generateRealEstateSuggestions(portfolio, roi)
  };
}

// Generate AI suggestions
function generateRealEstateSuggestions(portfolio: any, roi: number): string[] {
  const suggestions: string[] = [];

  if (roi < 5) {
    suggestions.push('💡 معدل العائد منخفض. فكر في التنويع في مواقع ذات نمو أعلى');
  }

  if (portfolio.properties.length < 3) {
    suggestions.push('📊 قم بتنويع المحفظة بإضافة عقارات في مواقع مختلفة');
  }

  if (portfolio.properties.every((p: any) => p.financingType === 'cash')) {
    suggestions.push('🏦 استخدم التمويل العقاري لزيادة القوة الشرائية');
  }

  if (roi > 15) {
    suggestions.push('🎯 أداء ممتاز! حافظ على استراتيجيتك الحالية');
  }

  return suggestions;
}
