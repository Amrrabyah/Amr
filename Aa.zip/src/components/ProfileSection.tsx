import { motion } from 'motion/react';
import { Award, TrendingUp, Target, Zap, Crown, Star, Trophy } from 'lucide-react';

interface Badge {
  id: number;
  name: string;
  description: string;
  earned: boolean;
  earnedDate?: string;
  tier: 'bronze' | 'silver' | 'gold';
  icon: string;
}

const badges: Badge[] = [
  {
    id: 1,
    name: 'المبتدئ الذكي',
    description: 'أكمل أول درس',
    earned: true,
    earnedDate: '2024-01-15',
    tier: 'bronze',
    icon: '🌟',
  },
  {
    id: 2,
    name: 'المتداول المحترف',
    description: 'حقق 10 صفقات ناجحة',
    earned: true,
    earnedDate: '2024-02-20',
    tier: 'silver',
    icon: '💼',
  },
  {
    id: 3,
    name: 'أسطورة السوق',
    description: 'حقق عائد 100%',
    earned: true,
    earnedDate: '2024-03-10',
    tier: 'gold',
    icon: '👑',
  },
  {
    id: 4,
    name: 'خبير التحليل',
    description: 'استخدم جميع أدوات التحليل',
    earned: false,
    tier: 'gold',
    icon: '📊',
  },
  {
    id: 5,
    name: 'المعلم الصاعد',
    description: 'ساعد 50 متعلماً',
    earned: false,
    tier: 'silver',
    icon: '🎓',
  },
  {
    id: 6,
    name: 'الماسترو المالي',
    description: 'أكمل جميع الدورات',
    earned: false,
    tier: 'gold',
    icon: '🏆',
  },
];

const skills = [
  { name: 'التحليل الفني', level: 85, color: '#FFD700' },
  { name: 'إدارة المخاطر', level: 72, color: '#00D4FF' },
  { name: 'التحليل الأساسي', level: 90, color: '#FF6B6B' },
  { name: 'علم النفس التجاري', level: 68, color: '#4ECDC4' },
  { name: 'إدارة المحفظة', level: 78, color: '#95E1D3' },
];

export function ProfileSection() {
  const tierColors = {
    bronze: '#CD7F32',
    silver: '#C0C0C0',
    gold: '#FFD700',
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <motion.div
        className="glass-gold rounded-3xl p-8 relative overflow-hidden"
        initial={{ y: -50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
      >
        {/* Decorative pattern */}
        <div className="absolute inset-0 opacity-10">
          <div
            className="w-full h-full"
            style={{
              backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23FFD700' fill-opacity='1'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
            }}
          />
        </div>

        <div className="relative z-10 flex items-start gap-8">
          {/* Avatar with orbiting achievements */}
          <div className="relative">
            {/* Main avatar */}
            <motion.div
              className="relative w-32 h-32 rounded-3xl overflow-hidden"
              style={{
                background: 'linear-gradient(135deg, #FFD700, #D4AF37)',
                padding: 4,
              }}
              whileHover={{ scale: 1.05 }}
            >
              <div className="w-full h-full rounded-3xl bg-gradient-to-br from-gray-700 to-gray-900 flex items-center justify-center text-6xl">
                👤
              </div>
            </motion.div>

            {/* Orbiting icons */}
            {[
              { icon: '⭐', delay: 0 },
              { icon: '💎', delay: 1 },
              { icon: '🏆', delay: 2 },
            ].map((item, i) => (
              <motion.div
                key={i}
                className="absolute top-1/2 left-1/2 w-8 h-8 flex items-center justify-center bg-[#FFD700] rounded-full text-lg"
                style={{
                  transformOrigin: '0 0',
                }}
                animate={{
                  rotate: [0, 360],
                  x: [0, 60 * Math.cos((i * 2 * Math.PI) / 3)],
                  y: [0, 60 * Math.sin((i * 2 * Math.PI) / 3)],
                }}
                transition={{
                  duration: 4,
                  repeat: Infinity,
                  ease: "linear",
                  delay: item.delay,
                }}
              >
                {item.icon}
              </motion.div>
            ))}
          </div>

          {/* Info */}
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-2">
              <h2 className="text-[#FFD700]">محمد الخبير المالي</h2>
              <motion.div
                animate={{ rotate: [0, 15, -15, 0] }}
                transition={{ duration: 2, repeat: Infinity }}
              >
                <Crown className="w-8 h-8 text-[#FFD700]" />
              </motion.div>
            </div>
            <p className="opacity-80 mb-4">متداول محترف • خبير في التحليل الفني</p>

            {/* Level bar */}
            <div className="glass rounded-xl p-4">
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm">المستوى 25</span>
                <span className="text-sm text-[#FFD700]">المستوى التالي: 2,500 XP</span>
              </div>
              <div className="relative h-3 bg-black/50 rounded-full overflow-hidden">
                <motion.div
                  className="absolute inset-y-0 right-0 rounded-full"
                  style={{
                    background: 'linear-gradient(90deg, #D4AF37, #FFD700, #FFED4E)',
                  }}
                  initial={{ width: 0 }}
                  animate={{ width: '75%' }}
                  transition={{ duration: 1.5, ease: "easeOut" }}
                />
              </div>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Badges Gallery */}
      <div>
        <h3 className="text-[#FFD700] mb-6 flex items-center gap-3">
          <Trophy className="w-8 h-8" />
          قاعة الشارات
        </h3>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {badges.map((badge, index) => (
            <motion.div
              key={badge.id}
              className="group relative"
              initial={{ scale: 0, rotate: -180 }}
              animate={{ scale: 1, rotate: 0 }}
              transition={{ delay: index * 0.1, type: "spring" }}
              whileHover={{ scale: 1.1, rotate: 5 }}
            >
              <motion.div
                className={`glass-gold rounded-2xl p-6 text-center relative overflow-hidden ${
                  !badge.earned ? 'opacity-40 grayscale' : ''
                }`}
                animate={{
                  boxShadow: badge.earned
                    ? [
                        `0 0 20px ${tierColors[badge.tier]}44`,
                        `0 0 40px ${tierColors[badge.tier]}66`,
                        `0 0 20px ${tierColors[badge.tier]}44`,
                      ]
                    : 'none',
                }}
                transition={{ duration: 2, repeat: Infinity }}
              >
                {/* Shine effect for earned badges */}
                {badge.earned && (
                  <motion.div
                    className="absolute inset-0"
                    style={{
                      background: 'linear-gradient(45deg, transparent, rgba(255,255,255,0.2), transparent)',
                    }}
                    animate={{
                      x: ['-100%', '200%'],
                    }}
                    transition={{
                      duration: 2,
                      repeat: Infinity,
                      repeatDelay: 3,
                    }}
                  />
                )}

                <motion.div
                  className="text-5xl mb-3"
                  animate={
                    badge.earned
                      ? { rotate: [0, 10, -10, 10, 0] }
                      : {}
                  }
                  transition={{ duration: 0.5 }}
                >
                  {badge.icon}
                </motion.div>

                <div className="text-sm font-bold mb-1">{badge.name}</div>
                <div className="text-xs opacity-70">{badge.description}</div>

                {badge.earned && badge.earnedDate && (
                  <div className="mt-2 text-xs" style={{ color: tierColors[badge.tier] }}>
                    {badge.earnedDate}
                  </div>
                )}

                {/* Badge tier indicator */}
                <div
                  className="absolute top-2 left-2 w-3 h-3 rounded-full"
                  style={{ backgroundColor: tierColors[badge.tier] }}
                />
              </motion.div>

              {/* Hover tooltip */}
              <motion.div
                className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 glass-gold rounded-lg p-2 text-xs whitespace-nowrap opacity-0 pointer-events-none group-hover:opacity-100 transition-opacity"
                style={{ zIndex: 50 }}
              >
                {badge.earned ? `🎉 تم الحصول عليها!` : '🔒 لم يتم الحصول عليها بعد'}
              </motion.div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Skills Heatmap */}
      <div>
        <h3 className="text-[#FFD700] mb-6 flex items-center gap-3">
          <Zap className="w-8 h-8" />
          الخريطة الحرارية للمهارات
        </h3>
        <div className="glass rounded-2xl p-8 space-y-6">
          {skills.map((skill, index) => (
            <motion.div
              key={index}
              initial={{ x: -100, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ delay: index * 0.1 }}
            >
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm">{skill.name}</span>
                <motion.span
                  className="text-sm font-bold"
                  style={{ color: skill.color }}
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: index * 0.1 + 0.5, type: "spring" }}
                >
                  {skill.level}%
                </motion.span>
              </div>
              <div className="relative h-4 bg-black/50 rounded-full overflow-hidden">
                <motion.div
                  className="absolute inset-y-0 right-0 rounded-full"
                  style={{
                    backgroundColor: skill.color,
                    boxShadow: `0 0 20px ${skill.color}66`,
                  }}
                  initial={{ width: 0 }}
                  animate={{ width: `${skill.level}%` }}
                  transition={{ delay: index * 0.1 + 0.3, duration: 1, ease: "easeOut" }}
                />
                {/* Animated particles */}
                <motion.div
                  className="absolute inset-0"
                  style={{
                    background: `linear-gradient(90deg, transparent, ${skill.color}88, transparent)`,
                  }}
                  animate={{
                    x: ['-100%', '200%'],
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                    delay: index * 0.3,
                  }}
                />
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
