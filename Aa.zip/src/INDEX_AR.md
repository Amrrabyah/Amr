# 📖 الفهرس الشامل - أكاديمية الذهب المالية

## 🎯 نظرة عامة

**أكاديمية الذهب المالية** هي منصة تعليمية متكاملة تجمع بين:
- 🎮 محاكاة واقعية (تداول، عقارات، قرارات)
- 🤖 ذكاء اصطناعي متقدم
- 🎓 محتوى تعليمي شامل
- 🏆 نظام تحفيز ديناميكي
- 🤝 شراكات استراتيجية

---

## 📚 الأدلة التقنية

### 1️⃣ أدلة الأنظمة الأساسية

| الملف | الوصف | المحتوى |
|------|-------|---------|
| [`BACKEND_README.md`](./BACKEND_README.md) | دليل نظام Backend | محاكاة التداول والعقارات والقرارات |
| [`AI_FEATURES_README.md`](./AI_FEATURES_README.md) | دليل أنظمة AI | المساعد الذكي والتوصيات والتحليلات |
| [`PARTNERSHIPS_README.md`](./PARTNERSHIPS_README.md) | دليل نظام الشراكات | الجامعات والبنوك والشركات والمؤثرين |
| [`CONTENT_GAMIFICATION_README.md`](./CONTENT_GAMIFICATION_README.md) | دليل المحتوى والتحفيز | الفيديوهات والاختبارات والشهادات و XP |

### 2️⃣ شرح آلية العمل

| الملف | الوصف |
|------|-------|
| [`HOW_IT_WORKS_AR.md`](./HOW_IT_WORKS_AR.md) | شرح تفصيلي لكيفية عمل كل نظام (الجزء 1) |
| [`HOW_IT_WORKS_AR_PART2.md`](./HOW_IT_WORKS_AR_PART2.md) | شرح تفصيلي لكيفية عمل كل نظام (الجزء 2) |

### 3️⃣ سجلات الإصلاحات

| الملف | الوصف |
|------|-------|
| [`FIXES_LOG.md`](./FIXES_LOG.md) | سجل الإصلاحات وحل المشاكل |

---

## 🗂️ هيكل المشروع

```
📦 أكاديمية الذهب المالية
│
├── 📁 /components          # مكونات React
│   ├── EnhancedTradingSimulator.tsx
│   ├── RealEstateSimulator.tsx
│   ├── DecisionScenarioGame.tsx
│   ├── AITutorWidget.tsx
│   ├── ProfileDashboard.tsx
│   ├── LeaderboardPanel.tsx
│   └── PartnerDashboard.tsx
│
├── 📁 /supabase/functions/server  # Backend APIs
│   ├── index.tsx           # Router رئيسي
│   ├── kv_store.tsx        # قاعدة البيانات
│   ├── trading.tsx         # محاكاة التداول
│   ├── realEstate.tsx      # محاكاة العقارات
│   ├── decisions.tsx       # تمارين القرارات
│   ├── aiTutor.tsx         # المساعد الذكي
│   ├── recommendations.tsx # التوصيات
│   ├── analytics.tsx       # التحليلات
│   ├── partnerships.tsx    # الشراكات
│   ├── content.tsx         # المحتوى التعليمي
│   └── gamification.tsx    # نظام التحفيز
│
├── 📁 /utils               # أدوات مساعدة
│   ├── api.tsx             # نظام API موحد
│   └── supabase/           # إعدادات Supabase
│
├── 📁 /styles              # التصميم
│   └── globals.css         # الأنماط العامة
│
└── 📄 /                    # التوثيق
    ├── BACKEND_README.md
    ├── AI_FEATURES_README.md
    ├── PARTNERSHIPS_README.md
    ├── CONTENT_GAMIFICATION_README.md
    ├── HOW_IT_WORKS_AR.md
    ├── HOW_IT_WORKS_AR_PART2.md
    ├── FIXES_LOG.md
    └── INDEX_AR.md (هذا الملف)
```

---

## 🚀 البدء السريع

### 1. فهم الأنظمة
```bash
# ابدأ بقراءة شرح آلية العمل
1. اقرأ HOW_IT_WORKS_AR.md (الجزء 1)
2. اقرأ HOW_IT_WORKS_AR_PART2.md (الجزء 2)
```

### 2. استكشاف APIs
```bash
# ثم راجع الأدلة التقنية حسب الحاجة
- BACKEND_README.md      → للمحاكاة
- AI_FEATURES_README.md  → للذكاء الاصطناعي
- PARTNERSHIPS_README.md → للشراكات
- CONTENT_GAMIFICATION_README.md → للمحتوى والتحفيز
```

### 3. حل المشاكل
```bash
# إذا واجهت مشكلة
- راجع FIXES_LOG.md للحلول المعروفة
```

---

## 📊 الأنظمة العشرة

### 🎮 أنظمة المحاكاة (3)
1. **محاكاة التداول** - تدرب على الأسهم بأموال افتراضية
2. **محاكاة العقارات** - استثمر في عقارات افتراضية
3. **تمارين القرارات** - اختبر قدرتك على اتخاذ القرار

### 🤖 أنظمة الذكاء الاصطناعي (3)
4. **المساعد الذكي** - أجب عن أسئلتك الفورية
5. **نظام التوصيات** - محتوى مخصص لك
6. **نظام التحليلات** - تحليل شامل لأدائك

### 🎓 أنظمة التعليم والتحفيز (2)
7. **نظام المحتوى** - فيديوهات واختبارات وشهادات
8. **نظام التحفيز** - XP ومستويات وشارات

### 🤝 أنظمة الأعمال (2)
9. **نظام الشراكات** - إدارة الشراكات مع المؤسسات
10. **نظام التكامل** - ربط جميع الأنظمة

---

## 🔑 المفاهيم الأساسية

### 1. نظام XP (نقاط الخبرة)
```
مصادر XP:
├── تسجيل دخول يومي: 10-45 XP
├── مشاهدة فيديو: 20-30 XP
├── إكمال اختبار: 50-75 XP
├── صفقة رابحة: 30-230 XP
├── قرار صحيح: 25-95 XP
├── إحالة صديق: 100 XP
└── فتح شارة: 50-1000 XP

المستويات:
Level = floor(sqrt(XP / 100)) + 1

أمثلة:
- 100 XP = Level 2
- 1,600 XP = Level 5
- 10,000 XP = Level 11
```

### 2. نظام الحماية
```
حدود الأمان:
├── Max XP/hour: 1,000
├── Max same source: 10/hour
├── Cooldown: 5 minutes
├── Farming detection: 5 actions/minute
└── IP tracking: تتبع النشاط المشبوه
```

### 3. نظام الشراكات
```
أنواع الشراكات:
├── 🎓 Universit (جامعات)
├── 🏦 Bank (بنوك)
├── 🏢 Corporate (شركات)
└── 📱 Influencer (مؤثرون)

مستويات العمولة:
├── Bronze: 5-8%
├── Silver: 8-12%
├── Gold: 12-15%
└── Platinum: 15-20%
```

### 4. نظام التوصيات
```
معايير التوصية:
├── الاهتمامات (30%)
├── مستوى المعرفة (20%)
├── نمط التعلم (15%)
├── الوقت المتاح (10%)
├── الشعبية (15%)
└── التقييمات (10%)
```

---

## 📈 أمثلة الاستخدام

### مثال 1: رحلة طالب
```
يوم 1:
├── تسجيل عبر كود الجامعة → نظام الشراكات
├── مشاهدة فيديو → نظام المحتوى + XP
└── AI يقترح محتوى مناسب → نظام التوصيات

يوم 7:
├── سلسلة دخول 7 أيام → شارة "المثابر"
├── إكمال اختبار → شهادة + XP
└── المستوى 4 → فتح محتوى متقدم

شهر 1:
├── 150 صفقة تداول → إحصائيات مفصلة
├── تقرير أداء شامل → نظام التحليلات
└── المركز #28 → لوحة الصدارة
```

### مثال 2: رحلة شريك (جامعة)
```
شهر 1:
├── تسجيل كشريك → Bronze tier
├── 30 طالب انضموا → 750 ريال عمولة
└── عداد الإحالات: 30

شهر 3:
├── 65 طالب → ترقية لـ Silver
├── عمولة جديدة: 8%
└── مكافأة ترقية: +500 ريال

شهر 6:
├── 220 طالب → ترقية لـ Gold
├── عمولة: 12%
└── إجمالي العمولات: 10,200 ريال
```

---

## 🛠️ API Endpoints (ملخص)

### التداول (6 endpoints)
```
GET  /market/:symbol
POST /trading/open
POST /trading/close
GET  /trading/stats/:userId/:simulationId
GET  /trading/history/:userId/:simulationId
GET  /trading/balance/:userId/:simulationId
```

### العقارات (6 endpoints)
```
POST /realestate/init/:simulationId
GET  /realestate/properties/:simulationId
POST /realestate/purchase
POST /realestate/sell
GET  /realestate/portfolio/:userId/:simulationId
POST /realestate/update/:simulationId
```

### القرارات (5 endpoints)
```
POST /decisions/init
GET  /decisions/scenario
POST /decisions/submit
GET  /decisions/stats/:userId
GET  /decisions/recommendations/:userId
```

### AI (9 endpoints)
```
POST /ai/tutor/ask
GET  /ai/tutor/history/:userId
GET  /ai/tutor/progress/:userId
GET  /ai/tutor/tip
GET  /ai/recommendations/:userId
POST /ai/track
GET  /ai/learning-path/:userId/:goal
GET  /ai/trending
GET  /ai/search
```

### التحليلات (3 endpoints)
```
GET /ai/analytics/report/:userId/:simulationId
GET /ai/analytics/risk/:userId/:simulationId
GET /ai/analytics/summary/:userId
```

### الشراكات (16 endpoints)
```
POST /partners/create
GET  /partners/:partnerId
GET  /partners/code/:referralCode
GET  /partners
PUT  /partners/:partnerId
POST /partners/:partnerId/upgrade
POST /partners/referrals/track
GET  /partners/:partnerId/referrals
GET  /partners/:partnerId/stats
GET  /partners/:partnerId/report
POST /partners/university/:partnerId/students
POST /partners/bank/:partnerId/accounts
POST /partners/corporate/:partnerId/employees
GET  /partners/influencer/:partnerId/metrics
POST /partners/influencer/:partnerId/content
POST /partners/referrals/:referralId/complete
```

### المحتوى (13 endpoints)
```
POST /content/videos/create
GET  /content/videos/:videoId
GET  /content/videos
POST /content/videos/:videoId/view
POST /content/videos/:videoId/rate
POST /content/quizzes/create
GET  /content/quizzes/:quizId
POST /content/quizzes/:quizId/start
POST /content/quizzes/sessions/:sessionId/answer
POST /content/quizzes/sessions/:sessionId/complete
GET  /content/certificates/:userId
GET  /content/certificates/verify/:code
GET  /content/recommendations/:userId
```

### التحفيز (11 endpoints)
```
GET  /gamification/progress/:userId
POST /gamification/xp/grant
POST /gamification/login/:userId
GET  /gamification/xp/history/:userId
POST /gamification/badges/create
GET  /gamification/badges
GET  /gamification/badges/:userId
POST /gamification/leaderboard/update/:period
GET  /gamification/leaderboard/:period
GET  /gamification/leaderboard/:period/position/:userId
POST /gamification/init
```

**إجمالي: 69+ API endpoint**

---

## 💡 نصائح للمطورين

### 1. استخدام نظام API الموحد
```typescript
// ✅ صحيح
import { api } from './utils/api.tsx';
const data = await api.getMarketPrice('AAPL');

// ❌ خطأ
const res = await fetch(`${API_URL}/market/AAPL`);
```

### 2. معالجة الأخطاء
```typescript
try {
  const data = await api.someFunction();
  // استخدام البيانات
} catch (error) {
  console.error('Error:', error);
  // عرض رسالة للمستخدم
  // النظام سيستخدم mock data تلقائياً
}
```

### 3. البيانات التجريبية
```typescript
// النظام يعمل في وضعين:
// 1. مع Backend متصل: بيانات حقيقية
// 2. بدون Backend: mock data تلقائياً
```

---

## 🔍 البحث في الوثائق

### ابحث عن موضوع معين:

**للتداول:** راجع `BACKEND_README.md` → قسم Trading  
**للعقارات:** راجع `BACKEND_README.md` → قسم Real Estate  
**للقرارات:** راجع `BACKEND_README.md` → قسم Decisions  
**للـ AI:** راجع `AI_FEATURES_README.md`  
**للشراكات:** راجع `PARTNERSHIPS_README.md`  
**للمحتوى:** راجع `CONTENT_GAMIFICATION_README.md`  
**للتحفيز:** راجع `CONTENT_GAMIFICATION_README.md`  

### فهم كيف يعمل:
راجع `HOW_IT_WORKS_AR.md` و `HOW_IT_WORKS_AR_PART2.md`

---

## ❓ الأسئلة الشائعة

### س: كيف أبدأ؟
ج: اقرأ `HOW_IT_WORKS_AR.md` لفهم الأنظمة، ثم راجع الأدلة التقنية حسب احتياجك.

### س: أين أجد أمثلة الكود؟
ج: كل دليل يحتوي على أمثلة عملية كاملة.

### س: كيف أحل مشكلة معينة؟
ج: راجع `FIXES_LOG.md` أولاً، وإذا لم تجد الحل استخدم console.log لفحص البيانات.

### س: هل يعمل النظام بدون Backend؟
ج: نعم! النظام يستخدم mock data تلقائياً إذا لم يكن Backend متاحاً.

### س: كيف أضيف feature جديدة؟
ج: 
1. أضف الـ function في الـ server المناسب
2. أضف endpoint في `index.tsx`
3. أضف helper function في `utils/api.tsx`
4. استخدمها في المكون

---

## 📞 الدعم

للأسئلة أو المساعدة:
- راجع الوثائق أولاً
- استخدم console.log للـ debugging
- راجع `FIXES_LOG.md` للمشاكل المعروفة

---

**تم البناء بحب من فريق أكاديمية الذهب المالية** 🏆✨

*آخر تحديث: 5 ديسمبر 2024*
