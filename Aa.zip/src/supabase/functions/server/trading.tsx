import { createClient } from 'jsr:@supabase/supabase-js@2';
import * as kv from './kv_store.tsx';

const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
);

interface TradeRequest {
  simulationId: string;
  symbol: string;
  amount: number;
  direction: 'buy' | 'sell';
}

// Get current market price (simulated)
export async function getMarketPrice(symbol: string): Promise<number> {
  const cached = await kv.get(`market:${symbol}`);
  if (cached) {
    return parseFloat(cached);
  }

  // Generate realistic price movement
  const basePrice = 100;
  const volatility = 0.02;
  const randomChange = (Math.random() - 0.5) * 2 * volatility;
  const price = basePrice * (1 + randomChange);
  
  // Cache for 5 seconds
  await kv.set(`market:${symbol}`, price.toString(), { expiresIn: 5 });
  
  return price;
}

// Validate trade
export async function validateTrade(
  userId: string,
  tradeRequest: TradeRequest
): Promise<{ valid: boolean; message?: string; currentPrice?: number }> {
  try {
    // Get user's current balance
    const balanceKey = `balance:${userId}:${tradeRequest.simulationId}`;
    const balanceStr = await kv.get(balanceKey);
    const currentBalance = balanceStr ? parseFloat(balanceStr) : 10000;

    // Get current market price
    const currentPrice = await getMarketPrice(tradeRequest.symbol);
    
    // Calculate trade cost
    const tradeCost = currentPrice * tradeRequest.amount;
    const commission = tradeCost * 0.001; // 0.1% commission
    const totalCost = tradeCost + commission;

    // Check if user has enough balance
    if (tradeRequest.direction === 'buy' && totalCost > currentBalance) {
      return {
        valid: false,
        message: 'رصيد غير كافي لتنفيذ الصفقة',
        currentPrice
      };
    }

    // Anti-cheat: Check trade frequency
    const tradeCountKey = `trade_count:${userId}:${Date.now() / 60000 | 0}`;
    const tradeCount = await kv.get(tradeCountKey);
    if (tradeCount && parseInt(tradeCount) > 10) {
      return {
        valid: false,
        message: 'تم تجاوز الحد الأقصى للصفقات في الدقيقة',
        currentPrice
      };
    }

    // Anti-cheat: Check suspicious amounts
    const avgKey = `avg_trade:${userId}`;
    const avgStr = await kv.get(avgKey);
    const avgAmount = avgStr ? parseFloat(avgStr) : tradeRequest.amount;
    
    if (tradeRequest.amount > avgAmount * 10) {
      return {
        valid: false,
        message: 'حجم الصفقة غير طبيعي',
        currentPrice
      };
    }

    return {
      valid: true,
      currentPrice
    };
  } catch (error) {
    console.error('Error validating trade:', error);
    return {
      valid: false,
      message: 'خطأ في التحقق من الصفقة'
    };
  }
}

// Execute trade
export async function executeTrade(
  userId: string,
  tradeRequest: TradeRequest
): Promise<{
  success: boolean;
  tradeId?: string;
  newBalance?: number;
  message?: string;
}> {
  try {
    // Validate trade first
    const validation = await validateTrade(userId, tradeRequest);
    if (!validation.valid) {
      return {
        success: false,
        message: validation.message
      };
    }

    const currentPrice = validation.currentPrice!;
    const tradeCost = currentPrice * tradeRequest.amount;
    const commission = tradeCost * 0.001;
    
    // Get current balance
    const balanceKey = `balance:${userId}:${tradeRequest.simulationId}`;
    const balanceStr = await kv.get(balanceKey);
    const currentBalance = balanceStr ? parseFloat(balanceStr) : 10000;

    // Calculate new balance
    let newBalance = currentBalance;
    if (tradeRequest.direction === 'buy') {
      newBalance -= (tradeCost + commission);
    } else {
      newBalance += (tradeCost - commission);
    }

    // Generate trade ID
    const tradeId = `trade_${userId}_${Date.now()}`;

    // Save trade
    const trade = {
      id: tradeId,
      userId,
      simulationId: tradeRequest.simulationId,
      symbol: tradeRequest.symbol,
      amount: tradeRequest.amount,
      direction: tradeRequest.direction,
      entryPrice: currentPrice,
      commission,
      status: 'open',
      timestamp: new Date().toISOString()
    };

    await kv.set(`trade:${tradeId}`, JSON.stringify(trade));

    // Update balance
    await kv.set(balanceKey, newBalance.toString());

    // Update trade count (for anti-cheat)
    const tradeCountKey = `trade_count:${userId}:${Date.now() / 60000 | 0}`;
    const currentCount = await kv.get(tradeCountKey);
    await kv.set(
      tradeCountKey,
      (currentCount ? parseInt(currentCount) + 1 : 1).toString(),
      { expiresIn: 60 }
    );

    // Update average trade amount
    const avgKey = `avg_trade:${userId}`;
    const avgStr = await kv.get(avgKey);
    const currentAvg = avgStr ? parseFloat(avgStr) : tradeRequest.amount;
    const newAvg = (currentAvg + tradeRequest.amount) / 2;
    await kv.set(avgKey, newAvg.toString());

    return {
      success: true,
      tradeId,
      newBalance,
      message: 'تم تنفيذ الصفقة بنجاح'
    };
  } catch (error) {
    console.error('Error executing trade:', error);
    return {
      success: false,
      message: 'خطأ في تنفيذ الصفقة'
    };
  }
}

// Close trade
export async function closeTrade(
  userId: string,
  tradeId: string
): Promise<{
  success: boolean;
  profit?: number;
  newBalance?: number;
  message?: string;
}> {
  try {
    // Get trade
    const tradeStr = await kv.get(`trade:${tradeId}`);
    if (!tradeStr) {
      return {
        success: false,
        message: 'الصفقة غير موجودة'
      };
    }

    const trade = JSON.parse(tradeStr);
    
    // Verify ownership
    if (trade.userId !== userId) {
      return {
        success: false,
        message: 'غير مصرح لك بإغلاق هذه الصفقة'
      };
    }

    // Check if already closed
    if (trade.status === 'closed') {
      return {
        success: false,
        message: 'الصفقة مغلقة بالفعل'
      };
    }

    // Get current market price
    const exitPrice = await getMarketPrice(trade.symbol);
    
    // Calculate profit
    let profit = 0;
    if (trade.direction === 'buy') {
      profit = (exitPrice - trade.entryPrice) * trade.amount;
    } else {
      profit = (trade.entryPrice - exitPrice) * trade.amount;
    }
    
    // Subtract commission
    profit -= trade.commission;

    // Update trade
    trade.exitPrice = exitPrice;
    trade.profit = profit;
    trade.status = 'closed';
    trade.closedAt = new Date().toISOString();
    
    await kv.set(`trade:${tradeId}`, JSON.stringify(trade));

    // Update balance
    const balanceKey = `balance:${userId}:${trade.simulationId}`;
    const balanceStr = await kv.get(balanceKey);
    const currentBalance = balanceStr ? parseFloat(balanceStr) : 10000;
    const newBalance = currentBalance + profit;
    
    await kv.set(balanceKey, newBalance.toString());

    // Update statistics
    await updateUserStats(userId, trade.simulationId, profit);

    return {
      success: true,
      profit,
      newBalance,
      message: 'تم إغلاق الصفقة بنجاح'
    };
  } catch (error) {
    console.error('Error closing trade:', error);
    return {
      success: false,
      message: 'خطأ في إغلاق الصفقة'
    };
  }
}

// Update user statistics
async function updateUserStats(
  userId: string,
  simulationId: string,
  profit: number
): Promise<void> {
  const statsKey = `stats:${userId}:${simulationId}`;
  const statsStr = await kv.get(statsKey);
  
  const stats = statsStr ? JSON.parse(statsStr) : {
    totalTrades: 0,
    winningTrades: 0,
    totalProfit: 0,
    maxDrawdown: 0,
    winRate: 0
  };

  stats.totalTrades += 1;
  if (profit > 0) {
    stats.winningTrades += 1;
  }
  stats.totalProfit += profit;
  stats.winRate = (stats.winningTrades / stats.totalTrades) * 100;

  // Calculate max drawdown
  if (profit < 0 && Math.abs(profit) > stats.maxDrawdown) {
    stats.maxDrawdown = Math.abs(profit);
  }

  await kv.set(statsKey, JSON.stringify(stats));
}

// Get user statistics
export async function getUserStats(
  userId: string,
  simulationId: string
): Promise<any> {
  const statsKey = `stats:${userId}:${simulationId}`;
  const statsStr = await kv.get(statsKey);
  
  if (!statsStr) {
    return {
      totalTrades: 0,
      winningTrades: 0,
      totalProfit: 0,
      maxDrawdown: 0,
      winRate: 0
    };
  }

  return JSON.parse(statsStr);
}

// Get trade history
export async function getTradeHistory(
  userId: string,
  simulationId: string
): Promise<any[]> {
  const prefix = `trade:${userId}`;
  const trades = await kv.getByPrefix(prefix);
  
  return trades
    .map(t => JSON.parse(t))
    .filter(t => t.simulationId === simulationId)
    .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
}
