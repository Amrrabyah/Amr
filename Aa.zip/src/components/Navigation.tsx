import { motion } from 'motion/react';
import { Home, TrendingUp, User, BookOpen, Trophy, Sparkles } from 'lucide-react';

interface NavigationProps {
  currentSection: string;
  onSectionChange: (section: string) => void;
}

const navItems = [
  { id: 'home', label: 'الرئيسية', icon: Home },
  { id: 'trading', label: 'المحاكاة', icon: TrendingUp },
  { id: 'library', label: 'المكتبة', icon: BookOpen },
  { id: 'profile', label: 'الملف الشخصي', icon: User },
  { id: 'leaderboard', label: 'المتصدرون', icon: Trophy },
];

export function Navigation({ currentSection, onSectionChange }: NavigationProps) {
  return (
    <motion.nav
      className="fixed top-8 right-8 left-8 z-50 glass-gold rounded-2xl p-4"
      initial={{ y: -100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ type: 'spring', stiffness: 200 }}
    >
      <div className="flex items-center justify-between">
        {/* Logo */}
        <motion.div
          className="flex items-center gap-3"
          whileHover={{ scale: 1.05 }}
        >
          <motion.div
            className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#FFD700] to-[#D4AF37] flex items-center justify-center"
            animate={{ rotate: [0, 5, -5, 0] }}
            transition={{ duration: 2, repeat: Infinity }}
          >
            <Sparkles className="w-6 h-6 text-black" />
          </motion.div>
          <div>
            <div className="font-bold text-[#FFD700]">أكاديمية الذهب المالية</div>
            <div className="text-xs opacity-70">منصة التعليم الاستثماري</div>
          </div>
        </motion.div>

        {/* Nav Items */}
        <div className="flex items-center gap-2">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentSection === item.id;

            return (
              <motion.button
                key={item.id}
                className={`relative px-6 py-3 rounded-xl transition-all ${
                  isActive ? 'glass-gold' : 'glass'
                }`}
                onClick={() => onSectionChange(item.id)}
                whileHover={{ scale: 1.05, y: -2 }}
                whileTap={{ scale: 0.95 }}
              >
                {isActive && (
                  <motion.div
                    className="absolute inset-0 rounded-xl bg-[#FFD700]/20"
                    layoutId="activeTab"
                    transition={{ type: 'spring', stiffness: 300, damping: 30 }}
                  />
                )}

                <div className="relative z-10 flex items-center gap-2">
                  <Icon
                    className={`w-5 h-5 ${
                      isActive ? 'text-[#FFD700]' : 'text-white/70'
                    }`}
                  />
                  <span
                    className={`text-sm ${
                      isActive ? 'text-[#FFD700] font-bold' : 'text-white/70'
                    }`}
                  >
                    {item.label}
                  </span>
                </div>

                {isActive && (
                  <motion.div
                    className="absolute -bottom-1 left-1/2 transform -translate-x-1/2 w-1/2 h-0.5 bg-[#FFD700]"
                    layoutId="activeIndicator"
                    transition={{ type: 'spring', stiffness: 300, damping: 30 }}
                  />
                )}
              </motion.button>
            );
          })}
        </div>

        {/* User Badge */}
        <motion.div
          className="glass-gold rounded-xl px-4 py-2 flex items-center gap-3 cursor-pointer"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          <div className="text-right">
            <div className="text-sm font-bold">محمد الخبير</div>
            <div className="text-xs text-[#FFD700]">المستوى 25</div>
          </div>
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#FFD700] to-[#D4AF37] flex items-center justify-center">
            👤
          </div>
          <motion.div
            className="w-2 h-2 rounded-full bg-green-500"
            animate={{ scale: [1, 1.3, 1] }}
            transition={{ duration: 2, repeat: Infinity }}
          />
        </motion.div>
      </div>
    </motion.nav>
  );
}
