# 🤝 دليل نظام الشراكات - أكاديمية الذهب المالية

## 🌟 نظرة عامة

نظام شراكات متكامل يربط المنصة مع:
- 🎓 **الجامعات** - برامج تدريب الطلاب
- 🏦 **البنوك** - منتجات مالية متكاملة
- 🏢 **الشركات** - تدريب الموظفين
- ⭐ **المؤثرين** - تسويق بالعمولة

---

## 📋 أنواع الشركاء

### 1. 🎓 الجامعات (University Partners)

#### الفوائد
- تدريب الطلاب على المهارات المالية
- شهادات مشتركة معتمدة
- عمولات على كل طالب مسجل

#### معدلات العمولة
| المستوى | تسجيل طالب | إصدار شهادة | اشتراك شهري |
|---------|-----------|-------------|-------------|
| Bronze | 10% | $50 | $100 |
| Silver | 15% | $75 | $150 |
| Gold | 20% | $100 | $200 |
| Platinum | 25% | $150 | $300 |

#### مثال التكامل
```typescript
// تسجيل دفعة من الطلاب
const result = await fetch(`${API_URL}/partners/university/${partnerId}/students`, {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${publicAnonKey}`
  },
  body: JSON.stringify({
    students: [
      { email: 'student1@uni.edu', name: 'أحمد محمد', studentId: 'STU001' },
      { email: 'student2@uni.edu', name: 'فاطمة علي', studentId: 'STU002' }
    ]
  })
});

// Response:
{
  "registered": 2,
  "referralCodes": ["UNI-ABC123", "UNI-ABC123"]
}
```

---

### 2. 🏦 البنوك (Bank Partners)

#### الفوائد
- ربط الحسابات البنكية
- تقديم منتجات مالية (قروض، استثمارات)
- عمولات على كل معاملة

#### معدلات العمولة
| المستوى | فتح حساب | قرض | منتج استثماري |
|---------|---------|-----|---------------|
| Bronze | $200 | 1% | 5% |
| Silver | $300 | 1.5% | 7.5% |
| Gold | $500 | 2% | 10% |
| Platinum | $1000 | 2.5% | 15% |

#### مثال الاستخدام
```typescript
// تتبع فتح حساب جديد
await fetch(`${API_URL}/partners/referrals/track`, {
  method: 'POST',
  body: JSON.stringify({
    referralCode: 'BAN-XYZ789',
    userId: 'user_12345',
    activityType: 'account_opening',
    transactionAmount: 200
  })
});

// إكمال الإحالة وحساب العمولة
await fetch(`${API_URL}/partners/referrals/${referralId}/complete`, {
  method: 'POST',
  body: JSON.stringify({
    activityType: 'account_opening',
    transactionAmount: 200
  })
});
```

---

### 3. 🏢 الشركات (Corporate Partners)

#### الفوائد
- تدريب الموظفين جماعياً
- خصومات خاصة للشركات
- تقارير أداء مفصلة

#### معدلات العمولة
| المستوى | اشتراك جماعي | إحالة موظف | برنامج تدريبي |
|---------|-------------|-----------|---------------|
| Bronze | 15% | $100 | 12% |
| Silver | 20% | $150 | 18% |
| Gold | 25% | $200 | 25% |
| Platinum | 30% | $300 | 35% |

#### مثال الاستخدام
```typescript
// تسجيل دفعة من الموظفين
const result = await fetch(`${API_URL}/partners/corporate/${partnerId}/employees`, {
  method: 'POST',
  body: JSON.stringify({
    employeeCount: 50,
    subscriptionAmount: 100 // لكل موظف
  })
});

// Response:
{
  "enrolled": 50,
  "totalCommission": 750 // (50 × 100) × 0.15 for Bronze tier
}
```

---

### 4. ⭐ المؤثرين (Influencer Partners)

#### الفوائد
- روابط تتبع فريدة
- عمولات على كل تسجيل وشراء
- مكافآت إضافية للأداء المميز

#### معدلات العمولة
| المستوى | تسجيل مستخدم | تحويل مدفوع | شراء دورة |
|---------|-------------|------------|----------|
| Bronze | $50 | 20% | 15% |
| Silver | $75 | 25% | 20% |
| Gold | $100 | 30% | 25% |
| Platinum | $150 | 40% | 35% |

---

## 🎯 مستويات الشراكة (Tiers)

### 🥉 Bronze (البرونزية)
- عمولات أساسية (10-15%)
- لوحة تحكم بسيطة
- دعم عبر البريد الإلكتروني
- تقارير شهرية

### 🥈 Silver (الفضية)
- عمولات متوسطة (15-20%)
- لوحة تحكم متقدمة
- دعم أولوية
- تقارير أسبوعية
- **شرط الترقية**: 10+ إحالات مكتملة

### 🥇 Gold (الذهبية)
- عمولات عالية (20-25%)
- لوحة تحكم كاملة
- دعم فوري 24/7
- تقارير لحظية
- مدير حساب مخصص
- **شرط الترقية**: 50+ إحالات + $5000 إيرادات

### 💎 Platinum (البلاتينية)
- عمولات فائقة (25-40%)
- جميع المميزات
- API مخصص
- استشارات استراتيجية مجانية
- حملات تسويقية مشتركة
- **شرط الترقية**: 100+ إحالات + $20000 إيرادات

---

## 🔧 API Endpoints

### إنشاء شريك جديد
```http
POST /partners/create
Content-Type: application/json

{
  "name": "جامعة الملك سعود",
  "type": "university",
  "tier": "bronze",
  "contact": {
    "email": "partnerships@ksu.edu.sa",
    "phone": "+966501234567",
    "representative": "د. أحمد العتيبي"
  },
  "customBenefits": {
    "discountRate": 20,
    "maxStudents": 1000
  },
  "agreementTerms": "شروط الاتفاقية..."
}

// Response:
{
  "id": "partner_1234567890_abc123",
  "referralCode": "UNI-A1B2C3",
  ...
}
```

### الحصول على بيانات الشريك
```http
GET /partners/:partnerId
GET /partners/code/:referralCode
```

### قائمة الشركاء
```http
GET /partners?type=university&tier=gold

// Response:
{
  "partners": [...]
}
```

### تحديث بيانات الشريك
```http
PUT /partners/:partnerId
Content-Type: application/json

{
  "contact": {
    "phone": "+966509876543"
  }
}
```

### ترقية المستوى
```http
POST /partners/:partnerId/upgrade
Content-Type: application/json

{
  "newTier": "silver"
}
```

### تتبع إحالة
```http
POST /partners/referrals/track
Content-Type: application/json

{
  "referralCode": "UNI-A1B2C3",
  "userId": "user_demo_123",
  "activityType": "course_enrollment",
  "transactionAmount": 500
}
```

### إكمال الإحالة (حساب العمولة)
```http
POST /partners/referrals/:referralId/complete
Content-Type: application/json

{
  "activityType": "course_enrollment",
  "transactionAmount": 500
}
```

### إحصائيات الشريك
```http
GET /partners/:partnerId/stats

// Response:
{
  "totalReferrals": 145,
  "completedReferrals": 132,
  "pendingReferrals": 13,
  "totalRevenue": 15750.50,
  "pendingCommission": 1250.00,
  "conversionRate": 91.03,
  "averageCommission": 119.32
}
```

### تقرير الشريك
```http
GET /partners/:partnerId/report?startDate=2024-01-01&endDate=2024-12-31

// Response:
{
  "partner": {...},
  "stats": {...},
  "referrals": [...],
  "revenue": {
    "total": 15750.50,
    "byActivity": {
      "course_enrollment": 8500,
      "student_subscription": 7250.50
    },
    "byMonth": {
      "2024-01": 1200,
      "2024-02": 1500,
      ...
    }
  }
}
```

### إحالات الشريك
```http
GET /partners/:partnerId/referrals

// Response:
{
  "referrals": [
    {
      "id": "referral_...",
      "userId": "user_...",
      "status": "completed",
      "commissionEarned": 125.50,
      "activityType": "course_enrollment",
      "createdAt": "2024-01-15T10:30:00Z"
    },
    ...
  ]
}
```

---

## 💰 حساب العمولات

### خوارزمية الحساب

```typescript
function calculateCommission(
  partnerType: 'university' | 'bank' | 'corporate' | 'influencer',
  tier: 'bronze' | 'silver' | 'gold' | 'platinum',
  activityType: string,
  amount?: number
): number {
  const matrix = COMMISSION_MATRIX[partnerType][activityType];
  const rate = matrix[tier];
  
  // نسبة مئوية
  if (rate < 1 && amount) {
    return amount * rate;
  }
  
  // مبلغ ثابت
  return rate;
}
```

### أمثلة حسابية

#### مثال 1: جامعة - تسجيل طالب
```typescript
Partner: University (Gold Tier)
Activity: student_subscription
Amount: $100

Commission = $100 × 0.20 = $20
```

#### مثال 2: بنك - قرض
```typescript
Partner: Bank (Platinum Tier)
Activity: loan_issuance
Amount: $50,000

Commission = $50,000 × 0.025 = $1,250
```

#### مثال 3: شركة - اشتراك جماعي
```typescript
Partner: Corporate (Silver Tier)
Activity: bulk_subscription
Amount: 100 employees × $100 = $10,000

Commission = $10,000 × 0.20 = $2,000
```

---

## 📊 لوحة تحكم الشريك

### المكونات الرئيسية

1. **نظرة عامة**
   - إجمالي الإيرادات
   - عدد الإحالات
   - معدل التحويل
   - متوسط العمولة

2. **كود الإحالة**
   - كود فريد قابل للنسخ
   - رابط تتبع مخصص
   - QR Code

3. **مميزات المستوى**
   - قائمة المميزات الحالية
   - شروط الترقية للمستوى التالي
   - مقارنة المستويات

4. **الإحالات**
   - جدول الإحالات الأخيرة
   - فلترة حسب الحالة والتاريخ
   - تفاصيل كل إحالة

5. **أدوات التسويق**
   - بانرات جاهزة
   - قوالب بريد إلكتروني
   - فيديوهات ترويجية

### مثال الاستخدام

```tsx
import { PartnerDashboard } from './components/PartnerDashboard';

function App() {
  return (
    <PartnerDashboard partnerId="partner_1234567890_abc123" />
  );
}
```

---

## 🔐 الأمان والضوابط

### حماية كود الإحالة
- ✅ أكواد فريدة غير قابلة للتكرار
- ✅ تشفير في قاعدة البيانات
- ✅ معدل محاولات محدود (Rate Limiting)

### منع الاحتيال
- ✅ تتبع IP للإحالات
- ✅ كشف الأنماط المشبوهة
- ✅ مراجعة يدوية للإحالات الكبيرة

### الشفافية
- ✅ سجل كامل لجميع العمليات
- ✅ تقارير قابلة للتحقق
- ✅ إشعارات لحظية

---

## 📈 نماذج أرباح متوقعة

### جامعة متوسطة (Silver Tier)
```
50 طالب/شهر × $150 عمولة = $7,500/شهر
× 10 أشهر دراسية = $75,000/سنة
```

### بنك كبير (Platinum Tier)
```
100 حساب/شهر × $1000 = $100,000/شهر
+ 10 قروض/شهر × $1,250 متوسط = $12,500/شهر
= $112,500/شهر × 12 = $1,350,000/سنة
```

### شركة متوسطة (Gold Tier)
```
200 موظف × $200 عمولة أولية = $40,000
+ تجديدات سنوية: 200 × $100 × 0.25 = $5,000/شهر
= $100,000 أول سنة + $60,000 سنوياً بعدها
```

### مؤثر نشط (Gold Tier)
```
500 تسجيل/شهر × $100 = $50,000/شهر
+ 50 تحويل مدفوع × $200 متوسط × 0.30 = $3,000/شهر
= $53,000/شهر × 12 = $636,000/سنة
```

---

## 🎯 خطوات البدء كشريك

### 1. التسجيل
```bash
POST /partners/create
# احصل على referralCode
```

### 2. إعداد الحساب
- أكمل بيانات الاتصال
- حدد المميزات المطلوبة
- وقّع الاتفاقية

### 3. ابدأ التسويق
- شارك كود الإحالة
- استخدم أدوات التسويق المتاحة
- تابع الأداء من لوحة التحكم

### 4. اجمع العمولات
- تُحسب العمولات تلقائياً
- تُدفع شهرياً
- تقارير مفصلة

---

## 📞 الدعم الفني

### للاستفسارات
- 📧 partnerships@goldacademy.com
- 📱 +966 50 123 4567
- 💬 الدردشة الحية (مستوى Gold وأعلى)

### ساعات العمل
- الأحد - الخميس: 9 صباحاً - 6 مساءً
- دعم فوري 24/7 (Platinum فقط)

---

**تم البناء بحب لشركائنا الأعزاء** 🤝✨
