import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { LineChart, Line, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { TrendingUp, TrendingDown, Clock, AlertCircle, Check, X } from 'lucide-react';

interface Decision {
  id: number;
  question: string;
  options: { label: string; correct: boolean; impact: number }[];
  timeLimit: number;
}

const mockData = [
  { time: '09:00', price: 100 },
  { time: '10:00', price: 105 },
  { time: '11:00', price: 103 },
  { time: '12:00', price: 110 },
  { time: '13:00', price: 108 },
  { time: '14:00', price: 115 },
  { time: '15:00', price: 112 },
];

const decisions: Decision[] = [
  {
    id: 1,
    question: 'السهم يظهر اتجاهاً صعودياً. ما هو قرارك؟',
    options: [
      { label: 'شراء فوري', correct: true, impact: 15 },
      { label: 'الانتظار والمراقبة', correct: false, impact: 5 },
      { label: 'بيع المحفظة', correct: false, impact: -10 },
    ],
    timeLimit: 15,
  },
  {
    id: 2,
    question: 'تقرير أرباح إيجابي صدر للتو. ما استراتيجيتك؟',
    options: [
      { label: 'زيادة الاستثمار', correct: true, impact: 20 },
      { label: 'جني الأرباح', correct: false, impact: 8 },
      { label: 'عدم التحرك', correct: false, impact: 0 },
    ],
    timeLimit: 12,
  },
];

export function TradingSimulator() {
  const [balance, setBalance] = useState(10000);
  const [currentDecision, setCurrentDecision] = useState(0);
  const [timeLeft, setTimeLeft] = useState(15);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [score, setScore] = useState(0);

  useEffect(() => {
    if (showResult || currentDecision >= decisions.length) return;

    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          handleTimeout();
          return decisions[currentDecision]?.timeLimit || 15;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [timeLeft, showResult, currentDecision]);

  const handleTimeout = () => {
    setShowResult(true);
    setTimeout(() => {
      moveToNextDecision();
    }, 2000);
  };

  const handleOptionSelect = (index: number) => {
    if (showResult) return;
    
    setSelectedOption(index);
    const option = decisions[currentDecision].options[index];
    
    setShowResult(true);
    setBalance((prev) => prev + option.impact);
    setScore((prev) => prev + (option.correct ? 100 : 0));

    setTimeout(() => {
      moveToNextDecision();
    }, 2000);
  };

  const moveToNextDecision = () => {
    setSelectedOption(null);
    setShowResult(false);
    setCurrentDecision((prev) => prev + 1);
    setTimeLeft(decisions[currentDecision + 1]?.timeLimit || 15);
  };

  const urgencyColor = timeLeft > 10 ? '#FFD700' : timeLeft > 5 ? '#FFA500' : '#FF4444';
  const decision = decisions[currentDecision];

  if (currentDecision >= decisions.length) {
    return (
      <motion.div
        className="glass-gold rounded-3xl p-12 text-center"
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ type: "spring" }}
      >
        <motion.div
          className="text-6xl mb-6"
          animate={{ rotate: [0, 10, -10, 0], scale: [1, 1.2, 1] }}
          transition={{ duration: 0.5 }}
        >
          🏆
        </motion.div>
        <h2 className="text-[#FFD700] mb-4">تم إكمال المحاكاة!</h2>
        <div className="space-y-4">
          <div className="glass rounded-xl p-6">
            <div className="text-sm opacity-70 mb-2">الرصيد النهائي</div>
            <div className="text-4xl font-bold text-[#FFD700]">
              ${balance.toLocaleString('en-US')}
            </div>
          </div>
          <div className="glass rounded-xl p-6">
            <div className="text-sm opacity-70 mb-2">النقاط المكتسبة</div>
            <div className="text-4xl font-bold text-[#FFD700]">{score}</div>
          </div>
        </div>
      </motion.div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header Stats */}
      <div className="grid grid-cols-3 gap-4">
        <div className="glass-gold rounded-xl p-4">
          <div className="text-xs opacity-70 mb-1">الرصيد</div>
          <motion.div
            className="text-2xl font-bold text-[#FFD700]"
            key={balance}
            initial={{ scale: 1.2 }}
            animate={{ scale: 1 }}
          >
            ${balance.toLocaleString('en-US')}
          </motion.div>
        </div>
        <div className="glass-gold rounded-xl p-4">
          <div className="text-xs opacity-70 mb-1">النقاط</div>
          <div className="text-2xl font-bold text-[#FFD700]">{score}</div>
        </div>
        <div className="glass-gold rounded-xl p-4">
          <div className="text-xs opacity-70 mb-1">القرار</div>
          <div className="text-2xl font-bold text-[#FFD700]">
            {currentDecision + 1}/{decisions.length}
          </div>
        </div>
      </div>

      {/* Chart */}
      <motion.div
        className="glass rounded-2xl p-6"
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
      >
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={mockData}>
              <defs>
                <linearGradient id="goldGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#FFD700" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#FFD700" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
              <XAxis dataKey="time" stroke="rgba(255,255,255,0.5)" />
              <YAxis stroke="rgba(255,255,255,0.5)" />
              <Tooltip
                contentStyle={{
                  backgroundColor: 'rgba(10,10,10,0.9)',
                  border: '1px solid #FFD700',
                  borderRadius: '8px',
                }}
              />
              <Area
                type="monotone"
                dataKey="price"
                stroke="#FFD700"
                strokeWidth={3}
                fill="url(#goldGradient)"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* News ticker */}
        <motion.div
          className="mt-4 glass-gold rounded-lg p-3 overflow-hidden"
          animate={{ opacity: [0.7, 1, 0.7] }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          <div className="flex items-center gap-2 text-sm">
            <AlertCircle className="w-4 h-4 text-[#FFD700]" />
            <motion.div
              animate={{ x: [0, -100] }}
              transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
              className="whitespace-nowrap"
            >
              📈 السوق في اتجاه صعودي • 💹 مؤشرات إيجابية • 🔔 تقرير أرباح قادم
            </motion.div>
          </div>
        </motion.div>
      </motion.div>

      {/* Decision Panel */}
      <motion.div
        className="glass-gold rounded-2xl p-8 relative overflow-hidden"
        style={{
          backgroundColor: `rgba(255, ${Math.max(215 - (15 - timeLeft) * 10, 0)}, 0, 0.1)`,
        }}
        animate={{
          boxShadow:
            timeLeft <= 5
              ? ['0 0 0px rgba(255,0,0,0)', '0 0 30px rgba(255,0,0,0.5)']
              : '0 0 0px rgba(255,0,0,0)',
        }}
        transition={{ duration: 0.5, repeat: timeLeft <= 5 ? Infinity : 0 }}
      >
        {/* Timer Circle */}
        <div className="absolute top-8 left-8">
          <div className="relative w-24 h-24">
            <svg className="transform -rotate-90 w-24 h-24">
              <circle
                cx="48"
                cy="48"
                r="40"
                stroke="rgba(255,255,255,0.1)"
                strokeWidth="6"
                fill="none"
              />
              <motion.circle
                cx="48"
                cy="48"
                r="40"
                stroke={urgencyColor}
                strokeWidth="6"
                fill="none"
                strokeLinecap="round"
                strokeDasharray={251.2}
                strokeDashoffset={251.2 * (1 - timeLeft / (decision?.timeLimit || 15))}
                animate={{
                  strokeDashoffset: 251.2 * (1 - timeLeft / (decision?.timeLimit || 15)),
                }}
              />
            </svg>
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-center">
                <Clock className="w-6 h-6 mx-auto mb-1" style={{ color: urgencyColor }} />
                <div className="text-xl font-bold" style={{ color: urgencyColor }}>
                  {timeLeft}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Question */}
        <div className="mr-32 mb-8">
          <h3 className="text-[#FFD700] mb-2">قرار استثماري</h3>
          <p className="text-lg">{decision?.question}</p>
        </div>

        {/* Options */}
        <div className="space-y-4">
          <AnimatePresence mode="wait">
            {decision?.options.map((option, index) => (
              <motion.button
                key={index}
                className="w-full glass rounded-xl p-6 text-right relative overflow-hidden group"
                onClick={() => handleOptionSelect(index)}
                disabled={showResult}
                initial={{ x: -50, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ scale: showResult ? 1 : 1.02, x: showResult ? 0 : -10 }}
                whileTap={{ scale: 0.98 }}
                style={{
                  borderWidth: 2,
                  borderColor:
                    showResult && selectedOption === index
                      ? option.correct
                        ? '#00FF00'
                        : '#FF0000'
                      : 'transparent',
                }}
              >
                <motion.div
                  className="absolute inset-0"
                  style={{
                    background: 'linear-gradient(90deg, rgba(255,215,0,0.1), transparent)',
                  }}
                  initial={{ x: '-100%' }}
                  whileHover={{ x: '0%' }}
                  transition={{ duration: 0.3 }}
                />

                <div className="relative z-10 flex items-center justify-between">
                  <span className="text-lg">{option.label}</span>
                  
                  {showResult && selectedOption === index && (
                    <motion.div
                      initial={{ scale: 0, rotate: -180 }}
                      animate={{ scale: 1, rotate: 0 }}
                      transition={{ type: "spring", stiffness: 200 }}
                    >
                      {option.correct ? (
                        <Check className="w-6 h-6 text-green-500" />
                      ) : (
                        <X className="w-6 h-6 text-red-500" />
                      )}
                    </motion.div>
                  )}
                </div>

                {showResult && selectedOption === index && (
                  <motion.div
                    className="mt-2 text-sm"
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                  >
                    التأثير على الرصيد:{' '}
                    <span
                      className="font-bold"
                      style={{ color: option.impact > 0 ? '#00FF00' : '#FF0000' }}
                    >
                      {option.impact > 0 ? '+' : ''}${option.impact}
                    </span>
                  </motion.div>
                )}
              </motion.button>
            ))}
          </AnimatePresence>
        </div>
      </motion.div>
    </div>
  );
}
