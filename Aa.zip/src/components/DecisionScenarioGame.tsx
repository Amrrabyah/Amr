import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Brain, Clock, TrendingUp, AlertCircle, CheckCircle, XCircle, Lightbulb } from 'lucide-react';
import { API_URL } from '../utils/api.tsx';
import { publicAnonKey } from '../utils/supabase/info.tsx';

interface DecisionOption {
  id: string;
  text: string;
  impact: number;
  explanation: string;
}

interface Scenario {
  id: string;
  title: string;
  description: string;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  context: string;
  question: string;
  options: DecisionOption[];
  points: number;
  category: string;
}

export function DecisionScenarioGame() {
  const userId = 'user_demo_123';

  const [scenario, setScenario] = useState<Scenario | null>(null);
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [timeLeft, setTimeLeft] = useState(60);
  const [startTime, setStartTime] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [stats, setStats] = useState({
    totalAttempts: 0,
    correctAttempts: 0,
    totalScore: 0,
    accuracy: 0
  });
  const [recommendations, setRecommendations] = useState<string[]>([]);

  // Initialize scenarios
  const initScenarios = async () => {
    try {
      await fetch(`${API_URL}/decisions/init`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`
        }
      });
    } catch (error) {
      console.error('Error initializing scenarios:', error);
    }
  };

  // Fetch scenario
  const fetchScenario = async (difficulty?: string) => {
    setLoading(true);
    try {
      const url = difficulty 
        ? `${API_URL}/decisions/scenario?difficulty=${difficulty}`
        : `${API_URL}/decisions/scenario`;

      const res = await fetch(url, {
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`
        }
      });

      const data = await res.json();
      
      if (data.error) {
        console.error(data.error);
      } else {
        setScenario(data);
        setSelectedOption(null);
        setShowResult(false);
        setResult(null);
        setTimeLeft(60);
        setStartTime(Date.now());
      }
    } catch (error) {
      console.error('Error fetching scenario:', error);
    } finally {
      setLoading(false);
    }
  };

  // Fetch stats
  const fetchStats = async () => {
    try {
      const res = await fetch(`${API_URL}/decisions/stats/${userId}`, {
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`
        }
      });
      const data = await res.json();
      setStats(data);
    } catch (error) {
      console.error('Error fetching stats:', error);
    }
  };

  // Fetch recommendations
  const fetchRecommendations = async () => {
    try {
      const res = await fetch(`${API_URL}/decisions/recommendations/${userId}`, {
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`
        }
      });
      const data = await res.json();
      if (data.recommendations) {
        setRecommendations(data.recommendations);
      }
    } catch (error) {
      console.error('Error fetching recommendations:', error);
    }
  };

  // Submit solution
  const handleSubmit = async () => {
    if (!selectedOption || !scenario || !startTime) return;

    setLoading(true);
    const timeTaken = (Date.now() - startTime) / 1000;

    try {
      const res = await fetch(`${API_URL}/decisions/submit`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`
        },
        body: JSON.stringify({
          userId,
          scenarioId: scenario.id,
          selectedOptionId: selectedOption,
          timeTaken
        })
      });

      const data = await res.json();
      
      if (data.error) {
        console.error(data.error);
      } else {
        setResult(data);
        setShowResult(true);
        await fetchStats();
        await fetchRecommendations();
      }
    } catch (error) {
      console.error('Error submitting solution:', error);
    } finally {
      setLoading(false);
    }
  };

  // Timer
  useEffect(() => {
    if (!scenario || showResult) return;

    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          handleSubmit();
          return 60;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [scenario, showResult, selectedOption]);

  // Initial load
  useEffect(() => {
    initScenarios();
    fetchStats();
    fetchRecommendations();
    fetchScenario();
  }, []);

  const difficultyColors = {
    beginner: '#00D4FF',
    intermediate: '#FFD700',
    advanced: '#FF6B6B'
  };

  const difficultyNames = {
    beginner: 'مبتدئ',
    intermediate: 'متوسط',
    advanced: 'متقدم'
  };

  if (loading && !scenario) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <motion.div
          className="text-[#FFD700] text-xl"
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
        >
          ⏳
        </motion.div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Stats Bar */}
      <div className="grid grid-cols-4 gap-4">
        <div className="glass-gold rounded-xl p-4">
          <div className="text-xs opacity-70 mb-1">المحاولات</div>
          <div className="text-2xl font-bold text-[#FFD700]">{stats.totalAttempts}</div>
        </div>

        <div className="glass-gold rounded-xl p-4">
          <div className="text-xs opacity-70 mb-1">الإجابات الصحيحة</div>
          <div className="text-2xl font-bold text-green-500">{stats.correctAttempts}</div>
        </div>

        <div className="glass-gold rounded-xl p-4">
          <div className="text-xs opacity-70 mb-1">الدقة</div>
          <div className="text-2xl font-bold text-[#FFD700]">{stats.accuracy}%</div>
        </div>

        <div className="glass-gold rounded-xl p-4">
          <div className="text-xs opacity-70 mb-1">النقاط الكلية</div>
          <div className="text-2xl font-bold text-[#FFD700]">{stats.totalScore}</div>
        </div>
      </div>

      {/* Recommendations */}
      {recommendations.length > 0 && (
        <motion.div
          className="glass-gold rounded-xl p-6"
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
        >
          <div className="flex items-center gap-2 mb-4">
            <Lightbulb className="w-5 h-5 text-[#FFD700]" />
            <h4 className="font-bold">توصيات مخصصة</h4>
          </div>
          <div className="space-y-2">
            {recommendations.map((rec, i) => (
              <motion.div
                key={i}
                className="text-sm opacity-90"
                initial={{ x: -20, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                transition={{ delay: i * 0.1 }}
              >
                • {rec}
              </motion.div>
            ))}
          </div>
        </motion.div>
      )}

      {/* Difficulty Selector */}
      <div className="flex gap-3">
        {(['beginner', 'intermediate', 'advanced'] as const).map((diff) => (
          <motion.button
            key={diff}
            className="glass rounded-xl px-6 py-3 flex-1"
            style={{
              borderColor: difficultyColors[diff],
              borderWidth: 2
            }}
            onClick={() => fetchScenario(diff)}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            <span style={{ color: difficultyColors[diff] }}>
              {difficultyNames[diff]}
            </span>
          </motion.button>
        ))}
      </div>

      {/* Scenario Card */}
      <AnimatePresence mode="wait">
        {scenario && !showResult && (
          <motion.div
            key={scenario.id}
            className="glass-gold rounded-2xl p-8 relative overflow-hidden"
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            style={{
              backgroundColor: timeLeft <= 10 ? `rgba(255, 0, 0, ${(10 - timeLeft) * 0.05})` : undefined
            }}
          >
            {/* Timer */}
            <div className="absolute top-8 left-8">
              <div className="relative w-24 h-24">
                <svg className="transform -rotate-90 w-24 h-24">
                  <circle
                    cx="48"
                    cy="48"
                    r="40"
                    stroke="rgba(255,255,255,0.1)"
                    strokeWidth="6"
                    fill="none"
                  />
                  <motion.circle
                    cx="48"
                    cy="48"
                    r="40"
                    stroke={timeLeft <= 10 ? '#FF0000' : '#FFD700'}
                    strokeWidth="6"
                    fill="none"
                    strokeLinecap="round"
                    strokeDasharray={251.2}
                    strokeDashoffset={251.2 * (1 - timeLeft / 60)}
                    animate={{ strokeDashoffset: 251.2 * (1 - timeLeft / 60) }}
                  />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center">
                    <Clock className="w-6 h-6 mx-auto mb-1" style={{ color: timeLeft <= 10 ? '#FF0000' : '#FFD700' }} />
                    <div className="text-xl font-bold" style={{ color: timeLeft <= 10 ? '#FF0000' : '#FFD700' }}>
                      {timeLeft}
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Content */}
            <div className="mr-32">
              <div className="flex items-center gap-3 mb-4">
                <Brain className="w-6 h-6 text-[#FFD700]" />
                <div
                  className="px-3 py-1 rounded-full text-xs"
                  style={{
                    backgroundColor: `${difficultyColors[scenario.difficulty]}22`,
                    color: difficultyColors[scenario.difficulty],
                    borderColor: difficultyColors[scenario.difficulty],
                    borderWidth: 1
                  }}
                >
                  {difficultyNames[scenario.difficulty]}
                </div>
                <div className="text-sm opacity-70">{scenario.points} نقطة</div>
              </div>

              <h3 className="text-[#FFD700] mb-3">{scenario.title}</h3>
              <p className="text-sm opacity-80 mb-4">{scenario.description}</p>

              <div className="glass rounded-xl p-4 mb-6">
                <div className="text-sm font-bold mb-2">السياق:</div>
                <div className="text-sm opacity-90">{scenario.context}</div>
              </div>

              <h4 className="mb-4">{scenario.question}</h4>

              {/* Options */}
              <div className="space-y-3">
                {scenario.options.map((option, index) => (
                  <motion.button
                    key={option.id}
                    className={`w-full glass rounded-xl p-4 text-right transition-all ${
                      selectedOption === option.id
                        ? 'ring-2 ring-[#FFD700] bg-[#FFD700]/10'
                        : ''
                    }`}
                    onClick={() => setSelectedOption(option.id)}
                    initial={{ x: -50, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    transition={{ delay: index * 0.1 }}
                    whileHover={{ scale: 1.02, x: -5 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-6 h-6 rounded-full border-2 flex items-center justify-center ${
                          selectedOption === option.id
                            ? 'border-[#FFD700] bg-[#FFD700]'
                            : 'border-gray-600'
                        }`}
                      >
                        {selectedOption === option.id && (
                          <motion.div
                            initial={{ scale: 0 }}
                            animate={{ scale: 1 }}
                            className="w-3 h-3 rounded-full bg-black"
                          />
                        )}
                      </div>
                      <span className="flex-1">{option.text}</span>
                    </div>
                  </motion.button>
                ))}
              </div>

              {/* Submit Button */}
              <motion.button
                className="w-full mt-6 glass-gold rounded-xl py-4 text-lg font-bold text-[#FFD700] disabled:opacity-50"
                onClick={handleSubmit}
                disabled={!selectedOption || loading}
                whileHover={{ scale: !selectedOption || loading ? 1 : 1.02 }}
                whileTap={{ scale: !selectedOption || loading ? 1 : 0.98 }}
              >
                {loading ? 'جاري التقييم...' : 'تأكيد الإجابة'}
              </motion.button>
            </div>
          </motion.div>
        )}

        {/* Result */}
        {showResult && result && (
          <motion.div
            className="glass-gold rounded-2xl p-8 text-center"
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
          >
            <motion.div
              className="text-8xl mb-6"
              animate={{ rotate: [0, 10, -10, 0], scale: [1, 1.2, 1] }}
              transition={{ duration: 0.5 }}
            >
              {result.isCorrect ? '🎉' : '📚'}
            </motion.div>

            <h2 className={`mb-4 ${result.isCorrect ? 'text-green-500' : 'text-orange-500'}`}>
              {result.message}
            </h2>

            <div className="glass rounded-xl p-6 mb-6 text-right">
              <div className="text-sm font-bold mb-2">الشرح:</div>
              <div className="text-sm opacity-90">{result.explanation}</div>
            </div>

            <div className="grid grid-cols-2 gap-4 mb-6">
              <div className="glass rounded-xl p-4">
                <div className="text-xs opacity-70 mb-1">النقاط المكتسبة</div>
                <div className="text-3xl font-bold text-[#FFD700]">+{result.score}</div>
              </div>
              <div className="glass rounded-xl p-4">
                <div className="text-xs opacity-70 mb-1">الوقت المستغرق</div>
                <div className="text-3xl font-bold text-[#FFD700]">
                  {Math.floor((Date.now() - (startTime || 0)) / 1000)}s
                </div>
              </div>
            </div>

            <motion.button
              className="glass-gold rounded-xl px-12 py-4 text-lg font-bold text-[#FFD700]"
              onClick={() => fetchScenario()}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              سيناريو جديد
            </motion.button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
