import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import * as kv from "./kv_store.tsx";
import * as trading from "./trading.tsx";
import * as realEstate from "./realEstate.tsx";
import * as decisions from "./decisions.tsx";
import * as aiTutor from "./aiTutor.tsx";
import * as recommendations from "./recommendations.tsx";
import * as analytics from "./analytics.tsx";
import * as partnerships from "./partnerships.tsx";
import * as content from "./content.tsx";
import * as gamification from "./gamification.tsx";

const app = new Hono();

// Enable logger
app.use('*', logger(console.log));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// Health check endpoint
app.get("/make-server-1e8d5017/health", (c) => {
  return c.json({ status: "ok" });
});

// ==================== TRADING ROUTES ====================

// Get market price
app.get("/make-server-1e8d5017/market/:symbol", async (c) => {
  try {
    const symbol = c.req.param("symbol");
    const price = await trading.getMarketPrice(symbol);
    return c.json({ symbol, price });
  } catch (error) {
    console.error("Error fetching market price:", error);
    return c.json({ error: "خطأ في جلب سعر السوق" }, 500);
  }
});

// Open trade
app.post("/make-server-1e8d5017/trading/open", async (c) => {
  try {
    const body = await c.req.json();
    const { userId, simulationId, symbol, amount, direction } = body;

    if (!userId || !simulationId || !symbol || !amount || !direction) {
      return c.json({ error: "بيانات غير مكتملة" }, 400);
    }

    const result = await trading.executeTrade(userId, {
      simulationId,
      symbol,
      amount: parseFloat(amount),
      direction
    });

    if (!result.success) {
      return c.json({ error: result.message }, 400);
    }

    return c.json(result);
  } catch (error) {
    console.error("Error opening trade:", error);
    return c.json({ error: "خطأ في فتح الصفقة" }, 500);
  }
});

// Close trade
app.post("/make-server-1e8d5017/trading/close", async (c) => {
  try {
    const body = await c.req.json();
    const { userId, tradeId } = body;

    if (!userId || !tradeId) {
      return c.json({ error: "بيانات غير مكتملة" }, 400);
    }

    const result = await trading.closeTrade(userId, tradeId);

    if (!result.success) {
      return c.json({ error: result.message }, 400);
    }

    return c.json(result);
  } catch (error) {
    console.error("Error closing trade:", error);
    return c.json({ error: "خطأ في إغلاق الصفقة" }, 500);
  }
});

// Get trade statistics
app.get("/make-server-1e8d5017/trading/stats/:userId/:simulationId", async (c) => {
  try {
    const userId = c.req.param("userId");
    const simulationId = c.req.param("simulationId");

    const stats = await trading.getUserStats(userId, simulationId);
    return c.json(stats);
  } catch (error) {
    console.error("Error fetching stats:", error);
    return c.json({ error: "خطأ في جلب الإحصائيات" }, 500);
  }
});

// Get trade history
app.get("/make-server-1e8d5017/trading/history/:userId/:simulationId", async (c) => {
  try {
    const userId = c.req.param("userId");
    const simulationId = c.req.param("simulationId");

    const history = await trading.getTradeHistory(userId, simulationId);
    return c.json({ trades: history });
  } catch (error) {
    console.error("Error fetching history:", error);
    return c.json({ error: "خطأ في جلب السجل" }, 500);
  }
});

// Get user balance
app.get("/make-server-1e8d5017/trading/balance/:userId/:simulationId", async (c) => {
  try {
    const userId = c.req.param("userId");
    const simulationId = c.req.param("simulationId");

    const balanceKey = `balance:${userId}:${simulationId}`;
    const balanceStr = await kv.get(balanceKey);
    const balance = balanceStr ? parseFloat(balanceStr) : 10000;

    return c.json({ balance });
  } catch (error) {
    console.error("Error fetching balance:", error);
    return c.json({ error: "خطأ في جلب الرصيد" }, 500);
  }
});

// ==================== REAL ESTATE ROUTES ====================

// Initialize property market
app.post("/make-server-1e8d5017/realestate/init/:simulationId", async (c) => {
  try {
    const simulationId = c.req.param("simulationId");
    await realEstate.initializePropertyMarket(simulationId);
    return c.json({ message: "تم تهيئة سوق العقارات بنجاح" });
  } catch (error) {
    console.error("Error initializing property market:", error);
    return c.json({ error: "خطأ في تهيئة السوق" }, 500);
  }
});

// Get available properties
app.get("/make-server-1e8d5017/realestate/properties/:simulationId", async (c) => {
  try {
    const simulationId = c.req.param("simulationId");
    const properties = await realEstate.getAvailableProperties(simulationId);
    return c.json({ properties });
  } catch (error) {
    console.error("Error fetching properties:", error);
    return c.json({ error: "خطأ في جلب العقارات" }, 500);
  }
});

// Purchase property
app.post("/make-server-1e8d5017/realestate/purchase", async (c) => {
  try {
    const body = await c.req.json();
    const { userId, simulationId, propertyId, financingType, downPayment } = body;

    if (!userId || !simulationId || !propertyId || !financingType) {
      return c.json({ error: "بيانات غير مكتملة" }, 400);
    }

    const result = await realEstate.purchaseProperty(userId, simulationId, {
      propertyId,
      financingType,
      downPayment: downPayment ? parseFloat(downPayment) : undefined
    });

    if (!result.success) {
      return c.json({ error: result.message }, 400);
    }

    return c.json(result);
  } catch (error) {
    console.error("Error purchasing property:", error);
    return c.json({ error: "خطأ في شراء العقار" }, 500);
  }
});

// Sell property
app.post("/make-server-1e8d5017/realestate/sell", async (c) => {
  try {
    const body = await c.req.json();
    const { userId, simulationId, propertyId } = body;

    if (!userId || !simulationId || !propertyId) {
      return c.json({ error: "بيانات غير مكتملة" }, 400);
    }

    const result = await realEstate.sellProperty(userId, simulationId, propertyId);

    if (!result.success) {
      return c.json({ error: result.message }, 400);
    }

    return c.json(result);
  } catch (error) {
    console.error("Error selling property:", error);
    return c.json({ error: "خطأ في بيع العقار" }, 500);
  }
});

// Get user portfolio
app.get("/make-server-1e8d5017/realestate/portfolio/:userId/:simulationId", async (c) => {
  try {
    const userId = c.req.param("userId");
    const simulationId = c.req.param("simulationId");

    const portfolio = await realEstate.getUserPortfolio(userId, simulationId);
    return c.json(portfolio);
  } catch (error) {
    console.error("Error fetching portfolio:", error);
    return c.json({ error: "خطأ في جلب المحفظة" }, 500);
  }
});

// Analyze portfolio performance
app.get("/make-server-1e8d5017/realestate/analyze/:userId/:simulationId", async (c) => {
  try {
    const userId = c.req.param("userId");
    const simulationId = c.req.param("simulationId");

    const analysis = await realEstate.analyzePortfolioPerformance(userId, simulationId);
    return c.json(analysis);
  } catch (error) {
    console.error("Error analyzing portfolio:", error);
    return c.json({ error: "خطأ في تحليل المحفظة" }, 500);
  }
});

// ==================== DECISION SCENARIOS ROUTES ====================

// Initialize scenarios
app.post("/make-server-1e8d5017/decisions/init", async (c) => {
  try {
    await decisions.initializeScenarios();
    return c.json({ message: "تم تهيئة السيناريوهات بنجاح" });
  } catch (error) {
    console.error("Error initializing scenarios:", error);
    return c.json({ error: "خطأ ي تهيئة السيناريوهات" }, 500);
  }
});

// Get random scenario
app.get("/make-server-1e8d5017/decisions/scenario", async (c) => {
  try {
    const difficulty = c.req.query("difficulty") as any;
    const scenario = await decisions.getRandomScenario(difficulty);
    
    if (!scenario) {
      return c.json({ error: "لا توجد سيناريوهات متاحة" }, 404);
    }

    return c.json(scenario);
  } catch (error) {
    console.error("Error fetching scenario:", error);
    return c.json({ error: "خطأ في جلب السيناريو" }, 500);
  }
});

// Submit solution
app.post("/make-server-1e8d5017/decisions/submit", async (c) => {
  try {
    const body = await c.req.json();
    const { userId, scenarioId, selectedOptionId, timeTaken } = body;

    if (!userId || !scenarioId || !selectedOptionId || timeTaken === undefined) {
      return c.json({ error: "بيانات غير مكتملة" }, 400);
    }

    const result = await decisions.submitSolution(
      userId,
      scenarioId,
      selectedOptionId,
      parseFloat(timeTaken)
    );

    if (!result.success) {
      return c.json({ error: result.message }, 400);
    }

    return c.json(result);
  } catch (error) {
    console.error("Error submitting solution:", error);
    return c.json({ error: "خطأ في قييم الحل" }, 500);
  }
});

// Get user decision stats
app.get("/make-server-1e8d5017/decisions/stats/:userId", async (c) => {
  try {
    const userId = c.req.param("userId");
    const stats = await decisions.getUserDecisionStats(userId);
    return c.json(stats);
  } catch (error) {
    console.error("Error fetching decision stats:", error);
    return c.json({ error: "خطأ في جلب الإحصائيات" }, 500);
  }
});

// Get recommendations
app.get("/make-server-1e8d5017/decisions/recommendations/:userId", async (c) => {
  try {
    const userId = c.req.param("userId");
    const recommendations = await decisions.generateRecommendations(userId);
    return c.json({ recommendations });
  } catch (error) {
    console.error("Error generating recommendations:", error);
    return c.json({ error: "خطأ في توليد التوصيات" }, 500);
  }
});

// Analyze patterns (anti-cheat)
app.get("/make-server-1e8d5017/decisions/analyze/:userId", async (c) => {
  try {
    const userId = c.req.param("userId");
    const analysis = await decisions.analyzeDecisionPatterns(userId);
    return c.json(analysis);
  } catch (error) {
    console.error("Error analyzing patterns:", error);
    return c.json({ error: "خطأ في تحليل الأنماط" }, 500);
  }
});

// ==================== AI TUTOR ROUTES ====================

// Ask AI tutor
app.post("/make-server-1e8d5017/ai/tutor/ask", async (c) => {
  try {
    const body = await c.req.json();
    const { userId, question } = body;

    if (!userId || !question) {
      return c.json({ error: "بيانات غير مكتملة" }, 400);
    }

    const result = await aiTutor.generateAIResponse(userId, question);
    return c.json(result);
  } catch (error) {
    console.error("Error asking AI tutor:", error);
    return c.json({ error: "خطأ في الحصول على الرد" }, 500);
  }
});

// Get conversation history
app.get("/make-server-1e8d5017/ai/tutor/history/:userId", async (c) => {
  try {
    const userId = c.req.param("userId");
    const limit = parseInt(c.req.query("limit") || "10");
    
    const history = await aiTutor.getConversationHistory(userId, limit);
    return c.json({ history });
  } catch (error) {
    console.error("Error fetching conversation history:", error);
    return c.json({ error: "خطأ في جلب السجل" }, 500);
  }
});

// Get learning progress analysis
app.get("/make-server-1e8d5017/ai/tutor/progress/:userId", async (c) => {
  try {
    const userId = c.req.param("userId");
    const progress = await aiTutor.analyzeLearningProgress(userId);
    return c.json(progress);
  } catch (error) {
    console.error("Error analyzing learning progress:", error);
    return c.json({ error: "خطأ في تحليل التقدم" }, 500);
  }
});

// Get quick tip
app.get("/make-server-1e8d5017/ai/tutor/tip", async (c) => {
  try {
    const category = c.req.query("category");
    const tip = aiTutor.getQuickTip(category);
    return c.json({ tip });
  } catch (error) {
    console.error("Error getting quick tip:", error);
    return c.json({ error: "خطأ في جلب النصيحة" }, 500);
  }
});

// ==================== RECOMMENDATIONS ROUTES ====================

// Get personalized recommendations
app.get("/make-server-1e8d5017/ai/recommendations/:userId", async (c) => {
  try {
    const userId = c.req.param("userId");
    const limit = parseInt(c.req.query("limit") || "5");
    
    const result = await recommendations.generateRecommendations(userId, limit);
    return c.json(result);
  } catch (error) {
    console.error("Error generating recommendations:", error);
    return c.json({ error: "خطأ في توليد التوصيات" }, 500);
  }
});

// Track user activity
app.post("/make-server-1e8d5017/ai/track", async (c) => {
  try {
    const body = await c.req.json();
    const { userId, activityType, contentId, category, timeSpent } = body;

    if (!userId || !activityType || !contentId || !category) {
      return c.json({ error: "بيانات غير مكتملة" }, 400);
    }

    await recommendations.trackActivity(
      userId,
      activityType,
      contentId,
      category,
      timeSpent || 0
    );

    return c.json({ message: "تم تسجيل النشاط بنجاح" });
  } catch (error) {
    console.error("Error tracking activity:", error);
    return c.json({ error: "خطأ في تسجيل النشاط" }, 500);
  }
});

// Get learning path
app.get("/make-server-1e8d5017/ai/learning-path/:userId/:goal", async (c) => {
  try {
    const userId = c.req.param("userId");
    const goal = c.req.param("goal") as any;
    
    const path = await recommendations.getLearningPath(userId, goal);
    return c.json(path);
  } catch (error) {
    console.error("Error getting learning path:", error);
    return c.json({ error: "خطأ في جلب المسار التعليمي" }, 500);
  }
});

// Get trending content
app.get("/make-server-1e8d5017/ai/trending", async (c) => {
  try {
    const limit = parseInt(c.req.query("limit") || "5");
    const trending = await recommendations.getTrendingContent(limit);
    return c.json({ trending });
  } catch (error) {
    console.error("Error getting trending content:", error);
    return c.json({ error: "خطأ في جلب المحتوى الرائج" }, 500);
  }
});

// Search content
app.get("/make-server-1e8d5017/ai/search", async (c) => {
  try {
    const query = c.req.query("q");
    if (!query) {
      return c.json({ error: "يجب توفير نص البحث" }, 400);
    }

    const filters = {
      type: c.req.query("type"),
      difficulty: c.req.query("difficulty"),
      category: c.req.query("category")
    };

    const results = await recommendations.searchContent(query, filters);
    return c.json({ results });
  } catch (error) {
    console.error("Error searching content:", error);
    return c.json({ error: "خطأ في البحث" }, 500);
  }
});

// ==================== ANALYTICS ROUTES ====================

// Get comprehensive performance report
app.get("/make-server-1e8d5017/ai/analytics/report/:userId/:simulationId", async (c) => {
  try {
    const userId = c.req.param("userId");
    const simulationId = c.req.param("simulationId");
    
    const report = await analytics.generatePerformanceReport(userId, simulationId);
    return c.json(report);
  } catch (error) {
    console.error("Error generating performance report:", error);
    return c.json({ error: "خطأ في توليد التقرير" }, 500);
  }
});

// Get risk analysis
app.get("/make-server-1e8d5017/ai/analytics/risk/:userId/:simulationId", async (c) => {
  try {
    const userId = c.req.param("userId");
    const simulationId = c.req.param("simulationId");
    
    const riskProfile = await analytics.detectRiskPatterns(userId, simulationId);
    return c.json(riskProfile);
  } catch (error) {
    console.error("Error detecting risk patterns:", error);
    return c.json({ error: "خطأ في تحليل المخاطر" }, 500);
  }
});

// Get activity summary
app.get("/make-server-1e8d5017/ai/analytics/summary/:userId", async (c) => {
  try {
    const userId = c.req.param("userId");
    const period = (c.req.query("period") || "week") as 'week' | 'month';
    
    const summary = await analytics.getActivitySummary(userId, period);
    return c.json(summary);
  } catch (error) {
    console.error("Error getting activity summary:", error);
    return c.json({ error: "خطأ في جلب الملخص" }, 500);
  }
});

// ==================== PARTNERSHIPS ROUTES ====================

// Create new partner
app.post("/make-server-1e8d5017/partners/create", async (c) => {
  try {
    const body = await c.req.json();
    const { name, type, tier, contact, customBenefits, agreementTerms } = body;

    if (!name || !type || !contact?.email) {
      return c.json({ error: "بيانات غير مكتملة" }, 400);
    }

    const partner = await partnerships.createPartner({
      name,
      type,
      tier,
      contact,
      customBenefits,
      agreementTerms
    });

    return c.json(partner);
  } catch (error) {
    console.error("Error creating partner:", error);
    return c.json({ error: "خطأ في إنشاء الشريك" }, 500);
  }
});

// Get partner by ID
app.get("/make-server-1e8d5017/partners/:partnerId", async (c) => {
  try {
    const partnerId = c.req.param("partnerId");
    const partner = await partnerships.getPartner(partnerId);
    
    if (!partner) {
      return c.json({ error: "الشريك غير موجود" }, 404);
    }

    return c.json(partner);
  } catch (error) {
    console.error("Error fetching partner:", error);
    return c.json({ error: "خطأ في جلب بيانات الشريك" }, 500);
  }
});

// Get partner by referral code
app.get("/make-server-1e8d5017/partners/code/:referralCode", async (c) => {
  try {
    const referralCode = c.req.param("referralCode");
    const partner = await partnerships.getPartnerByCode(referralCode);
    
    if (!partner) {
      return c.json({ error: "كود إحالة غير صالح" }, 404);
    }

    return c.json(partner);
  } catch (error) {
    console.error("Error fetching partner by code:", error);
    return c.json({ error: "خطأ في جلب بيانات الشريك" }, 500);
  }
});

// List all partners
app.get("/make-server-1e8d5017/partners", async (c) => {
  try {
    const type = c.req.query("type") as any;
    const tier = c.req.query("tier") as any;
    
    const partners = await partnerships.listPartners({ type, tier });
    return c.json({ partners });
  } catch (error) {
    console.error("Error listing partners:", error);
    return c.json({ error: "خطأ في جلب قائمة الشركاء" }, 500);
  }
});

// Update partner
app.put("/make-server-1e8d5017/partners/:partnerId", async (c) => {
  try {
    const partnerId = c.req.param("partnerId");
    const updates = await c.req.json();
    
    const partner = await partnerships.updatePartner(partnerId, updates);
    
    if (!partner) {
      return c.json({ error: "الشريك غير موجود" }, 404);
    }

    return c.json(partner);
  } catch (error) {
    console.error("Error updating partner:", error);
    return c.json({ error: "خطأ في تحديث بيانات الشريك" }, 500);
  }
});

// Upgrade partner tier
app.post("/make-server-1e8d5017/partners/:partnerId/upgrade", async (c) => {
  try {
    const partnerId = c.req.param("partnerId");
    const { newTier } = await c.req.json();
    
    if (!newTier) {
      return c.json({ error: "يجب تحديد المستوى الجديد" }, 400);
    }

    const partner = await partnerships.upgradePartnerTier(partnerId, newTier);
    
    if (!partner) {
      return c.json({ error: "فشل في ترقية المستوى" }, 400);
    }

    return c.json(partner);
  } catch (error) {
    console.error("Error upgrading partner tier:", error);
    return c.json({ error: error.message || "خطأ في ترقية المستوى" }, 500);
  }
});

// Track referral
app.post("/make-server-1e8d5017/partners/referrals/track", async (c) => {
  try {
    const { referralCode, userId, activityType, transactionAmount } = await c.req.json();
    
    if (!referralCode || !userId) {
      return c.json({ error: "بيانات غير مكتملة" }, 400);
    }

    const referral = await partnerships.trackReferral(
      referralCode,
      userId,
      activityType,
      transactionAmount
    );

    return c.json(referral);
  } catch (error) {
    console.error("Error tracking referral:", error);
    return c.json({ error: error.message || "خطأ في تتبع الإحالة" }, 500);
  }
});

// Complete referral (assign commission)
app.post("/make-server-1e8d5017/partners/referrals/:referralId/complete", async (c) => {
  try {
    const referralId = c.req.param("referralId");
    const { activityType, transactionAmount } = await c.req.json();
    
    if (!activityType) {
      return c.json({ error: "يجب تحديد نوع النشاط" }, 400);
    }

    const referral = await partnerships.completeReferral(
      referralId,
      activityType,
      transactionAmount
    );
    
    if (!referral) {
      return c.json({ error: "الإحالة غير موجودة" }, 404);
    }

    return c.json(referral);
  } catch (error) {
    console.error("Error completing referral:", error);
    return c.json({ error: "خطأ في إكمال الإحالة" }, 500);
  }
});

// Get partner referrals
app.get("/make-server-1e8d5017/partners/:partnerId/referrals", async (c) => {
  try {
    const partnerId = c.req.param("partnerId");
    const referrals = await partnerships.getPartnerReferrals(partnerId);
    return c.json({ referrals });
  } catch (error) {
    console.error("Error fetching referrals:", error);
    return c.json({ error: "خطأ في جلب الإحالات" }, 500);
  }
});

// Get partner statistics
app.get("/make-server-1e8d5017/partners/:partnerId/stats", async (c) => {
  try {
    const partnerId = c.req.param("partnerId");
    const stats = await partnerships.getPartnerStats(partnerId);
    return c.json(stats);
  } catch (error) {
    console.error("Error fetching partner stats:", error);
    return c.json({ error: "خطأ في جلب الإحصائيات" }, 500);
  }
});

// Generate partner report
app.get("/make-server-1e8d5017/partners/:partnerId/report", async (c) => {
  try {
    const partnerId = c.req.param("partnerId");
    const startDate = c.req.query("startDate");
    const endDate = c.req.query("endDate");
    
    const report = await partnerships.generatePartnerReport(partnerId, startDate, endDate);
    return c.json(report);
  } catch (error) {
    console.error("Error generating partner report:", error);
    return c.json({ error: "خطأ في توليد التقرير" }, 500);
  }
});

// University: Bulk student registration
app.post("/make-server-1e8d5017/partners/university/:partnerId/students", async (c) => {
  try {
    const partnerId = c.req.param("partnerId");
    const { students } = await c.req.json();
    
    if (!students || !Array.isArray(students)) {
      return c.json({ error: "يجب توفير قائمة الطلاب" }, 400);
    }

    const result = await partnerships.registerUniversityStudents(partnerId, students);
    return c.json(result);
  } catch (error) {
    console.error("Error registering students:", error);
    return c.json({ error: error.message || "خطأ في تسجيل الطلاب" }, 500);
  }
});

// Corporate: Bulk employee enrollment
app.post("/make-server-1e8d5017/partners/corporate/:partnerId/employees", async (c) => {
  try {
    const partnerId = c.req.param("partnerId");
    const { employeeCount, subscriptionAmount } = await c.req.json();
    
    if (!employeeCount || !subscriptionAmount) {
      return c.json({ error: "بيانات غير مكتملة" }, 400);
    }

    const result = await partnerships.enrollCorporateEmployees(
      partnerId,
      employeeCount,
      subscriptionAmount
    );
    
    return c.json(result);
  } catch (error) {
    console.error("Error enrolling employees:", error);
    return c.json({ error: error.message || "خطأ في تسجيل الموظفين" }, 500);
  }
});

// ==================== CONTENT ROUTES ====================

// Create video
app.post("/make-server-1e8d5017/content/videos/create", async (c) => {
  try {
    const body = await c.req.json();
    const video = await content.createVideo(body);
    return c.json(video);
  } catch (error) {
    console.error("Error creating video:", error);
    return c.json({ error: "خطأ في إنشاء الفيديو" }, 500);
  }
});

// Get video
app.get("/make-server-1e8d5017/content/videos/:videoId", async (c) => {
  try {
    const videoId = c.req.param("videoId");
    const video = await content.getVideo(videoId);
    
    if (!video) {
      return c.json({ error: "الفيديو غير موجود" }, 404);
    }

    return c.json(video);
  } catch (error) {
    console.error("Error fetching video:", error);
    return c.json({ error: "خطأ في جلب الفيديو" }, 500);
  }
});

// List videos
app.get("/make-server-1e8d5017/content/videos", async (c) => {
  try {
    const filters = {
      category: c.req.query("category"),
      level: c.req.query("level"),
      owner: c.req.query("owner")
    };
    
    const videos = await content.listVideos(filters);
    return c.json({ videos });
  } catch (error) {
    console.error("Error listing videos:", error);
    return c.json({ error: "خطأ في جلب الفيديوهات" }, 500);
  }
});

// Increment video views
app.post("/make-server-1e8d5017/content/videos/:videoId/view", async (c) => {
  try {
    const videoId = c.req.param("videoId");
    const views = await content.incrementViews(videoId);
    return c.json({ views });
  } catch (error) {
    console.error("Error incrementing views:", error);
    return c.json({ error: "خطأ في تسجيل المشاهدة" }, 500);
  }
});

// Rate video
app.post("/make-server-1e8d5017/content/videos/:videoId/rate", async (c) => {
  try {
    const videoId = c.req.param("videoId");
    const { userId, rating } = await c.req.json();
    
    if (!userId || !rating) {
      return c.json({ error: "بيانات غير مكتملة" }, 400);
    }

    const result = await content.rateVideo(videoId, userId, rating);
    return c.json(result);
  } catch (error) {
    console.error("Error rating video:", error);
    return c.json({ error: "خطأ في تقييم الفيديو" }, 500);
  }
});

// Create quiz
app.post("/make-server-1e8d5017/content/quizzes/create", async (c) => {
  try {
    const body = await c.req.json();
    const quiz = await content.createQuiz(body);
    return c.json(quiz);
  } catch (error) {
    console.error("Error creating quiz:", error);
    return c.json({ error: "خطأ في إنشاء الاختبار" }, 500);
  }
});

// Get quiz
app.get("/make-server-1e8d5017/content/quizzes/:quizId", async (c) => {
  try {
    const quizId = c.req.param("quizId");
    const quiz = await content.getQuiz(quizId);
    
    if (!quiz) {
      return c.json({ error: "الاختبار غير موجود" }, 404);
    }

    return c.json(quiz);
  } catch (error) {
    console.error("Error fetching quiz:", error);
    return c.json({ error: "خطأ في جلب الاختبار" }, 500);
  }
});

// Start quiz session
app.post("/make-server-1e8d5017/content/quizzes/:quizId/start", async (c) => {
  try {
    const quizId = c.req.param("quizId");
    const { userId } = await c.req.json();
    
    if (!userId) {
      return c.json({ error: "معرف المستخدم مطلوب" }, 400);
    }

    const session = await content.startQuizSession(userId, quizId);
    return c.json(session);
  } catch (error) {
    console.error("Error starting quiz session:", error);
    return c.json({ error: error.message || "خطأ في بدء الاختبار" }, 500);
  }
});

// Submit quiz answer
app.post("/make-server-1e8d5017/content/quizzes/sessions/:sessionId/answer", async (c) => {
  try {
    const sessionId = c.req.param("sessionId");
    const { questionId, answer } = await c.req.json();
    
    if (!questionId || answer === undefined) {
      return c.json({ error: "بيانات غير مكتملة" }, 400);
    }

    const result = await content.submitAnswer(sessionId, questionId, answer);
    return c.json(result);
  } catch (error) {
    console.error("Error submitting answer:", error);
    return c.json({ error: error.message || "خطأ في تسجيل الإجابة" }, 500);
  }
});

// Complete quiz session
app.post("/make-server-1e8d5017/content/quizzes/sessions/:sessionId/complete", async (c) => {
  try {
    const sessionId = c.req.param("sessionId");
    const result = await content.completeQuizSession(sessionId);
    return c.json(result);
  } catch (error) {
    console.error("Error completing quiz session:", error);
    return c.json({ error: error.message || "خطأ في إنهاء الاختبار" }, 500);
  }
});

// Get user certificates
app.get("/make-server-1e8d5017/content/certificates/:userId", async (c) => {
  try {
    const userId = c.req.param("userId");
    const certificates = await content.getUserCertificates(userId);
    return c.json({ certificates });
  } catch (error) {
    console.error("Error fetching certificates:", error);
    return c.json({ error: "خطأ في جلب الشهادات" }, 500);
  }
});

// Verify certificate
app.get("/make-server-1e8d5017/content/certificates/verify/:code", async (c) => {
  try {
    const code = c.req.param("code");
    const result = await content.verifyCertificate(code);
    return c.json(result);
  } catch (error) {
    console.error("Error verifying certificate:", error);
    return c.json({ error: "خطأ في التحقق من الشهادة" }, 500);
  }
});

// Get content recommendations
app.get("/make-server-1e8d5017/content/recommendations/:userId", async (c) => {
  try {
    const userId = c.req.param("userId");
    const limit = parseInt(c.req.query("limit") || "5");
    
    const recommendations = await content.getContentRecommendations(userId, limit);
    return c.json({ recommendations });
  } catch (error) {
    console.error("Error getting content recommendations:", error);
    return c.json({ error: "خطأ في جلب التوصيات" }, 500);
  }
});

// ==================== GAMIFICATION ROUTES ====================

// Get user progress
app.get("/make-server-1e8d5017/gamification/progress/:userId", async (c) => {
  try {
    const userId = c.req.param("userId");
    const progress = await gamification.getUserProgress(userId);
    return c.json(progress);
  } catch (error) {
    console.error("Error fetching user progress:", error);
    return c.json({ error: "خطأ في جلب التقدم" }, 500);
  }
});

// Grant XP
app.post("/make-server-1e8d5017/gamification/xp/grant", async (c) => {
  try {
    const { userId, source, details } = await c.req.json();
    
    if (!userId || !source) {
      return c.json({ error: "بيانات غير مكتملة" }, 400);
    }

    const result = await gamification.grantXP(userId, source, details || {});
    return c.json(result);
  } catch (error) {
    console.error("Error granting XP:", error);
    return c.json({ error: "خطأ في منح XP" }, 500);
  }
});

// Update login streak
app.post("/make-server-1e8d5017/gamification/login/:userId", async (c) => {
  try {
    const userId = c.req.param("userId");
    const result = await gamification.updateLoginStreak(userId);
    return c.json(result);
  } catch (error) {
    console.error("Error updating login streak:", error);
    return c.json({ error: "خطأ في تحديث سلسلة الدخول" }, 500);
  }
});

// Get XP history
app.get("/make-server-1e8d5017/gamification/xp/history/:userId", async (c) => {
  try {
    const userId = c.req.param("userId");
    const limit = parseInt(c.req.query("limit") || "20");
    
    const history = await gamification.getXPHistory(userId, limit);
    return c.json({ history });
  } catch (error) {
    console.error("Error fetching XP history:", error);
    return c.json({ error: "خطأ في جلب السجل" }, 500);
  }
});

// Create badge
app.post("/make-server-1e8d5017/gamification/badges/create", async (c) => {
  try {
    const body = await c.req.json();
    const badge = await gamification.createBadge(body);
    return c.json(badge);
  } catch (error) {
    console.error("Error creating badge:", error);
    return c.json({ error: "خطأ في إنشاء الشارة" }, 500);
  }
});

// Get all badges
app.get("/make-server-1e8d5017/gamification/badges", async (c) => {
  try {
    const badges = await gamification.getAllBadges();
    return c.json({ badges });
  } catch (error) {
    console.error("Error fetching badges:", error);
    return c.json({ error: "خطأ في جلب الشارات" }, 500);
  }
});

// Get user badges
app.get("/make-server-1e8d5017/gamification/badges/:userId", async (c) => {
  try {
    const userId = c.req.param("userId");
    const badges = await gamification.getUserBadges(userId);
    return c.json({ badges });
  } catch (error) {
    console.error("Error fetching user badges:", error);
    return c.json({ error: "خطأ في جلب شارات المستخدم" }, 500);
  }
});

// Update leaderboard
app.post("/make-server-1e8d5017/gamification/leaderboard/update/:period", async (c) => {
  try {
    const period = c.req.param("period") as any;
    const leaderboard = await gamification.updateLeaderboard(period);
    return c.json(leaderboard);
  } catch (error) {
    console.error("Error updating leaderboard:", error);
    return c.json({ error: "خطأ في تحديث لوحة الصدارة" }, 500);
  }
});

// Get leaderboard
app.get("/make-server-1e8d5017/gamification/leaderboard/:period", async (c) => {
  try {
    const period = c.req.param("period") as any;
    const leaderboard = await gamification.getLeaderboard(period);
    
    if (!leaderboard) {
      return c.json({ error: "لوحة الصدارة غير موجودة" }, 404);
    }

    return c.json(leaderboard);
  } catch (error) {
    console.error("Error fetching leaderboard:", error);
    return c.json({ error: "خطأ في جلب لوحة الصدارة" }, 500);
  }
});

// Get user leaderboard position
app.get("/make-server-1e8d5017/gamification/leaderboard/:period/position/:userId", async (c) => {
  try {
    const period = c.req.param("period") as any;
    const userId = c.req.param("userId");
    
    const position = await gamification.getUserLeaderboardPosition(userId, period);
    
    if (!position) {
      return c.json({ error: "لم يتم العثور على المستخدم في لوحة الصدارة" }, 404);
    }

    return c.json(position);
  } catch (error) {
    console.error("Error fetching user leaderboard position:", error);
    return c.json({ error: "خطأ في جلب الترتيب" }, 500);
  }
});

// Initialize default badges
app.post("/make-server-1e8d5017/gamification/init", async (c) => {
  try {
    await gamification.initializeDefaultBadges();
    return c.json({ message: "تم تهيئة الشارات الافتراضية بنجاح" });
  } catch (error) {
    console.error("Error initializing default badges:", error);
    return c.json({ error: "خطأ في التهيئة" }, 500);
  }
});

Deno.serve(app.fetch);