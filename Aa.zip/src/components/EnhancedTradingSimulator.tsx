import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { TrendingUp, TrendingDown, DollarSign, Clock, Target, AlertCircle, Award, Activity } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { projectId, publicAnonKey } from '../utils/supabase/info.tsx';
import { api } from '../utils/api.tsx';

const API_URL = `https://${projectId}.supabase.co/functions/v1/make-server-1e8d5017`;

interface MarketDataPoint {
  time: string;
  price: number;
}

interface Trade {
  id: string;
  symbol: string;
  amount: number;
  direction: 'buy' | 'sell';
  entryPrice: number;
  status: 'open' | 'closed';
  timestamp: string;
}

export function EnhancedTradingSimulator() {
  const userId = 'user_demo_123'; // In production, get from auth
  const simulationId = 'sim_stock_001';

  const [balance, setBalance] = useState(10000);
  const [marketData, setMarketData] = useState<MarketDataPoint[]>([]);
  const [currentPrice, setCurrentPrice] = useState(100);
  const [openTrades, setOpenTrades] = useState<Trade[]>([]);
  const [stats, setStats] = useState({
    totalTrades: 0,
    winningTrades: 0,
    totalProfit: 0,
    winRate: 0
  });

  // Trade form
  const [symbol, setSymbol] = useState('AAPL');
  const [amount, setAmount] = useState(10);
  const [direction, setDirection] = useState<'buy' | 'sell'>('buy');
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');

  // Fetch balance
  const fetchBalance = async () => {
    try {
      const res = await fetch(`${API_URL}/trading/balance/${userId}/${simulationId}`, {
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`
        }
      });
      const data = await res.json();
      if (data.balance !== undefined) {
        setBalance(data.balance);
      }
    } catch (error) {
      console.error('Error fetching balance:', error);
    }
  };

  // Fetch market price
  const fetchMarketPrice = async () => {
    try {
      const res = await fetch(`${API_URL}/market/${symbol}`, {
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`
        }
      });
      const data = await res.json();
      if (data.price) {
        setCurrentPrice(data.price);
        
        // Update chart
        setMarketData(prev => {
          const newData = [
            ...prev,
            {
              time: new Date().toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit' }),
              price: data.price
            }
          ];
          return newData.slice(-20); // Keep last 20 points
        });
      }
    } catch (error) {
      console.error('Error fetching market price:', error);
    }
  };

  // Fetch stats
  const fetchStats = async () => {
    try {
      const res = await fetch(`${API_URL}/trading/stats/${userId}/${simulationId}`, {
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`
        }
      });
      const data = await res.json();
      setStats(data);
    } catch (error) {
      console.error('Error fetching stats:', error);
    }
  };

  // Fetch trade history
  const fetchTrades = async () => {
    try {
      const res = await fetch(`${API_URL}/trading/history/${userId}/${simulationId}`, {
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`
        }
      });
      const data = await res.json();
      if (data.trades) {
        setOpenTrades(data.trades.filter((t: Trade) => t.status === 'open'));
      }
    } catch (error) {
      console.error('Error fetching trades:', error);
    }
  };

  // Open trade
  const handleOpenTrade = async () => {
    setLoading(true);
    setMessage('');

    try {
      const res = await fetch(`${API_URL}/trading/open`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`
        },
        body: JSON.stringify({
          userId,
          simulationId,
          symbol,
          amount,
          direction
        })
      });

      const data = await res.json();

      if (data.error) {
        setMessage(`❌ ${data.error}`);
      } else {
        setMessage(`✅ ${data.message}`);
        await fetchBalance();
        await fetchTrades();
        await fetchStats();
      }
    } catch (error) {
      console.error('Error opening trade:', error);
      setMessage('❌ خطأ في فتح الصفقة');
    } finally {
      setLoading(false);
    }
  };

  // Close trade
  const handleCloseTrade = async (tradeId: string) => {
    setLoading(true);

    try {
      const res = await fetch(`${API_URL}/trading/close`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`
        },
        body: JSON.stringify({
          userId,
          tradeId
        })
      });

      const data = await res.json();

      if (data.error) {
        setMessage(`❌ ${data.error}`);
      } else {
        setMessage(`✅ ${data.message} - الربح: $${data.profit?.toFixed(2)}`);
        await fetchBalance();
        await fetchTrades();
        await fetchStats();
      }
    } catch (error) {
      console.error('Error closing trade:', error);
      setMessage('❌ خطأ في إغلاق الصفقة');
    } finally {
      setLoading(false);
    }
  };

  // Initial load
  useEffect(() => {
    fetchBalance();
    fetchStats();
    fetchTrades();
    fetchMarketPrice();
  }, []);

  // Auto-refresh price
  useEffect(() => {
    const interval = setInterval(() => {
      fetchMarketPrice();
    }, 5000); // Every 5 seconds

    return () => clearInterval(interval);
  }, [symbol]);

  return (
    <div className="space-y-6">
      {/* Stats Bar */}
      <div className="grid grid-cols-4 gap-4">
        <motion.div
          className="glass-gold rounded-xl p-4"
          whileHover={{ scale: 1.02 }}
        >
          <div className="text-xs opacity-70 mb-1">الرصيد</div>
          <motion.div
            className="text-2xl font-bold text-[#FFD700]"
            key={balance}
            initial={{ scale: 1.2 }}
            animate={{ scale: 1 }}
          >
            ${balance.toLocaleString('en-US', { minimumFractionDigits: 2 })}
          </motion.div>
        </motion.div>

        <div className="glass-gold rounded-xl p-4">
          <div className="text-xs opacity-70 mb-1">إجمالي الصفقات</div>
          <div className="text-2xl font-bold text-[#FFD700]">{stats.totalTrades}</div>
        </div>

        <div className="glass-gold rounded-xl p-4">
          <div className="text-xs opacity-70 mb-1">معدل النجاح</div>
          <div className="text-2xl font-bold text-[#FFD700]">{stats.winRate.toFixed(1)}%</div>
        </div>

        <div className="glass-gold rounded-xl p-4">
          <div className="text-xs opacity-70 mb-1">الربح الكلي</div>
          <div className={`text-2xl font-bold ${stats.totalProfit >= 0 ? 'text-green-500' : 'text-red-500'}`}>
            ${stats.totalProfit.toFixed(2)}
          </div>
        </div>
      </div>

      {/* Market Chart */}
      <motion.div
        className="glass rounded-2xl p-6"
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
      >
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-[#FFD700]">رسم بياني للسعر - {symbol}</h3>
          <motion.div
            className="text-3xl font-bold"
            key={currentPrice}
            initial={{ scale: 1.2, color: '#FFD700' }}
            animate={{ scale: 1, color: '#FFFFFF' }}
          >
            ${currentPrice.toFixed(2)}
          </motion.div>
        </div>

        {marketData.length > 0 ? (
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={marketData}>
                <defs>
                  <linearGradient id="goldGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#FFD700" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#FFD700" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                <XAxis dataKey="time" stroke="rgba(255,255,255,0.5)" />
                <YAxis stroke="rgba(255,255,255,0.5)" domain={['auto', 'auto']} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'rgba(10,10,10,0.9)',
                    border: '1px solid #FFD700',
                    borderRadius: '8px',
                  }}
                />
                <Area
                  type="monotone"
                  dataKey="price"
                  stroke="#FFD700"
                  strokeWidth={3}
                  fill="url(#goldGradient)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        ) : (
          <div className="h-64 flex items-center justify-center text-gray-500">
            جاري تحميل بيانات السوق...
          </div>
        )}
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Trading Panel */}
        <motion.div
          className="glass-gold rounded-2xl p-6"
          initial={{ x: -50, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
        >
          <h3 className="text-[#FFD700] mb-6">فتح صفقة جديدة</h3>

          <div className="space-y-4">
            <div>
              <label className="block text-sm mb-2">رمز السهم</label>
              <select
                className="w-full glass rounded-xl py-3 px-4 bg-black/30 border-none outline-none focus:ring-2 focus:ring-[#FFD700]"
                value={symbol}
                onChange={(e) => setSymbol(e.target.value)}
              >
                <option value="AAPL">Apple (AAPL)</option>
                <option value="GOOGL">Google (GOOGL)</option>
                <option value="TSLA">Tesla (TSLA)</option>
                <option value="AMZN">Amazon (AMZN)</option>
                <option value="MSFT">Microsoft (MSFT)</option>
              </select>
            </div>

            <div>
              <label className="block text-sm mb-2">الكمية</label>
              <input
                type="number"
                className="w-full glass rounded-xl py-3 px-4 bg-black/30 border-none outline-none focus:ring-2 focus:ring-[#FFD700]"
                value={amount}
                onChange={(e) => setAmount(parseFloat(e.target.value))}
                min="1"
              />
            </div>

            <div>
              <label className="block text-sm mb-2">نوع الصفقة</label>
              <div className="grid grid-cols-2 gap-3">
                <motion.button
                  className={`glass rounded-xl py-3 ${direction === 'buy' ? 'bg-green-500/20 ring-2 ring-green-500' : ''}`}
                  onClick={() => setDirection('buy')}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <TrendingUp className="w-5 h-5 mx-auto mb-1 text-green-500" />
                  شراء
                </motion.button>
                <motion.button
                  className={`glass rounded-xl py-3 ${direction === 'sell' ? 'bg-red-500/20 ring-2 ring-red-500' : ''}`}
                  onClick={() => setDirection('sell')}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <TrendingDown className="w-5 h-5 mx-auto mb-1 text-red-500" />
                  بيع
                </motion.button>
              </div>
            </div>

            <motion.button
              className="w-full glass-gold rounded-xl py-4 text-lg font-bold text-[#FFD700] disabled:opacity-50"
              onClick={handleOpenTrade}
              disabled={loading}
              whileHover={{ scale: loading ? 1 : 1.02 }}
              whileTap={{ scale: loading ? 1 : 0.98 }}
            >
              {loading ? 'جاري التنفيذ...' : 'تنفيذ الصفقة'}
            </motion.button>

            {message && (
              <motion.div
                className="glass rounded-xl p-3 text-sm text-center"
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
              >
                {message}
              </motion.div>
            )}
          </div>
        </motion.div>

        {/* Open Trades */}
        <motion.div
          className="glass rounded-2xl p-6"
          initial={{ x: 50, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
        >
          <h3 className="text-[#FFD700] mb-6">الصفقات المفتوحة ({openTrades.length})</h3>

          <div className="space-y-3 max-h-96 overflow-y-auto">
            <AnimatePresence>
              {openTrades.map((trade) => {
                const currentProfit = trade.direction === 'buy'
                  ? (currentPrice - trade.entryPrice) * trade.amount
                  : (trade.entryPrice - currentPrice) * trade.amount;

                return (
                  <motion.div
                    key={trade.id}
                    className="glass-gold rounded-xl p-4"
                    initial={{ scale: 0, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    exit={{ scale: 0, opacity: 0 }}
                    layout
                  >
                    <div className="flex justify-between items-start mb-3">
                      <div>
                        <div className="font-bold text-lg">{trade.symbol}</div>
                        <div className="text-xs opacity-70">
                          {trade.amount} سهم @ ${trade.entryPrice.toFixed(2)}
                        </div>
                      </div>
                      <div
                        className={`px-3 py-1 rounded-full text-xs ${
                          trade.direction === 'buy'
                            ? 'bg-green-500/20 text-green-500'
                            : 'bg-red-500/20 text-red-500'
                        }`}
                      >
                        {trade.direction === 'buy' ? 'شراء' : 'بيع'}
                      </div>
                    </div>

                    <div className="flex justify-between items-center mb-3">
                      <span className="text-sm opacity-70">الربح/الخسارة</span>
                      <motion.span
                        className={`text-lg font-bold ${currentProfit >= 0 ? 'text-green-500' : 'text-red-500'}`}
                        key={currentProfit}
                        initial={{ scale: 1.2 }}
                        animate={{ scale: 1 }}
                      >
                        ${currentProfit.toFixed(2)}
                      </motion.span>
                    </div>

                    <motion.button
                      className="w-full glass rounded-xl py-2 text-sm"
                      onClick={() => handleCloseTrade(trade.id)}
                      disabled={loading}
                      whileHover={{ scale: loading ? 1 : 1.02 }}
                      whileTap={{ scale: loading ? 1 : 0.98 }}
                    >
                      إغلاق الصفقة
                    </motion.button>
                  </motion.div>
                );
              })}
            </AnimatePresence>

            {openTrades.length === 0 && (
              <div className="text-center py-8 opacity-50">
                لا توجد صفقات مفتوحة
              </div>
            )}
          </div>
        </motion.div>
      </div>
    </div>
  );
}