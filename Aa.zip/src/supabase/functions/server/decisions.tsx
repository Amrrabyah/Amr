import * as kv from './kv_store.tsx';

interface DecisionScenario {
  id: string;
  title: string;
  description: string;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  context: string;
  question: string;
  options: {
    id: string;
    text: string;
    impact: number;
    explanation: string;
  }[];
  correctOptionId: string;
  points: number;
  category: string;
}

// Initialize decision scenarios
export async function initializeScenarios(): Promise<void> {
  const scenarios: DecisionScenario[] = [
    {
      id: 'scenario_1',
      title: 'قرار استثماري عاجل',
      description: 'شركة تقنية تعلن عن ابتكار جديد',
      difficulty: 'beginner',
      context: 'شركة Apple أعلنت عن منتج ثوري جديد. السهم ارتفع 5% في أول ساعة من التداول.',
      question: 'ما هو أفضل قرار استثماري؟',
      options: [
        {
          id: 'opt_1_a',
          text: 'الشراء الفوري للاستفادة من الزخم',
          impact: -5,
          explanation: 'قد يكون السعر مبالغاً فيه بعد الارتفاع المفاجئ'
        },
        {
          id: 'opt_1_b',
          text: 'الانتظار لمدة أسبوع لتحليل ردود فعل السوق',
          impact: 15,
          explanation: 'قرار ممتاز! التحليل الهادئ يؤدي لقرارات أفضل'
        },
        {
          id: 'opt_1_c',
          text: 'البيع على المكشوف لتوقع انخفاض السعر',
          impact: -10,
          explanation: 'البيع على المكشوف في اتجاه صعودي مخاطرة عالية'
        }
      ],
      correctOptionId: 'opt_1_b',
      points: 100,
      category: 'stock_market'
    },
    {
      id: 'scenario_2',
      title: 'إدارة المخاطر',
      description: 'محفظتك الاستثمارية انخفضت 15%',
      difficulty: 'intermediate',
      context: 'السوق يشهد تراجعاً عاماً، ومحفظتك انخفضت 15% في أسبوع واحد.',
      question: 'كيف تتصرف؟',
      options: [
        {
          id: 'opt_2_a',
          text: 'البيع الفوري لتجنب المزيد من الخسائر',
          impact: -15,
          explanation: 'البيع بخسارة قد يكون قراراً عاطفياً خاطئاً'
        },
        {
          id: 'opt_2_b',
          text: 'مراجعة أساسيات الشركات والاحتفاظ بالجيد منها',
          impact: 20,
          explanation: 'ممتاز! الاستثمار بناءً على الأساسيات وليس العواطف'
        },
        {
          id: 'opt_2_c',
          text: 'شراء المزيد للاستفادة من الأسعار المنخفضة',
          impact: 5,
          explanation: 'جيد، لكن تأكد من سلامة الشركات أولاً'
        }
      ],
      correctOptionId: 'opt_2_b',
      points: 150,
      category: 'risk_management'
    },
    {
      id: 'scenario_3',
      title: 'قرار عقاري استراتيجي',
      description: 'فرصة شراء عقار في موقع متطور',
      difficulty: 'advanced',
      context: 'عقار في حي جديد بسعر 800,000 ريال. الحكومة تخطط لبناء مترو في المنطقة خلال 3 سنوات.',
      question: 'ما هي استراتيجيتك؟',
      options: [
        {
          id: 'opt_3_a',
          text: 'الشراء الفوري بالكامل نقداً',
          impact: 10,
          explanation: 'جيد، لكن قد تفقد سيولة مالية مهمة'
        },
        {
          id: 'opt_3_b',
          text: 'استخدام التمويل العقاري بدفعة مقدمة 30%',
          impact: 25,
          explanation: 'ممتاز! الاستفادة من الرافعة المالية مع الحفاظ على السيولة'
        },
        {
          id: 'opt_3_c',
          text: 'الانتظار حتى يبدأ بناء المترو',
          impact: -5,
          explanation: 'السعر سيرتفع كثيراً بمجرد بدء البناء'
        }
      ],
      correctOptionId: 'opt_3_b',
      points: 200,
      category: 'real_estate'
    },
    {
      id: 'scenario_4',
      title: 'علم النفس التجاري',
      description: 'ضغط نفسي بعد صفقات خاسرة',
      difficulty: 'intermediate',
      context: 'خسرت في 3 صفقات متتالية. تشعر برغبة قوية في تعويض الخسائر سريعاً.',
      question: 'ما هو القرار الأمثل؟',
      options: [
        {
          id: 'opt_4_a',
          text: 'فتح صفقة كبيرة لتعويض الخسائر',
          impact: -20,
          explanation: 'خطأ كبير! هذا يسمى "Revenge Trading" وهو مدمر'
        },
        {
          id: 'opt_4_b',
          text: 'أخذ استراحة وتحليل الأخطاء',
          impact: 25,
          explanation: 'قرار حكيم جداً! الانضباط النفسي أهم من التعويض السريع'
        },
        {
          id: 'opt_4_c',
          text: 'تقليل حجم الصفقات والعودة تدريجياً',
          impact: 15,
          explanation: 'جيد! نهج حذر ومتوازن'
        }
      ],
      correctOptionId: 'opt_4_b',
      points: 180,
      category: 'psychology'
    },
    {
      id: 'scenario_5',
      title: 'تحليل البيانات المالية',
      description: 'تقرير أرباح ربع سنوي مختلط',
      difficulty: 'advanced',
      context: 'شركة أعلنت عن زيادة الإيرادات 20% لكن الأرباح انخفضت 5%. الإدارة تتحدث عن استثمارات طويلة الأجل.',
      question: 'كيف تقيّم الوضع؟',
      options: [
        {
          id: 'opt_5_a',
          text: 'بيع السهم فوراً بسبب انخفاض الأرباح',
          impact: -10,
          explanation: 'نظرة قصيرة المدى. الاستثمارات قد تكون إيجابية'
        },
        {
          id: 'opt_5_b',
          text: 'دراسة تفاصيل الاستثمارات والاحتفاظ إذا كانت استراتيجية',
          impact: 30,
          explanation: 'ممتاز! تحليل عميق للأساسيات وليس الأرقام السطحية'
        },
        {
          id: 'opt_5_c',
          text: 'الشراء فوراً بسبب زيادة الإيرادات',
          impact: 0,
          explanation: 'متسرع. يجب فهم سبب انخفاض الأرباح أولاً'
        }
      ],
      correctOptionId: 'opt_5_b',
      points: 250,
      category: 'financial_analysis'
    }
  ];

  for (const scenario of scenarios) {
    await kv.set(`scenario:${scenario.id}`, JSON.stringify(scenario));
  }
}

// Get random scenario
export async function getRandomScenario(
  difficulty?: 'beginner' | 'intermediate' | 'advanced'
): Promise<DecisionScenario | null> {
  try {
    const scenarios = await kv.getByPrefix('scenario:');
    
    if (scenarios.length === 0) {
      // Initialize if empty
      await initializeScenarios();
      return getRandomScenario(difficulty);
    }

    let filteredScenarios = scenarios.map(s => JSON.parse(s));
    
    if (difficulty) {
      filteredScenarios = filteredScenarios.filter(
        s => s.difficulty === difficulty
      );
    }

    if (filteredScenarios.length === 0) {
      return null;
    }

    const randomIndex = Math.floor(Math.random() * filteredScenarios.length);
    const scenario = filteredScenarios[randomIndex];
    
    // Return scenario without correct answer
    const { correctOptionId, ...scenarioWithoutAnswer } = scenario;
    return scenarioWithoutAnswer;
  } catch (error) {
    console.error('Error getting scenario:', error);
    return null;
  }
}

// Submit solution
export async function submitSolution(
  userId: string,
  scenarioId: string,
  selectedOptionId: string,
  timeTaken: number
): Promise<{
  success: boolean;
  isCorrect?: boolean;
  score?: number;
  explanation?: string;
  message?: string;
}> {
  try {
    // Get scenario
    const scenarioStr = await kv.get(`scenario:${scenarioId}`);
    if (!scenarioStr) {
      return {
        success: false,
        message: 'السيناريو غير موجود'
      };
    }

    const scenario: DecisionScenario = JSON.parse(scenarioStr);

    // Check if correct
    const isCorrect = selectedOptionId === scenario.correctOptionId;
    
    // Find selected option
    const selectedOption = scenario.options.find(opt => opt.id === selectedOptionId);
    if (!selectedOption) {
      return {
        success: false,
        message: 'الخيار المحدد غير صحيح'
      };
    }

    // Calculate score (with time bonus)
    let score = 0;
    if (isCorrect) {
      score = scenario.points;
      
      // Time bonus (if answered in less than 30 seconds)
      if (timeTaken < 30) {
        const timeBonus = Math.floor((30 - timeTaken) / 30 * scenario.points * 0.2);
        score += timeBonus;
      }
    } else {
      // Partial points for effort
      score = Math.floor(scenario.points * 0.1);
    }

    // Save attempt
    const attemptId = `attempt_${userId}_${Date.now()}`;
    const attempt = {
      id: attemptId,
      userId,
      scenarioId,
      selectedOptionId,
      isCorrect,
      score,
      timeTaken,
      timestamp: new Date().toISOString()
    };

    await kv.set(`attempt:${attemptId}`, JSON.stringify(attempt));

    // Update user stats
    const statsKey = `decision_stats:${userId}`;
    const statsStr = await kv.get(statsKey);
    const stats = statsStr ? JSON.parse(statsStr) : {
      totalAttempts: 0,
      correctAttempts: 0,
      totalScore: 0,
      averageTime: 0,
      byCategory: {}
    };

    stats.totalAttempts += 1;
    if (isCorrect) {
      stats.correctAttempts += 1;
    }
    stats.totalScore += score;
    stats.averageTime = (stats.averageTime * (stats.totalAttempts - 1) + timeTaken) / stats.totalAttempts;

    // Category stats
    if (!stats.byCategory[scenario.category]) {
      stats.byCategory[scenario.category] = {
        attempts: 0,
        correct: 0,
        score: 0
      };
    }
    stats.byCategory[scenario.category].attempts += 1;
    if (isCorrect) {
      stats.byCategory[scenario.category].correct += 1;
    }
    stats.byCategory[scenario.category].score += score;

    await kv.set(statsKey, JSON.stringify(stats));

    // Award XP
    const xpKey = `xp:${userId}`;
    const currentXP = await kv.get(xpKey);
    const newXP = (currentXP ? parseInt(currentXP) : 0) + score;
    await kv.set(xpKey, newXP.toString());

    return {
      success: true,
      isCorrect,
      score,
      explanation: selectedOption.explanation,
      message: isCorrect ? '🎉 إجابة صحيحة!' : '❌ إجابة خاطئة، حاول مرة أخرى'
    };
  } catch (error) {
    console.error('Error submitting solution:', error);
    return {
      success: false,
      message: 'خطأ في تقييم الحل'
    };
  }
}

// Get user decision statistics
export async function getUserDecisionStats(userId: string): Promise<any> {
  const statsKey = `decision_stats:${userId}`;
  const statsStr = await kv.get(statsKey);
  
  if (!statsStr) {
    return {
      totalAttempts: 0,
      correctAttempts: 0,
      totalScore: 0,
      accuracy: 0,
      averageTime: 0,
      byCategory: {}
    };
  }

  const stats = JSON.parse(statsStr);
  stats.accuracy = stats.totalAttempts > 0 
    ? (stats.correctAttempts / stats.totalAttempts * 100).toFixed(2)
    : 0;

  return stats;
}

// Analyze decision patterns (anti-cheat)
export async function analyzeDecisionPatterns(userId: string): Promise<{
  suspicious: boolean;
  reasons: string[];
}> {
  const stats = await getUserDecisionStats(userId);
  const reasons: string[] = [];
  let suspicious = false;

  // Check for impossibly high accuracy
  if (stats.totalAttempts > 10 && stats.accuracy > 95) {
    suspicious = true;
    reasons.push('دقة عالية بشكل غير طبيعي');
  }

  // Check for impossibly fast answers
  if (stats.averageTime < 5) {
    suspicious = true;
    reasons.push('سرعة إجابة غير طبيعية');
  }

  // Check recent attempts
  const recentAttempts = await kv.getByPrefix(`attempt:${userId}`);
  const parsed = recentAttempts.map(a => JSON.parse(a));
  const last10 = parsed.slice(-10);
  
  if (last10.length === 10 && last10.every(a => a.isCorrect)) {
    suspicious = true;
    reasons.push('10 إجابات صحيحة متتالية');
  }

  return { suspicious, reasons };
}

// Generate personalized recommendations
export async function generateRecommendations(userId: string): Promise<string[]> {
  const stats = await getUserDecisionStats(userId);
  const recommendations: string[] = [];

  if (!stats.byCategory || Object.keys(stats.byCategory).length === 0) {
    recommendations.push('🎯 ابدأ بحل السيناريوهات للحصول على توصيات مخصصة');
    return recommendations;
  }

  // Find weakest category
  let weakestCategory = '';
  let lowestAccuracy = 100;

  for (const [category, data] of Object.entries(stats.byCategory) as any) {
    const accuracy = (data.correct / data.attempts) * 100;
    if (accuracy < lowestAccuracy) {
      lowestAccuracy = accuracy;
      weakestCategory = category;
    }
  }

  const categoryNames: Record<string, string> = {
    stock_market: 'سوق الأسهم',
    risk_management: 'إدارة المخاطر',
    real_estate: 'العقارات',
    psychology: 'علم النفس التجاري',
    financial_analysis: 'التحليل المالي'
  };

  if (lowestAccuracy < 60) {
    recommendations.push(
      `📚 ركز على تحسين مهاراتك في ${categoryNames[weakestCategory] || weakestCategory}`
    );
  }

  if (stats.averageTime > 60) {
    recommendations.push('⏱️ حاول تحسين سرعة اتخاذ القرار مع الحفاظ على الدقة');
  }

  if (stats.accuracy > 80) {
    recommendations.push('🌟 أداء ممتاز! حاول السيناريوهات الأكثر تقدماً');
  }

  if (stats.totalAttempts < 10) {
    recommendations.push('💪 قم بحل المزيد من السيناريوهات لبناء خبرة أكبر');
  }

  return recommendations;
}
