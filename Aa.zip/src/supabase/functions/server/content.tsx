import * as kv from './kv_store.tsx';

interface Video {
  id: string;
  title: string;
  description: string;
  duration: number; // seconds
  category: 'تداول' | 'عقارات' | 'ريادة أعمال' | 'تخطيط مالي';
  level: 'مبتدئ' | 'متوسط' | 'متقدم';
  thumbnail: string;
  videoUrl: string;
  transcript?: string;
  resources: Array<{ title: string; url: string }>;
  owner: string;
  views: number;
  averageRating: number;
  ratings: Array<{ userId: string; value: number }>;
  isVerified: boolean;
  createdAt: string;
  updatedAt: string;
}

interface Quiz {
  id: string;
  title: string;
  questions: Array<{
    id: string;
    text: string;
    options: string[];
    correctAnswer: number;
    explanation: string;
  }>;
  passingScore: number;
  timeLimit: number; // minutes
  relatedVideoId?: string;
  category: string;
  level: string;
  createdAt: string;
}

interface QuizSession {
  id: string;
  userId: string;
  quizId: string;
  startTime: string;
  endTime: string;
  answers: Array<{
    questionId: string;
    answer: number;
    timestamp: string;
  }>;
  score?: number;
  isCompleted: boolean;
  timeTaken?: number;
}

interface Certificate {
  id: string;
  userId: string;
  courseId: string;
  courseName: string;
  issueDate: string;
  expirationDate?: string;
  verificationCode: string;
  grade: number;
  nftMetadata?: {
    tokenId?: string;
    contractAddress?: string;
    explorerUrl?: string;
  };
}

// Create video
export async function createVideo(data: {
  title: string;
  description: string;
  duration: number;
  category: Video['category'];
  level: Video['level'];
  videoUrl: string;
  owner: string;
  thumbnail?: string;
  transcript?: string;
  resources?: Array<{ title: string; url: string }>;
}): Promise<Video> {
  const videoId = `video_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

  const video: Video = {
    id: videoId,
    title: data.title,
    description: data.description,
    duration: data.duration,
    category: data.category,
    level: data.level,
    thumbnail: data.thumbnail || '/default-thumbnail.jpg',
    videoUrl: data.videoUrl,
    transcript: data.transcript,
    resources: data.resources || [],
    owner: data.owner,
    views: 0,
    averageRating: 0,
    ratings: [],
    isVerified: false,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };

  await kv.set(`video:${videoId}`, JSON.stringify(video));
  await kv.set(`video_by_owner:${data.owner}:${videoId}`, videoId);

  return video;
}

// Get video
export async function getVideo(videoId: string): Promise<Video | null> {
  const data = await kv.get(`video:${videoId}`);
  return data ? JSON.parse(data) : null;
}

// List videos with filters
export async function listVideos(filters?: {
  category?: string;
  level?: string;
  owner?: string;
}): Promise<Video[]> {
  const prefix = 'video:video_';
  const videoStrs = await kv.getByPrefix(prefix);

  let videos: Video[] = videoStrs.map(str => JSON.parse(str));

  if (filters?.category) {
    videos = videos.filter(v => v.category === filters.category);
  }
  if (filters?.level) {
    videos = videos.filter(v => v.level === filters.level);
  }
  if (filters?.owner) {
    videos = videos.filter(v => v.owner === filters.owner);
  }

  return videos.sort((a, b) => 
    new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  );
}

// Increment video views
export async function incrementViews(videoId: string): Promise<number> {
  const video = await getVideo(videoId);
  if (!video) throw new Error('Video not found');

  video.views += 1;
  video.updatedAt = new Date().toISOString();
  
  await kv.set(`video:${videoId}`, JSON.stringify(video));
  return video.views;
}

// Rate video
export async function rateVideo(
  videoId: string,
  userId: string,
  rating: number
): Promise<{ averageRating: number }> {
  const video = await getVideo(videoId);
  if (!video) throw new Error('Video not found');

  // Remove existing rating from this user
  video.ratings = video.ratings.filter(r => r.userId !== userId);
  
  // Add new rating
  video.ratings.push({ userId, value: rating });

  // Calculate average
  const sum = video.ratings.reduce((acc, r) => acc + r.value, 0);
  video.averageRating = parseFloat((sum / video.ratings.length).toFixed(2));
  video.updatedAt = new Date().toISOString();

  await kv.set(`video:${videoId}`, JSON.stringify(video));

  return { averageRating: video.averageRating };
}

// Create quiz
export async function createQuiz(data: {
  title: string;
  questions: Quiz['questions'];
  passingScore?: number;
  timeLimit?: number;
  relatedVideoId?: string;
  category: string;
  level: string;
}): Promise<Quiz> {
  const quizId = `quiz_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

  const quiz: Quiz = {
    id: quizId,
    title: data.title,
    questions: data.questions.map((q, i) => ({
      ...q,
      id: `q_${i + 1}`
    })),
    passingScore: data.passingScore || 70,
    timeLimit: data.timeLimit || 30,
    relatedVideoId: data.relatedVideoId,
    category: data.category,
    level: data.level,
    createdAt: new Date().toISOString()
  };

  await kv.set(`quiz:${quizId}`, JSON.stringify(quiz));
  
  return quiz;
}

// Get quiz
export async function getQuiz(quizId: string): Promise<Quiz | null> {
  const data = await kv.get(`quiz:${quizId}`);
  return data ? JSON.parse(data) : null;
}

// Start quiz session
export async function startQuizSession(
  userId: string,
  quizId: string
): Promise<QuizSession> {
  const quiz = await getQuiz(quizId);
  if (!quiz) throw new Error('Quiz not found');

  const sessionId = `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  const now = new Date();
  const endTime = new Date(now.getTime() + quiz.timeLimit * 60000);

  const session: QuizSession = {
    id: sessionId,
    userId,
    quizId,
    startTime: now.toISOString(),
    endTime: endTime.toISOString(),
    answers: [],
    isCompleted: false
  };

  await kv.set(`quiz_session:${sessionId}`, JSON.stringify(session));
  await kv.set(`quiz_session_user:${userId}:${sessionId}`, sessionId);

  return session;
}

// Submit answer
export async function submitAnswer(
  sessionId: string,
  questionId: string,
  answer: number
): Promise<{ success: boolean; message?: string }> {
  const sessionStr = await kv.get(`quiz_session:${sessionId}`);
  if (!sessionStr) throw new Error('Session not found');

  const session: QuizSession = JSON.parse(sessionStr);

  // Check if time is up
  if (new Date() > new Date(session.endTime)) {
    return { success: false, message: 'انتهى وقت الاختبار' };
  }

  // Check if already answered
  if (session.answers.some(a => a.questionId === questionId)) {
    return { success: false, message: 'تم الإجابة على هذا السؤال مسبقاً' };
  }

  // Add answer
  session.answers.push({
    questionId,
    answer,
    timestamp: new Date().toISOString()
  });

  await kv.set(`quiz_session:${sessionId}`, JSON.stringify(session));

  return { success: true };
}

// Complete quiz session
export async function completeQuizSession(
  sessionId: string
): Promise<{
  score: number;
  passed: boolean;
  correctAnswers: number;
  totalQuestions: number;
  certificate?: Certificate;
}> {
  const sessionStr = await kv.get(`quiz_session:${sessionId}`);
  if (!sessionStr) throw new Error('Session not found');

  const session: QuizSession = JSON.parse(sessionStr);
  const quiz = await getQuiz(session.quizId);
  if (!quiz) throw new Error('Quiz not found');

  // Calculate score
  let correctAnswers = 0;
  for (const answer of session.answers) {
    const question = quiz.questions.find(q => q.id === answer.questionId);
    if (question && question.correctAnswer === answer.answer) {
      correctAnswers++;
    }
  }

  const score = Math.round((correctAnswers / quiz.questions.length) * 100);
  const passed = score >= quiz.passingScore;

  // Update session
  session.score = score;
  session.isCompleted = true;
  session.timeTaken = Math.floor(
    (new Date().getTime() - new Date(session.startTime).getTime()) / 1000
  );

  await kv.set(`quiz_session:${sessionId}`, JSON.stringify(session));

  // Issue certificate if passed
  let certificate: Certificate | undefined;
  if (passed) {
    certificate = await issueCertificate(
      session.userId,
      quiz.relatedVideoId || quiz.id,
      quiz.title,
      score
    );
  }

  return {
    score,
    passed,
    correctAnswers,
    totalQuestions: quiz.questions.length,
    certificate
  };
}

// Issue certificate
export async function issueCertificate(
  userId: string,
  courseId: string,
  courseName: string,
  grade: number
): Promise<Certificate> {
  const certificateId = `cert_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  const verificationCode = Math.random().toString(36).substr(2, 12).toUpperCase();

  const certificate: Certificate = {
    id: certificateId,
    userId,
    courseId,
    courseName,
    issueDate: new Date().toISOString(),
    expirationDate: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString(),
    verificationCode,
    grade
  };

  await kv.set(`certificate:${certificateId}`, JSON.stringify(certificate));
  await kv.set(`certificate_code:${verificationCode}`, certificateId);
  await kv.set(`certificate_user:${userId}:${certificateId}`, certificateId);

  return certificate;
}

// Get user certificates
export async function getUserCertificates(userId: string): Promise<Certificate[]> {
  const prefix = `certificate_user:${userId}:`;
  const certIds = await kv.getByPrefix(prefix);

  const certificates: Certificate[] = [];
  for (const id of certIds) {
    const certStr = await kv.get(`certificate:${id}`);
    if (certStr) {
      certificates.push(JSON.parse(certStr));
    }
  }

  return certificates.sort((a, b) => 
    new Date(b.issueDate).getTime() - new Date(a.issueDate).getTime()
  );
}

// Verify certificate
export async function verifyCertificate(
  verificationCode: string
): Promise<{ valid: boolean; certificate?: Certificate }> {
  const certId = await kv.get(`certificate_code:${verificationCode}`);
  if (!certId) {
    return { valid: false };
  }

  const certStr = await kv.get(`certificate:${certId}`);
  if (!certStr) {
    return { valid: false };
  }

  const certificate: Certificate = JSON.parse(certStr);

  // Check expiration
  if (certificate.expirationDate && new Date() > new Date(certificate.expirationDate)) {
    return { valid: false };
  }

  return { valid: true, certificate };
}

// Get recommendations based on user activity
export async function getContentRecommendations(
  userId: string,
  limit: number = 5
): Promise<Video[]> {
  // Get all videos
  const allVideos = await listVideos();

  // Simple recommendation: highest rated + most viewed
  const scored = allVideos.map(v => ({
    ...v,
    recommendScore: (v.averageRating * 0.6) + (Math.log(v.views + 1) * 0.4)
  }));

  scored.sort((a, b) => b.recommendScore - a.recommendScore);

  return scored.slice(0, limit);
}
