import * as kv from './kv_store.tsx';

interface PerformanceMetrics {
  tradingPerformance: {
    winRate: number;
    totalTrades: number;
    profitFactor: number;
    maxDrawdown: number;
    sharpeRatio: number;
    averageWin: number;
    averageLoss: number;
  };
  learningProgress: {
    coursesCompleted: number;
    quizScore: number;
    studyTime: number;
    consistency: number;
  };
  riskProfile: {
    riskScore: number;
    riskLevel: 'low' | 'medium' | 'high' | 'very_high';
    indicators: string[];
  };
}

// Calculate trading performance metrics
export async function calculateTradingMetrics(
  userId: string,
  simulationId: string
): Promise<PerformanceMetrics['tradingPerformance']> {
  try {
    // Get stats
    const statsKey = `stats:${userId}:${simulationId}`;
    const statsStr = await kv.get(statsKey);
    const stats = statsStr ? JSON.parse(statsStr) : {
      totalTrades: 0,
      winningTrades: 0,
      totalProfit: 0,
      maxDrawdown: 0
    };
    
    // Get trade history
    const prefix = `trade:${userId}`;
    const trades = await kv.getByPrefix(prefix);
    const parsedTrades = trades.map(t => JSON.parse(t)).filter(t => t.simulationId === simulationId);
    
    // Calculate metrics
    const winRate = stats.totalTrades > 0 
      ? (stats.winningTrades / stats.totalTrades) * 100 
      : 0;
    
    // Calculate average win/loss
    const closedTrades = parsedTrades.filter(t => t.status === 'closed' && t.profit !== undefined);
    const wins = closedTrades.filter(t => t.profit > 0);
    const losses = closedTrades.filter(t => t.profit < 0);
    
    const averageWin = wins.length > 0
      ? wins.reduce((sum, t) => sum + t.profit, 0) / wins.length
      : 0;
    
    const averageLoss = losses.length > 0
      ? Math.abs(losses.reduce((sum, t) => sum + t.profit, 0) / losses.length)
      : 0;
    
    // Profit factor (gross profit / gross loss)
    const grossProfit = wins.reduce((sum, t) => sum + t.profit, 0);
    const grossLoss = Math.abs(losses.reduce((sum, t) => sum + t.profit, 0));
    const profitFactor = grossLoss > 0 ? grossProfit / grossLoss : 0;
    
    // Sharpe Ratio (simplified - risk-adjusted return)
    const returns = closedTrades.map(t => t.profit);
    const avgReturn = returns.length > 0 
      ? returns.reduce((a, b) => a + b, 0) / returns.length 
      : 0;
    const stdDev = calculateStdDev(returns);
    const sharpeRatio = stdDev > 0 ? avgReturn / stdDev : 0;
    
    return {
      winRate: parseFloat(winRate.toFixed(2)),
      totalTrades: stats.totalTrades,
      profitFactor: parseFloat(profitFactor.toFixed(2)),
      maxDrawdown: stats.maxDrawdown,
      sharpeRatio: parseFloat(sharpeRatio.toFixed(2)),
      averageWin: parseFloat(averageWin.toFixed(2)),
      averageLoss: parseFloat(averageLoss.toFixed(2))
    };
  } catch (error) {
    console.error('Error calculating trading metrics:', error);
    return {
      winRate: 0,
      totalTrades: 0,
      profitFactor: 0,
      maxDrawdown: 0,
      sharpeRatio: 0,
      averageWin: 0,
      averageLoss: 0
    };
  }
}

// Calculate standard deviation
function calculateStdDev(values: number[]): number {
  if (values.length === 0) return 0;
  
  const avg = values.reduce((a, b) => a + b, 0) / values.length;
  const squareDiffs = values.map(value => Math.pow(value - avg, 2));
  const avgSquareDiff = squareDiffs.reduce((a, b) => a + b, 0) / squareDiffs.length;
  
  return Math.sqrt(avgSquareDiff);
}

// Calculate learning progress
export async function calculateLearningProgress(
  userId: string
): Promise<PerformanceMetrics['learningProgress']> {
  try {
    // Get activity
    const activityKey = `activity:${userId}`;
    const activityStr = await kv.get(activityKey);
    const activity = activityStr ? JSON.parse(activityStr) : {
      completedCourses: [],
      timeSpent: {}
    };
    
    // Get decision stats
    const decisionStatsKey = `decision_stats:${userId}`;
    const decisionStatsStr = await kv.get(decisionStatsKey);
    const decisionStats = decisionStatsStr ? JSON.parse(decisionStatsStr) : {
      totalAttempts: 0,
      correctAttempts: 0,
      totalScore: 0
    };
    
    // Calculate total study time
    const studyTime = Object.values(activity.timeSpent as Record<string, number>)
      .reduce((a, b) => a + b, 0);
    
    // Calculate quiz score (from decision scenarios)
    const quizScore = decisionStats.totalAttempts > 0
      ? (decisionStats.correctAttempts / decisionStats.totalAttempts) * 100
      : 0;
    
    // Calculate consistency (days active in last 30 days)
    const historyKey = `ai_history:${userId}`;
    const historyStr = await kv.get(historyKey);
    const history = historyStr ? JSON.parse(historyStr) : [];
    
    const last30Days = new Date();
    last30Days.setDate(last30Days.getDate() - 30);
    
    const activeDays = new Set(
      history
        .filter((entry: any) => new Date(entry.timestamp) > last30Days)
        .map((entry: any) => new Date(entry.timestamp).toDateString())
    );
    
    const consistency = (activeDays.size / 30) * 100;
    
    return {
      coursesCompleted: activity.completedCourses.length,
      quizScore: parseFloat(quizScore.toFixed(2)),
      studyTime: Math.round(studyTime),
      consistency: parseFloat(consistency.toFixed(2))
    };
  } catch (error) {
    console.error('Error calculating learning progress:', error);
    return {
      coursesCompleted: 0,
      quizScore: 0,
      studyTime: 0,
      consistency: 0
    };
  }
}

// Detect risk patterns
export async function detectRiskPatterns(
  userId: string,
  simulationId: string
): Promise<PerformanceMetrics['riskProfile']> {
  try {
    let riskScore = 0;
    const indicators: string[] = [];
    
    // Get trade data
    const prefix = `trade:${userId}`;
    const trades = await kv.getByPrefix(prefix);
    const parsedTrades = trades
      .map(t => JSON.parse(t))
      .filter(t => t.simulationId === simulationId)
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
    
    if (parsedTrades.length === 0) {
      return {
        riskScore: 0,
        riskLevel: 'low',
        indicators: []
      };
    }
    
    // 1. Rapid trading pattern (overtrading)
    const last24h = new Date();
    last24h.setHours(last24h.getHours() - 24);
    const tradesLast24h = parsedTrades.filter(
      t => new Date(t.timestamp) > last24h
    );
    
    if (tradesLast24h.length > 20) {
      riskScore += 25;
      indicators.push('⚠️ Overtrading: أكثر من 20 صفقة في 24 ساعة');
    } else if (tradesLast24h.length > 10) {
      riskScore += 15;
      indicators.push('⚡ تداول نشط جداً: راقب قراراتك');
    }
    
    // 2. Revenge trading pattern (rapid trades after loss)
    const recentTrades = parsedTrades.slice(0, 10);
    let consecutiveLosses = 0;
    let tradesAfterLoss = 0;
    
    for (let i = 0; i < recentTrades.length; i++) {
      if (recentTrades[i].profit && recentTrades[i].profit < 0) {
        consecutiveLosses++;
        
        // Check if next trade was very quick (< 5 minutes)
        if (i < recentTrades.length - 1) {
          const timeDiff = new Date(recentTrades[i].timestamp).getTime() - 
                          new Date(recentTrades[i + 1].timestamp).getTime();
          if (timeDiff < 5 * 60 * 1000) {
            tradesAfterLoss++;
          }
        }
      } else {
        consecutiveLosses = 0;
      }
    }
    
    if (tradesAfterLoss >= 3) {
      riskScore += 30;
      indicators.push('🔴 Revenge Trading: تداول انتقامي محتمل - خذ استراحة!');
    }
    
    if (consecutiveLosses >= 5) {
      riskScore += 20;
      indicators.push('📉 سلسلة خسائر طويلة: راجع استراتيجيتك');
    }
    
    // 3. Position sizing issues
    const stats = await kv.get(`stats:${userId}:${simulationId}`);
    const parsedStats = stats ? JSON.parse(stats) : { maxDrawdown: 0 };
    
    if (parsedStats.maxDrawdown > 2000) {
      riskScore += 25;
      indicators.push('💸 خسارة كبيرة في صفقة واحدة: راجع إدارة المخاطر');
    }
    
    // 4. Consistency issues
    const closedTrades = parsedTrades.filter(t => t.status === 'closed' && t.profit !== undefined);
    if (closedTrades.length >= 10) {
      const profits = closedTrades.map(t => t.profit);
      const stdDev = calculateStdDev(profits);
      const avgProfit = profits.reduce((a, b) => a + b, 0) / profits.length;
      
      // High volatility in results
      if (stdDev > Math.abs(avgProfit) * 3) {
        riskScore += 15;
        indicators.push('📊 تذبذب عالي في النتائج: ركز على الاتساق');
      }
    }
    
    // 5. No stop-loss usage detection
    // (In real system, we'd check if trades have stop-loss set)
    
    // Determine risk level
    let riskLevel: 'low' | 'medium' | 'high' | 'very_high';
    if (riskScore >= 70) {
      riskLevel = 'very_high';
      indicators.unshift('🚨 مستوى خطر عالي جداً - توقف عن التداول وراجع استراتيجيتك!');
    } else if (riskScore >= 50) {
      riskLevel = 'high';
      indicators.unshift('⚠️ مستوى خطر عالي - كن حذراً');
    } else if (riskScore >= 30) {
      riskLevel = 'medium';
      indicators.unshift('⚡ مستوى خطر متوسط - راقب قراراتك');
    } else {
      riskLevel = 'low';
      if (indicators.length === 0) {
        indicators.push('✅ أداء جيد - استمر في الانضباط');
      }
    }
    
    return {
      riskScore,
      riskLevel,
      indicators
    };
  } catch (error) {
    console.error('Error detecting risk patterns:', error);
    return {
      riskScore: 0,
      riskLevel: 'low',
      indicators: []
    };
  }
}

// Generate comprehensive performance report
export async function generatePerformanceReport(
  userId: string,
  simulationId: string
): Promise<{
  metrics: PerformanceMetrics;
  insights: string[];
  recommendations: string[];
  grade: string;
}> {
  // Get all metrics
  const tradingPerformance = await calculateTradingMetrics(userId, simulationId);
  const learningProgress = await calculateLearningProgress(userId);
  const riskProfile = await detectRiskPatterns(userId, simulationId);
  
  const metrics: PerformanceMetrics = {
    tradingPerformance,
    learningProgress,
    riskProfile
  };
  
  // Generate insights
  const insights: string[] = [];
  const recommendations: string[] = [];
  
  // Trading insights
  if (tradingPerformance.winRate > 60) {
    insights.push('🎯 معدل نجاح ممتاز في التداول');
  } else if (tradingPerformance.winRate < 40) {
    insights.push('📉 معدل نجاح منخفض - راجع استراتيجيتك');
    recommendations.push('📚 راجع دورة "إدارة المخاطر في التداول"');
  }
  
  if (tradingPerformance.profitFactor > 2) {
    insights.push('💰 عامل ربح ممتاز - أرباحك أعلى من خسائرك');
  } else if (tradingPerformance.profitFactor < 1) {
    insights.push('⚠️ خسائرك أكبر من أرباحك');
    recommendations.push('🎓 تعلم استراتيجيات التداول المربحة');
  }
  
  if (tradingPerformance.sharpeRatio > 1) {
    insights.push('📊 عائد ممتاز مقارنة بالمخاطرة');
  }
  
  // Learning insights
  if (learningProgress.consistency > 70) {
    insights.push('⭐ التزام ممتاز في التعلم');
  } else if (learningProgress.consistency < 30) {
    insights.push('📅 قلة انتظام في التعلم');
    recommendations.push('⏰ خصص 30 دقيقة يومياً للتعلم');
  }
  
  if (learningProgress.quizScore > 80) {
    insights.push('🧠 استيعاب ممتاز للمفاهيم');
  } else if (learningProgress.quizScore < 60) {
    insights.push('📖 يحتاج المزيد من المراجعة');
    recommendations.push('🔄 أعد حل التمارين والاختبارات');
  }
  
  // Risk insights (already in indicators)
  insights.push(...riskProfile.indicators);
  
  // Calculate overall grade
  let gradeScore = 0;
  gradeScore += Math.min(tradingPerformance.winRate, 100) * 0.3;
  gradeScore += Math.min(tradingPerformance.profitFactor * 20, 100) * 0.2;
  gradeScore += Math.min(learningProgress.quizScore, 100) * 0.2;
  gradeScore += Math.min(learningProgress.consistency, 100) * 0.15;
  gradeScore += Math.max(100 - riskProfile.riskScore, 0) * 0.15;
  
  let grade: string;
  if (gradeScore >= 90) {
    grade = 'A+ ممتاز';
  } else if (gradeScore >= 80) {
    grade = 'A جيد جداً';
  } else if (gradeScore >= 70) {
    grade = 'B+ جيد';
  } else if (gradeScore >= 60) {
    grade = 'B مقبول';
  } else {
    grade = 'C يحتاج تحسين';
    recommendations.push('💪 ركز على تحسين معدل النجاح والانضباط');
  }
  
  return {
    metrics,
    insights,
    recommendations,
    grade
  };
}

// Get weekly/monthly summary
export async function getActivitySummary(
  userId: string,
  period: 'week' | 'month'
): Promise<{
  tradesCount: number;
  profitLoss: number;
  studyTime: number;
  lessonsCompleted: number;
  activeDays: number;
}> {
  const daysBack = period === 'week' ? 7 : 30;
  const startDate = new Date();
  startDate.setDate(startDate.getDate() - daysBack);
  
  // Get trades
  const prefix = `trade:${userId}`;
  const trades = await kv.getByPrefix(prefix);
  const recentTrades = trades
    .map(t => JSON.parse(t))
    .filter(t => new Date(t.timestamp) > startDate);
  
  const profitLoss = recentTrades
    .filter(t => t.profit !== undefined)
    .reduce((sum, t) => sum + t.profit, 0);
  
  // Get learning activity
  const historyKey = `ai_history:${userId}`;
  const historyStr = await kv.get(historyKey);
  const history = historyStr ? JSON.parse(historyStr) : [];
  
  const recentActivity = history.filter((entry: any) => 
    new Date(entry.timestamp) > startDate
  );
  
  const activeDays = new Set(
    recentActivity.map((entry: any) => 
      new Date(entry.timestamp).toDateString()
    )
  ).size;
  
  return {
    tradesCount: recentTrades.length,
    profitLoss: parseFloat(profitLoss.toFixed(2)),
    studyTime: recentActivity.length * 5, // Rough estimate
    lessonsCompleted: recentActivity.filter((a: any) => 
      a.category !== 'general'
    ).length,
    activeDays
  };
}
