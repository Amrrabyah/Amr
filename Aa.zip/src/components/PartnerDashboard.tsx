import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Users, DollarSign, TrendingUp, Award, Copy, Check, Download, Calendar } from 'lucide-react';
import { API_URL } from '../utils/api.tsx';
import { publicAnonKey } from '../utils/supabase/info.tsx';

interface PartnerStats {
  totalReferrals: number;
  completedReferrals: number;
  pendingReferrals: number;
  totalRevenue: number;
  pendingCommission: number;
  conversionRate: number;
  averageCommission: number;
}

interface Partner {
  id: string;
  name: string;
  type: 'university' | 'bank' | 'corporate' | 'influencer';
  tier: 'bronze' | 'silver' | 'gold' | 'platinum';
  referralCode: string;
  revenueGenerated: number;
}

interface Referral {
  id: string;
  userId: string;
  status: 'pending' | 'completed' | 'rejected';
  commissionEarned: number;
  activityType?: string;
  createdAt: string;
}

const tierColors = {
  bronze: '#CD7F32',
  silver: '#C0C0C0',
  gold: '#FFD700',
  platinum: '#E5E4E2'
};

const tierBenefits = {
  bronze: { rate: '10%', features: ['لوحة تحكم أساسية', 'دعم عبر البريد'] },
  silver: { rate: '15%', features: ['لوحة تحكم متقدمة', 'دعم أولوية', 'تقارير شهرية'] },
  gold: { rate: '20%', features: ['لوحة تحكم كاملة', 'دعم فوري', 'تقارير لحظية', 'مدير حساب'] },
  platinum: { rate: '25%', features: ['جميع المميزات', 'API مخصص', 'استشارات مجانية', 'حملات مشتركة'] }
};

export function PartnerDashboard({ partnerId }: { partnerId: string }) {
  const [partner, setPartner] = useState<Partner | null>(null);
  const [stats, setStats] = useState<PartnerStats | null>(null);
  const [referrals, setReferrals] = useState<Referral[]>([]);
  const [loading, setLoading] = useState(true);
  const [copied, setCopied] = useState(false);
  const [selectedPeriod, setSelectedPeriod] = useState<'week' | 'month' | 'all'>('month');

  useEffect(() => {
    loadData();
  }, [partnerId]);

  const loadData = async () => {
    setLoading(true);
    try {
      // Load partner info
      const partnerRes = await fetch(`${API_URL}/partners/${partnerId}`, {
        headers: { 'Authorization': `Bearer ${publicAnonKey}` }
      });
      const partnerData = await partnerRes.json();
      setPartner(partnerData);

      // Load stats
      const statsRes = await fetch(`${API_URL}/partners/${partnerId}/stats`, {
        headers: { 'Authorization': `Bearer ${publicAnonKey}` }
      });
      const statsData = await statsRes.json();
      setStats(statsData);

      // Load referrals
      const referralsRes = await fetch(`${API_URL}/partners/${partnerId}/referrals`, {
        headers: { 'Authorization': `Bearer ${publicAnonKey}` }
      });
      const referralsData = await referralsRes.json();
      setReferrals(referralsData.referrals || []);
    } catch (error) {
      console.error('Error loading partner data:', error);
    } finally {
      setLoading(false);
    }
  };

  const copyReferralCode = () => {
    if (partner) {
      navigator.clipboard.writeText(partner.referralCode);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const downloadReport = async () => {
    // In a real app, generate PDF report
    alert('سيتم تحميل التقرير قريباً');
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <motion.div
          className="w-16 h-16 border-4 border-[#FFD700] border-t-transparent rounded-full"
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
        />
      </div>
    );
  }

  if (!partner || !stats) {
    return (
      <div className="text-center py-12">
        <p className="text-xl opacity-70">لم يتم العثور على بيانات الشريك</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <motion.div
        className="glass-gold rounded-3xl p-8"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-3xl font-bold text-[#FFD700] mb-2">{partner.name}</h1>
            <div className="flex items-center gap-4">
              <span className="glass rounded-full px-4 py-1 text-sm">
                {partner.type === 'university' && '🎓 جامعة'}
                {partner.type === 'bank' && '🏦 بنك'}
                {partner.type === 'corporate' && '🏢 شركة'}
                {partner.type === 'influencer' && '⭐ مؤثر'}
              </span>
              <span
                className="glass rounded-full px-4 py-1 text-sm font-bold"
                style={{ color: tierColors[partner.tier] }}
              >
                {partner.tier.toUpperCase()}
              </span>
            </div>
          </div>
          
          <motion.button
            className="glass rounded-2xl px-6 py-3 flex items-center gap-2"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={downloadReport}
          >
            <Download className="w-5 h-5" />
            <span>تحميل التقرير</span>
          </motion.button>
        </div>

        {/* Referral Code */}
        <div className="glass rounded-2xl p-6">
          <div className="text-sm opacity-70 mb-2">كود الإحالة الخاص بك</div>
          <div className="flex items-center gap-4">
            <div className="flex-1 bg-black/30 rounded-xl px-6 py-4 text-2xl font-mono text-[#FFD700]">
              {partner.referralCode}
            </div>
            <motion.button
              className="glass rounded-xl px-6 py-4"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={copyReferralCode}
            >
              {copied ? (
                <Check className="w-6 h-6 text-green-500" />
              ) : (
                <Copy className="w-6 h-6 text-[#FFD700]" />
              )}
            </motion.button>
          </div>
          <div className="mt-4 text-sm opacity-70">
            شارك هذا الكود مع عملائك للحصول على عمولة {tierBenefits[partner.tier].rate}
          </div>
        </div>
      </motion.div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {[
          {
            label: 'إجمالي الإيرادات',
            value: `${stats.totalRevenue.toFixed(2)} $`,
            icon: DollarSign,
            color: '#00FF00',
            change: '+12.5%'
          },
          {
            label: 'إجمالي الإحالات',
            value: stats.totalReferrals,
            icon: Users,
            color: '#00D4FF',
            change: `${stats.completedReferrals} مكتملة`
          },
          {
            label: 'معدل التحويل',
            value: `${stats.conversionRate}%`,
            icon: TrendingUp,
            color: '#FFD700',
            change: stats.conversionRate > 50 ? 'ممتاز' : 'جيد'
          },
          {
            label: 'متوسط العمولة',
            value: `${stats.averageCommission.toFixed(2)} $`,
            icon: Award,
            color: '#FF6B6B',
            change: 'لكل إحالة'
          }
        ].map((stat, index) => (
          <motion.div
            key={index}
            className="glass-gold rounded-2xl p-6 relative overflow-hidden"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            whileHover={{ y: -5 }}
          >
            <motion.div
              className="absolute inset-0 opacity-10"
              style={{ backgroundColor: stat.color }}
              animate={{
                scale: [1, 1.2, 1],
                opacity: [0.1, 0.2, 0.1]
              }}
              transition={{ duration: 2, repeat: Infinity }}
            />
            
            <div className="relative z-10">
              <div className="flex items-center justify-between mb-4">
                <stat.icon className="w-8 h-8" style={{ color: stat.color }} />
                <span className="text-xs opacity-70">{stat.change}</span>
              </div>
              <div className="text-3xl font-bold mb-1" style={{ color: stat.color }}>
                {stat.value}
              </div>
              <div className="text-sm opacity-70">{stat.label}</div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Tier Benefits */}
      <motion.div
        className="glass-gold rounded-3xl p-8"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
      >
        <h3 className="text-xl font-bold mb-6" style={{ color: tierColors[partner.tier] }}>
          🏆 مميزات مستوى {partner.tier.toUpperCase()}
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {tierBenefits[partner.tier].features.map((feature, i) => (
            <motion.div
              key={i}
              className="glass rounded-xl px-4 py-3 flex items-center gap-3"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.1 }}
            >
              <div className="w-2 h-2 rounded-full" style={{ backgroundColor: tierColors[partner.tier] }} />
              <span>{feature}</span>
            </motion.div>
          ))}
        </div>

        {partner.tier !== 'platinum' && (
          <motion.div
            className="mt-6 glass rounded-2xl p-4 text-center"
            whileHover={{ scale: 1.02 }}
          >
            <p className="text-sm opacity-70 mb-2">
              ارفع مستواك للحصول على عمولات أعلى ومميزات أكثر!
            </p>
            <button className="text-[#FFD700] font-bold">
              اعرف المزيد عن الترقية →
            </button>
          </motion.div>
        )}
      </motion.div>

      {/* Referrals Table */}
      <motion.div
        className="glass-gold rounded-3xl p-8"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-xl font-bold text-[#FFD700]">الإحالات الأخيرة</h3>
          
          <div className="flex gap-2">
            {(['week', 'month', 'all'] as const).map((period) => (
              <motion.button
                key={period}
                className={`glass rounded-xl px-4 py-2 text-sm ${
                  selectedPeriod === period ? 'bg-[#FFD700]/20' : ''
                }`}
                onClick={() => setSelectedPeriod(period)}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                {period === 'week' && 'أسبوع'}
                {period === 'month' && 'شهر'}
                {period === 'all' && 'الكل'}
              </motion.button>
            ))}
          </div>
        </div>

        {referrals.length === 0 ? (
          <div className="text-center py-12">
            <Users className="w-16 h-16 mx-auto mb-4 opacity-30" />
            <p className="opacity-70">لا توجد إحالات بعد</p>
            <p className="text-sm opacity-50 mt-2">شارك كود الإحالة الخاص بك للبدء</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-white/10">
                  <th className="text-right py-3 px-4 text-sm opacity-70">المستخدم</th>
                  <th className="text-right py-3 px-4 text-sm opacity-70">النشاط</th>
                  <th className="text-right py-3 px-4 text-sm opacity-70">التاريخ</th>
                  <th className="text-right py-3 px-4 text-sm opacity-70">الحالة</th>
                  <th className="text-right py-3 px-4 text-sm opacity-70">العمولة</th>
                </tr>
              </thead>
              <tbody>
                {referrals.slice(0, 10).map((referral, index) => (
                  <motion.tr
                    key={referral.id}
                    className="border-b border-white/5 hover:bg-white/5"
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.05 }}
                  >
                    <td className="py-3 px-4">{referral.userId.substring(0, 16)}...</td>
                    <td className="py-3 px-4 text-sm opacity-70">
                      {referral.activityType || 'تسجيل'}
                    </td>
                    <td className="py-3 px-4 text-sm opacity-70">
                      {new Date(referral.createdAt).toLocaleDateString('ar-SA')}
                    </td>
                    <td className="py-3 px-4">
                      <span
                        className={`glass rounded-full px-3 py-1 text-xs ${
                          referral.status === 'completed'
                            ? 'text-green-500'
                            : referral.status === 'pending'
                            ? 'text-yellow-500'
                            : 'text-red-500'
                        }`}
                      >
                        {referral.status === 'completed' && '✓ مكتمل'}
                        {referral.status === 'pending' && '⏳ قيد الانتظار'}
                        {referral.status === 'rejected' && '✗ مرفوض'}
                      </span>
                    </td>
                    <td className="py-3 px-4 font-bold text-[#00FF00]">
                      ${referral.commissionEarned.toFixed(2)}
                    </td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </motion.div>

      {/* Marketing Tools */}
      <motion.div
        className="glass-gold rounded-3xl p-8"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
      >
        <h3 className="text-xl font-bold text-[#FFD700] mb-6">🎯 أدوات التسويق</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <motion.div
            className="glass rounded-2xl p-6 text-center"
            whileHover={{ y: -5 }}
          >
            <div className="text-4xl mb-3">📱</div>
            <h4 className="font-bold mb-2">بانرات للسوشيال ميديا</h4>
            <p className="text-sm opacity-70 mb-4">صور جاهزة للنشر</p>
            <button className="glass rounded-xl px-4 py-2 w-full">تحميل</button>
          </motion.div>

          <motion.div
            className="glass rounded-2xl p-6 text-center"
            whileHover={{ y: -5 }}
          >
            <div className="text-4xl mb-3">📧</div>
            <h4 className="font-bold mb-2">قوالب البريد الإلكتروني</h4>
            <p className="text-sm opacity-70 mb-4">رسائل جاهزة للإرسال</p>
            <button className="glass rounded-xl px-4 py-2 w-full">تحميل</button>
          </motion.div>

          <motion.div
            className="glass rounded-2xl p-6 text-center"
            whileHover={{ y: -5 }}
          >
            <div className="text-4xl mb-3">🎬</div>
            <h4 className="font-bold mb-2">فيديوهات ترويجية</h4>
            <p className="text-sm opacity-70 mb-4">محتوى فيديو احترافي</p>
            <button className="glass rounded-xl px-4 py-2 w-full">تحميل</button>
          </motion.div>
        </div>
      </motion.div>
    </div>
  );
}