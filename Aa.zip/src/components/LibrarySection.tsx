import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { BookOpen, PlayCircle, FileText, Video, TrendingUp, Filter, Search, Star } from 'lucide-react';

interface Content {
  id: number;
  title: string;
  description: string;
  type: 'video' | 'article' | 'course';
  level: 'beginner' | 'intermediate' | 'advanced';
  duration: string;
  progress: number;
  rating: number;
  featured: boolean;
}

const contents: Content[] = [
  {
    id: 1,
    title: 'أساسيات التحليل الفني',
    description: 'تعلم قراءة الرسوم البيانية وفهم الأنماط السعرية',
    type: 'course',
    level: 'beginner',
    duration: '4 ساعات',
    progress: 75,
    rating: 4.8,
    featured: true,
  },
  {
    id: 2,
    title: 'استراتيجيات التداول المتقدمة',
    description: 'تقنيات احترافية لتحقيق أرباح مستدامة',
    type: 'video',
    level: 'advanced',
    duration: '2 ساعة',
    progress: 30,
    rating: 4.9,
    featured: true,
  },
  {
    id: 3,
    title: 'إدارة المخاطر في الأسواق المالية',
    description: 'حماية رأس المال وتقليل الخسائر',
    type: 'article',
    level: 'intermediate',
    duration: '30 دقيقة',
    progress: 100,
    rating: 4.7,
    featured: false,
  },
  {
    id: 4,
    title: 'علم نفس المتداول الناجح',
    description: 'السيطرة على العواطف واتخاذ قرارات عقلانية',
    type: 'course',
    level: 'intermediate',
    duration: '3 ساعات',
    progress: 0,
    rating: 4.6,
    featured: false,
  },
  {
    id: 5,
    title: 'التحليل الأساسي للشركات',
    description: 'تقييم القيمة الحقيقية للأسهم',
    type: 'video',
    level: 'advanced',
    duration: '1.5 ساعة',
    progress: 50,
    rating: 4.8,
    featured: true,
  },
  {
    id: 6,
    title: 'مؤشرات التداول الفنية',
    description: 'استخدام المؤشرات لتحديد نقاط الدخول والخروج',
    type: 'article',
    level: 'beginner',
    duration: '45 دقيقة',
    progress: 0,
    rating: 4.5,
    featured: false,
  },
];

const typeIcons = {
  video: Video,
  article: FileText,
  course: BookOpen,
};

const levelColors = {
  beginner: '#00D4FF',
  intermediate: '#FFD700',
  advanced: '#FF6B6B',
};

export function LibrarySection() {
  const [filter, setFilter] = useState<'all' | 'video' | 'article' | 'course'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredContents = contents.filter((content) => {
    const matchesFilter = filter === 'all' || content.type === filter;
    const matchesSearch = content.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         content.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  const featuredContents = contents.filter((c) => c.featured);

  return (
    <div className="space-y-8">
      {/* Search and Filter Bar */}
      <motion.div
        className="glass-gold rounded-2xl p-6"
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
      >
        <div className="flex flex-col md:flex-row gap-4">
          {/* Search */}
          <div className="flex-1 relative">
            <Search className="absolute right-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-[#FFD700]" />
            <input
              type="text"
              placeholder="ابحث عن المحتوى..."
              className="w-full glass rounded-xl py-3 pr-12 pl-4 bg-black/30 border-none outline-none focus:ring-2 focus:ring-[#FFD700] transition-all"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>

          {/* Filters */}
          <div className="flex gap-2">
            {[
              { label: 'الكل', value: 'all', icon: Filter },
              { label: 'فيديو', value: 'video', icon: Video },
              { label: 'مقال', value: 'article', icon: FileText },
              { label: 'دورة', value: 'course', icon: BookOpen },
            ].map((item) => {
              const Icon = item.icon;
              return (
                <motion.button
                  key={item.value}
                  className={`glass rounded-xl px-4 py-3 flex items-center gap-2 transition-all ${
                    filter === item.value ? 'bg-[#FFD700]/20 ring-2 ring-[#FFD700]' : ''
                  }`}
                  onClick={() => setFilter(item.value as any)}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Icon className="w-4 h-4" />
                  <span className="text-sm">{item.label}</span>
                </motion.button>
              );
            })}
          </div>
        </div>

        {/* Live count */}
        <motion.div
          className="mt-4 text-sm opacity-70"
          key={filteredContents.length}
          initial={{ scale: 1.2 }}
          animate={{ scale: 1 }}
        >
          عرض {filteredContents.length} من {contents.length} محتوى
        </motion.div>
      </motion.div>

      {/* Featured Carousel */}
      {filter === 'all' && !searchQuery && (
        <div>
          <h3 className="text-[#FFD700] mb-6 flex items-center gap-3">
            <Star className="w-8 h-8" />
            المحتوى المميز
          </h3>
          <div className="relative">
            <motion.div
              className="flex gap-6 overflow-x-auto pb-4 snap-x snap-mandatory scrollbar-hide"
              style={{ scrollbarWidth: 'none' }}
            >
              {featuredContents.map((content, index) => (
                <motion.div
                  key={content.id}
                  className="min-w-[400px] snap-center"
                  initial={{ opacity: 0, x: 50 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  style={{ perspective: 1000 }}
                >
                  <motion.div
                    className="glass-gold rounded-2xl p-6 relative overflow-hidden h-full"
                    whileHover={{
                      rotateY: 5,
                      rotateX: -5,
                      scale: 1.02,
                    }}
                    style={{ transformStyle: 'preserve-3d' }}
                  >
                    {/* Seal/Stamp */}
                    <motion.div
                      className="absolute top-4 left-4 w-16 h-16 rounded-full bg-[#FFD700] flex items-center justify-center text-2xl font-bold shadow-lg"
                      animate={{ rotate: [0, 5, -5, 0] }}
                      transition={{ duration: 2, repeat: Infinity }}
                    >
                      ⭐
                    </motion.div>

                    <div className="mt-12">
                      <div className="flex items-center gap-2 mb-3">
                        {(() => {
                          const Icon = typeIcons[content.type];
                          return <Icon className="w-5 h-5 text-[#FFD700]" />;
                        })()}
                        <span className="text-xs opacity-70">{content.duration}</span>
                      </div>

                      <h3 className="text-[#FFD700] mb-2 text-xl">{content.title}</h3>
                      <p className="text-sm opacity-80 mb-4">{content.description}</p>

                      {/* Rating */}
                      <div className="flex items-center gap-2 mb-4">
                        <div className="flex gap-1">
                          {Array.from({ length: 5 }).map((_, i) => (
                            <Star
                              key={i}
                              className={`w-4 h-4 ${
                                i < Math.floor(content.rating)
                                  ? 'text-[#FFD700] fill-[#FFD700]'
                                  : 'text-gray-600'
                              }`}
                            />
                          ))}
                        </div>
                        <span className="text-sm">{content.rating}</span>
                      </div>

                      {/* Progress */}
                      {content.progress > 0 && (
                        <div className="mb-4">
                          <div className="flex justify-between text-xs mb-1">
                            <span>التقدم</span>
                            <span className="text-[#FFD700]">{content.progress}%</span>
                          </div>
                          <div className="relative h-2 bg-black/50 rounded-full overflow-hidden">
                            <motion.div
                              className="absolute inset-y-0 right-0 rounded-full bg-gradient-to-l from-[#FFD700] to-[#D4AF37]"
                              initial={{ width: 0 }}
                              animate={{ width: `${content.progress}%` }}
                              transition={{ duration: 1, delay: index * 0.2 }}
                            />
                          </div>
                        </div>
                      )}

                      <motion.button
                        className="w-full glass rounded-xl py-3 flex items-center justify-center gap-2 group"
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                      >
                        <PlayCircle className="w-5 h-5 text-[#FFD700] group-hover:scale-110 transition-transform" />
                        <span className="text-[#FFD700]">
                          {content.progress > 0 ? 'متابعة' : 'ابدأ الآن'}
                        </span>
                      </motion.button>
                    </div>
                  </motion.div>
                </motion.div>
              ))}
            </motion.div>
          </div>
        </div>
      )}

      {/* Content Grid */}
      <div>
        <h3 className="text-[#FFD700] mb-6 flex items-center gap-3">
          <BookOpen className="w-8 h-8" />
          المكتبة الكاملة
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <AnimatePresence mode="popLayout">
            {filteredContents.map((content, index) => {
              const Icon = typeIcons[content.type];
              return (
                <motion.div
                  key={content.id}
                  layout
                  initial={{ scale: 0, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  exit={{ scale: 0, opacity: 0 }}
                  transition={{ delay: index * 0.05 }}
                >
                  <motion.div
                    className="glass rounded-2xl p-6 h-full relative overflow-hidden group cursor-pointer"
                    whileHover={{ y: -5, boxShadow: '0 20px 40px rgba(255,215,0,0.3)' }}
                  >
                    {/* Loading wave effect */}
                    <motion.div
                      className="absolute inset-0 bg-gradient-to-t from-[#FFD700]/20 to-transparent"
                      initial={{ y: '100%' }}
                      whileHover={{ y: 0 }}
                      transition={{ duration: 0.5 }}
                    />

                    {/* Content */}
                    <div className="relative z-10">
                      <div className="flex items-start justify-between mb-4">
                        <div
                          className="p-3 rounded-xl glass-gold"
                          style={{
                            backgroundColor: `${levelColors[content.level]}22`,
                          }}
                        >
                          <Icon className="w-6 h-6" style={{ color: levelColors[content.level] }} />
                        </div>

                        <div
                          className="text-xs px-3 py-1 rounded-full glass"
                          style={{
                            borderColor: levelColors[content.level],
                            color: levelColors[content.level],
                          }}
                        >
                          {content.level === 'beginner' && 'مبتدئ'}
                          {content.level === 'intermediate' && 'متوسط'}
                          {content.level === 'advanced' && 'متقدم'}
                        </div>
                      </div>

                      <h4 className="mb-2">{content.title}</h4>
                      <p className="text-sm opacity-70 mb-4">{content.description}</p>

                      <div className="flex items-center justify-between text-xs opacity-70 mb-4">
                        <span>⏱️ {content.duration}</span>
                        <span>⭐ {content.rating}</span>
                      </div>

                      {/* Progress indicator - battery style */}
                      <div className="flex items-center gap-2 mb-4">
                        <div className="flex-1 relative h-6 border-2 border-[#FFD700] rounded-lg overflow-hidden">
                          <motion.div
                            className="absolute inset-y-0 right-0 bg-gradient-to-l from-[#FFD700] to-[#D4AF37]"
                            initial={{ width: 0 }}
                            animate={{ width: `${content.progress}%` }}
                            transition={{ duration: 1 }}
                          />
                          <div className="absolute inset-0 flex items-center justify-center text-xs font-bold">
                            {content.progress}%
                          </div>
                        </div>
                        <div className="w-2 h-4 bg-[#FFD700] rounded-sm" />
                      </div>

                      {/* Magnetic button */}
                      <motion.button
                        className="w-full glass-gold rounded-xl py-2 text-sm relative overflow-hidden group"
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                      >
                        <motion.div
                          className="absolute inset-0 bg-[#FFD700]"
                          initial={{ scale: 0, opacity: 0 }}
                          whileHover={{ scale: 1, opacity: 0.2 }}
                          transition={{ duration: 0.3 }}
                        />
                        <span className="relative z-10">إظهار المزيد</span>
                      </motion.button>
                    </div>
                  </motion.div>
                </motion.div>
              );
            })}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
