import { projectId, publicAnonKey } from './supabase/info.tsx';

// API Base URL
export const API_URL = `https://${projectId}.supabase.co/functions/v1/make-server-1e8d5017`;

// Helper function for API calls with error handling
export async function apiCall<T>(
  endpoint: string,
  options: RequestInit = {}
): Promise<T> {
  const url = `${API_URL}${endpoint}`;
  
  const defaultHeaders = {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${publicAnonKey}`
  };

  try {
    const response = await fetch(url, {
      ...options,
      headers: {
        ...defaultHeaders,
        ...options.headers
      }
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new Error(errorData.error || `HTTP ${response.status}: ${response.statusText}`);
    }

    return await response.json();
  } catch (error) {
    console.error(`API Error [${endpoint}]:`, error);
    
    // Return mock data for development if API is not available
    if (error instanceof TypeError && error.message.includes('fetch')) {
      console.warn('⚠️ API not available, using mock data');
      return getMockData(endpoint) as T;
    }
    
    throw error;
  }
}

// Mock data for development when API is not available
function getMockData(endpoint: string): any {
  // Market prices
  if (endpoint.startsWith('/market/')) {
    const symbol = endpoint.split('/').pop();
    return {
      symbol,
      price: Math.random() * 100 + 50
    };
  }

  // Trading balance
  if (endpoint.includes('/trading/balance/')) {
    return { balance: 10000 };
  }

  // Trading stats
  if (endpoint.includes('/trading/stats/')) {
    return {
      totalTrades: 0,
      winningTrades: 0,
      losingTrades: 0,
      winRate: 0,
      totalProfit: 0,
      totalLoss: 0,
      netProfit: 0,
      averageProfit: 0,
      averageLoss: 0,
      profitFactor: 0,
      largestWin: 0,
      largestLoss: 0
    };
  }

  // Trading history
  if (endpoint.includes('/trading/history/')) {
    return { trades: [] };
  }

  // Real estate properties
  if (endpoint.includes('/realestate/properties/')) {
    return { properties: [] };
  }

  // Real estate portfolio
  if (endpoint.includes('/realestate/portfolio/')) {
    return {
      properties: [],
      totalInvested: 0,
      currentValue: 0,
      totalROI: 0,
      monthlyIncome: 0,
      occupancyRate: 0
    };
  }

  // Decision scenarios
  if (endpoint.includes('/decisions/scenario')) {
    return {
      id: 'mock_scenario_1',
      title: 'قرار استثماري',
      description: 'يرجى الانتظار، النظام قيد التحميل...',
      difficulty: 'beginner',
      category: 'investment',
      context: {
        timeLimit: 300,
        budget: 10000,
        marketCondition: 'stable'
      },
      options: [
        {
          id: 'opt1',
          text: 'انتظر تحميل النظام',
          correctness: 0.5,
          outcome: {
            financialImpact: 0,
            timeImpact: 0,
            riskLevel: 'low'
          }
        }
      ]
    };
  }

  // Decision stats
  if (endpoint.includes('/decisions/stats/')) {
    return {
      totalScenarios: 0,
      completedScenarios: 0,
      averageScore: 0,
      averageTime: 0,
      categoryStats: {},
      difficultyStats: {},
      recentScenarios: []
    };
  }

  // AI recommendations
  if (endpoint.includes('/ai/recommendations/')) {
    return {
      recommendations: [],
      reasoning: 'النظام قيد التحميل...'
    };
  }

  // AI tutor
  if (endpoint.includes('/ai/tutor/ask')) {
    return {
      response: 'النظام قيد التحميل، يرجى المحاولة مرة أخرى...',
      sources: [],
      relatedTopics: []
    };
  }

  // AI tutor history
  if (endpoint.includes('/ai/tutor/history/')) {
    return { history: [] };
  }

  // AI tutor progress
  if (endpoint.includes('/ai/tutor/progress/')) {
    return {
      knowledgeLevel: 5,
      totalQuestions: 15,
      correctAnswers: 12,
      topicsExplored: ['التداول', 'الاستثمار', 'إدارة المخاطر'],
      learningStreak: 3,
      strongAreas: ['التحليل الأساسي', 'إدارة المخاطر'],
      weakAreas: ['التحليل الفني'],
      areasForImprovement: ['التحليل الفني']
    };
  }

  // AI tutor tip
  if (endpoint.includes('/ai/tutor/tip')) {
    const tips = [
      '💡 لا تستثمر مالاً تحتاجه في المدى القريب',
      '📊 التنويع هو مفتاح إدارة المخاطر الفعالة',
      '🎯 حدد أهدافك المالية قبل البدء في أي استثمار',
      '📈 تعلم قراءة الرسوم البيانية لفهم اتجاهات السوق',
      '⚠️ استخدم وقف الخسارة دائماً لحماية رأس المال'
    ];
    return { tip: tips[Math.floor(Math.random() * tips.length)] };
  }

  // Analytics report
  if (endpoint.includes('/ai/analytics/report/')) {
    return {
      overallScore: 0,
      metrics: {},
      recommendations: [],
      trends: {}
    };
  }

  // Risk analysis
  if (endpoint.includes('/ai/analytics/risk/')) {
    return {
      riskLevel: 'medium',
      riskScore: 50,
      patterns: [],
      recommendations: []
    };
  }

  // Activity summary
  if (endpoint.includes('/ai/analytics/summary/')) {
    return {
      totalActivities: 0,
      timeSpent: 0,
      categoriesEngaged: [],
      achievements: []
    };
  }

  // Partners
  if (endpoint.includes('/partners')) {
    if (endpoint.includes('/stats')) {
      return {
        totalReferrals: 0,
        completedReferrals: 0,
        pendingReferrals: 0,
        totalRevenue: 0,
        pendingCommission: 0,
        conversionRate: 0,
        averageCommission: 0
      };
    }
    if (endpoint.includes('/referrals')) {
      return { referrals: [] };
    }
    return { partners: [] };
  }

  // Default empty response
  return {};
}

// Specific API functions
export const api = {
  // Trading
  async getMarketPrice(symbol: string) {
    return apiCall(`/market/${symbol}`);
  },

  async openTrade(userId: string, simulationId: string, symbol: string, amount: number, direction: 'buy' | 'sell') {
    return apiCall('/trading/open', {
      method: 'POST',
      body: JSON.stringify({ userId, simulationId, symbol, amount, direction })
    });
  },

  async closeTrade(userId: string, tradeId: string) {
    return apiCall('/trading/close', {
      method: 'POST',
      body: JSON.stringify({ userId, tradeId })
    });
  },

  async getTradingStats(userId: string, simulationId: string) {
    return apiCall(`/trading/stats/${userId}/${simulationId}`);
  },

  async getTradingHistory(userId: string, simulationId: string) {
    return apiCall(`/trading/history/${userId}/${simulationId}`);
  },

  async getBalance(userId: string, simulationId: string) {
    return apiCall(`/trading/balance/${userId}/${simulationId}`);
  },

  // Real Estate
  async initPropertyMarket(simulationId: string) {
    return apiCall(`/realestate/init/${simulationId}`, { method: 'POST' });
  },

  async getProperties(simulationId: string) {
    return apiCall(`/realestate/properties/${simulationId}`);
  },

  async purchaseProperty(userId: string, simulationId: string, propertyId: string, financingType: string, downPayment?: number) {
    return apiCall('/realestate/purchase', {
      method: 'POST',
      body: JSON.stringify({ userId, simulationId, propertyId, financingType, downPayment })
    });
  },

  async sellProperty(userId: string, simulationId: string, propertyId: string) {
    return apiCall('/realestate/sell', {
      method: 'POST',
      body: JSON.stringify({ userId, simulationId, propertyId })
    });
  },

  async getPortfolio(userId: string, simulationId: string) {
    return apiCall(`/realestate/portfolio/${userId}/${simulationId}`);
  },

  // Decisions
  async initScenarios() {
    return apiCall('/decisions/init', { method: 'POST' });
  },

  async getScenario(difficulty?: string) {
    const query = difficulty ? `?difficulty=${difficulty}` : '';
    return apiCall(`/decisions/scenario${query}`);
  },

  async submitDecision(userId: string, scenarioId: string, selectedOptionId: string, timeTaken: number) {
    return apiCall('/decisions/submit', {
      method: 'POST',
      body: JSON.stringify({ userId, scenarioId, selectedOptionId, timeTaken })
    });
  },

  async getDecisionStats(userId: string) {
    return apiCall(`/decisions/stats/${userId}`);
  },

  // AI Tutor
  async getLearningProgress(userId: string) {
    return apiCall(`/ai/tutor/progress/${userId}`);
  },

  async getQuickTip(category?: string) {
    const params = category ? `?category=${category}` : '';
    return apiCall(`/ai/tutor/tip${params}`);
  },

  async askAITutor(userId: string, question: string) {
    return apiCall('/ai/tutor/ask', {
      method: 'POST',
      body: JSON.stringify({ userId, question })
    });
  },

  async getTutorHistory(userId: string, limit: number = 10) {
    return apiCall(`/ai/tutor/history/${userId}?limit=${limit}`);
  },

  // Recommendations
  async getRecommendations(userId: string, limit: number = 5) {
    return apiCall(`/ai/recommendations/${userId}?limit=${limit}`);
  },

  async trackActivity(userId: string, activityType: string, contentId: string, category: string, timeSpent: number) {
    return apiCall('/ai/track', {
      method: 'POST',
      body: JSON.stringify({ userId, activityType, contentId, category, timeSpent })
    });
  },

  async getLearningPath(userId: string, goal: string) {
    return apiCall(`/ai/learning-path/${userId}/${goal}`);
  },

  async getTrending(limit: number = 5) {
    return apiCall(`/ai/trending?limit=${limit}`);
  },

  async searchContent(query: string, filters: any = {}) {
    const params = new URLSearchParams({ q: query, ...filters });
    return apiCall(`/ai/search?${params}`);
  },

  // Analytics
  async getPerformanceReport(userId: string, simulationId: string) {
    return apiCall(`/ai/analytics/report/${userId}/${simulationId}`);
  },

  async getRiskAnalysis(userId: string, simulationId: string) {
    return apiCall(`/ai/analytics/risk/${userId}/${simulationId}`);
  },

  async getActivitySummary(userId: string, period: 'week' | 'month' = 'week') {
    return apiCall(`/ai/analytics/summary/${userId}?period=${period}`);
  },

  // Partnerships
  async createPartner(data: any) {
    return apiCall('/partners/create', {
      method: 'POST',
      body: JSON.stringify(data)
    });
  },

  async getPartner(partnerId: string) {
    return apiCall(`/partners/${partnerId}`);
  },

  async getPartnerByCode(referralCode: string) {
    return apiCall(`/partners/code/${referralCode}`);
  },

  async listPartners(filters?: any) {
    const params = new URLSearchParams(filters);
    return apiCall(`/partners?${params}`);
  },

  async updatePartner(partnerId: string, updates: any) {
    return apiCall(`/partners/${partnerId}`, {
      method: 'PUT',
      body: JSON.stringify(updates)
    });
  },

  async upgradePartner(partnerId: string, newTier: string) {
    return apiCall(`/partners/${partnerId}/upgrade`, {
      method: 'POST',
      body: JSON.stringify({ newTier })
    });
  },

  async trackReferral(referralCode: string, userId: string, activityType?: string, transactionAmount?: number) {
    return apiCall('/partners/referrals/track', {
      method: 'POST',
      body: JSON.stringify({ referralCode, userId, activityType, transactionAmount })
    });
  },

  async getPartnerReferrals(partnerId: string) {
    return apiCall(`/partners/${partnerId}/referrals`);
  },

  async getPartnerStats(partnerId: string) {
    return apiCall(`/partners/${partnerId}/stats`);
  },

  async getPartnerReport(partnerId: string, startDate?: string, endDate?: string) {
    const params = new URLSearchParams();
    if (startDate) params.append('startDate', startDate);
    if (endDate) params.append('endDate', endDate);
    return apiCall(`/partners/${partnerId}/report?${params}`);
  }
};