import { motion } from 'motion/react';
import { useState } from 'react';
import { TrendingUp, BookOpen, Award, Target } from 'lucide-react';

interface CardData {
  id: number;
  title: string;
  description: string;
  progress: number;
  icon: 'trending' | 'book' | 'award' | 'target';
  color: string;
}

const iconMap = {
  trending: TrendingUp,
  book: BookOpen,
  award: Award,
  target: Target,
};

export function ThreeDCard({ card }: { card: CardData }) {
  const [isHovered, setIsHovered] = useState(false);
  const Icon = iconMap[card.icon];

  return (
    <motion.div
      className="relative"
      style={{ perspective: 1000 }}
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
      whileHover={{ scale: 1.02 }}
    >
      <motion.div
        className="glass-gold rounded-2xl p-8 relative overflow-hidden"
        style={{
          transformStyle: 'preserve-3d',
        }}
        animate={{
          rotateX: isHovered ? 5 : 0,
          rotateY: isHovered ? -5 : 0,
          y: isHovered ? -15 : 0,
        }}
        transition={{ type: "spring", stiffness: 300, damping: 20 }}
      >
        {/* Glow effect */}
        <motion.div
          className="absolute inset-0 rounded-2xl opacity-0"
          style={{
            background: 'radial-gradient(circle at center, rgba(255,215,0,0.4), transparent)',
            filter: 'blur(20px)',
          }}
          animate={{ opacity: isHovered ? 1 : 0 }}
          transition={{ duration: 0.3 }}
        />

        {/* Inner glow */}
        <motion.div
          className="absolute inset-0 rounded-2xl"
          style={{
            boxShadow: 'inset 0 0 30px rgba(255,215,0,0)',
          }}
          animate={{
            boxShadow: isHovered
              ? 'inset 0 0 30px rgba(255,215,0,0.3)'
              : 'inset 0 0 30px rgba(255,215,0,0)',
          }}
        />

        {/* Content */}
        <div className="relative z-10">
          {/* Animated icon */}
          <motion.div
            className="mb-4"
            animate={{
              rotate: isHovered ? [0, -10, 10, -10, 0] : 0,
              scale: isHovered ? 1.1 : 1,
            }}
            transition={{ duration: 0.5 }}
          >
            <div
              className="inline-flex p-4 rounded-xl"
              style={{
                background: `${card.color}22`,
                boxShadow: `0 0 20px ${card.color}44`,
              }}
            >
              <Icon className="w-8 h-8" style={{ color: card.color }} />
            </div>
          </motion.div>

          {/* Title */}
          <h3 className="mb-2 text-[#FFD700]">{card.title}</h3>
          <p className="text-sm opacity-80 mb-6">{card.description}</p>

          {/* Circular mini progress */}
          <div className="flex items-center justify-between mb-4">
            <span className="text-xs opacity-70">التقدم</span>
            <div className="relative w-12 h-12">
              <svg className="transform -rotate-90 w-12 h-12">
                <circle
                  cx="24"
                  cy="24"
                  r="20"
                  stroke="rgba(255,215,0,0.2)"
                  strokeWidth="4"
                  fill="none"
                />
                <circle
                  cx="24"
                  cy="24"
                  r="20"
                  stroke={card.color}
                  strokeWidth="4"
                  fill="none"
                  strokeLinecap="round"
                  strokeDasharray={125.6}
                  strokeDashoffset={125.6 * (1 - card.progress / 100)}
                />
              </svg>
              <div className="absolute inset-0 flex items-center justify-center text-xs font-bold">
                {card.progress}%
              </div>
            </div>
          </div>

          {/* Glass CTA button */}
          <motion.button
            className="w-full glass rounded-xl py-3 relative overflow-hidden group"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            <motion.div
              className="absolute inset-0"
              style={{
                background: 'linear-gradient(90deg, transparent, rgba(255,215,0,0.3), transparent)',
              }}
              initial={{ x: '-100%' }}
              whileHover={{ x: '100%' }}
              transition={{ duration: 0.6 }}
            />
            <span className="relative z-10 text-[#FFD700]">استكشف الآن</span>
          </motion.button>
        </div>

        {/* Decorative corner */}
        <motion.div
          className="absolute top-0 left-0 w-20 h-20 opacity-20"
          style={{
            background: 'radial-gradient(circle at top left, #FFD700, transparent)',
          }}
          animate={{
            scale: isHovered ? 1.5 : 1,
            opacity: isHovered ? 0.3 : 0.2,
          }}
        />
      </motion.div>
    </motion.div>
  );
}
