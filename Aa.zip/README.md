
  # تطبيق تفاعلي متكامل

  This is a code bundle for تطبيق تفاعلي متكامل. The original project is available at https://www.figma.com/design/8H2icyQY2HjtbxO2UonJHm/%D8%AA%D8%B7%D8%A8%D9%8A%D9%82-%D8%AA%D9%81%D8%A7%D8%B9%D9%84%D9%8A-%D9%85%D8%AA%D9%83%D8%A7%D9%85%D9%84.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  