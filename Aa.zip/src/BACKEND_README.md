# 📚 دليل Backend - أكاديمية الذهب المالية

## 🏗️ البنية التحتية

تم بناء النظام باستخدام **Supabase Edge Functions** بدلاً من Node.js/Express التقليدي، مما يوفر:

- ✅ **Serverless Architecture** - لا حاجة لإدارة خوادم
- ✅ **Auto-scaling** - تكبير تلقائي حسب الحمل
- ✅ **Key-Value Store** - قاعدة بيانات مرنة
- ✅ **Real-time Updates** - تحديثات فورية
- ✅ **Built-in Security** - حماية مدمجة

---

## 🗄️ قاعدة البيانات

### نظام Key-Value Store
يستخدم النظام جدول `kv_store_1e8d5017` المدمج في Supabase:

```typescript
// مفاتيح البيانات
balance:${userId}:${simulationId}          // رصيد المستخدم
trade:${tradeId}                           // بيانات الصفقة
stats:${userId}:${simulationId}            // إحصائيات التداول
market:${symbol}                           // أسعار السوق
property:${propertyId}                     // بيانات العقارات
re_portfolio:${userId}:${simulationId}     // محفظة العقارات
scenario:${scenarioId}                     // سيناريوهات القرارات
attempt:${attemptId}                       // محاولات المستخدم
decision_stats:${userId}                   // إحصائيات القرارات
```

---

## 🔌 API Endpoints

### Base URL
```
https://${projectId}.supabase.co/functions/v1/make-server-1e8d5017
```

### 📈 محاكاة التداول

#### 1. الحصول على سعر السوق
```http
GET /market/:symbol
```

**مثال:**
```javascript
const response = await fetch(`${API_URL}/market/AAPL`, {
  headers: {
    'Authorization': `Bearer ${publicAnonKey}`
  }
});
// Response: { symbol: "AAPL", price: 150.25 }
```

#### 2. فتح صفقة
```http
POST /trading/open
```

**Body:**
```json
{
  "userId": "user_demo_123",
  "simulationId": "sim_stock_001",
  "symbol": "AAPL",
  "amount": 10,
  "direction": "buy"
}
```

**Response:**
```json
{
  "success": true,
  "tradeId": "trade_user_demo_123_1699999999",
  "newBalance": 8500.50,
  "message": "تم تنفيذ الصفقة بنجاح"
}
```

#### 3. إغلاق صفقة
```http
POST /trading/close
```

**Body:**
```json
{
  "userId": "user_demo_123",
  "tradeId": "trade_user_demo_123_1699999999"
}
```

**Response:**
```json
{
  "success": true,
  "profit": 125.50,
  "newBalance": 10125.50,
  "message": "تم إغلاق الصفقة بنجاح"
}
```

#### 4. الحصول على الإحصائيات
```http
GET /trading/stats/:userId/:simulationId
```

**Response:**
```json
{
  "totalTrades": 25,
  "winningTrades": 18,
  "totalProfit": 1250.75,
  "maxDrawdown": 150.00,
  "winRate": 72
}
```

#### 5. سجل الصفقات
```http
GET /trading/history/:userId/:simulationId
```

**Response:**
```json
{
  "trades": [
    {
      "id": "trade_xxx",
      "symbol": "AAPL",
      "amount": 10,
      "direction": "buy",
      "entryPrice": 150.00,
      "status": "open",
      "timestamp": "2024-11-16T10:00:00Z"
    }
  ]
}
```

#### 6. الرصيد الحالي
```http
GET /trading/balance/:userId/:simulationId
```

**Response:**
```json
{
  "balance": 10000.00
}
```

---

### 🏠 محاكاة العقارات

#### 1. تهيئة سوق العقارات
```http
POST /realestate/init/:simulationId
```

**Response:**
```json
{
  "message": "تم تهيئة سوق العقارات بنجاح"
}
```

#### 2. الحصول على العقارات المتاحة
```http
GET /realestate/properties/:simulationId
```

**Response:**
```json
{
  "properties": [
    {
      "id": "prop_sim_1",
      "location": "الرياض - حي الملقا",
      "type": "apartment",
      "currentPrice": 500000,
      "rentalYield": 0.06,
      "growthRate": 0.08,
      "sizeSqm": 150,
      "available": true
    }
  ]
}
```

#### 3. شراء عقار
```http
POST /realestate/purchase
```

**Body:**
```json
{
  "userId": "user_demo_123",
  "simulationId": "sim_re_001",
  "propertyId": "prop_sim_1",
  "financingType": "mortgage",
  "downPayment": 100000
}
```

**Response:**
```json
{
  "success": true,
  "transactionId": "re_trans_xxx",
  "newBalance": 9900000,
  "message": "تم شراء العقار بنجاح"
}
```

#### 4. بيع عقار
```http
POST /realestate/sell
```

**Body:**
```json
{
  "userId": "user_demo_123",
  "simulationId": "sim_re_001",
  "propertyId": "prop_sim_1"
}
```

**Response:**
```json
{
  "success": true,
  "profit": 50000,
  "newBalance": 10550000,
  "message": "تم بيع العقار بنجاح"
}
```

#### 5. المحفظة العقارية
```http
GET /realestate/portfolio/:userId/:simulationId
```

**Response:**
```json
{
  "properties": [
    {
      "propertyId": "prop_sim_1",
      "purchaseDate": "2024-11-01T00:00:00Z",
      "purchasePrice": 500000,
      "currentValue": 550000,
      "totalReturn": 80000,
      "rentalIncome": 30000,
      "appreciation": 50000
    }
  ],
  "totalValue": 550000,
  "totalReturn": 80000
}
```

#### 6. تحليل الأداء
```http
GET /realestate/analyze/:userId/:simulationId
```

**Response:**
```json
{
  "totalInvested": 500000,
  "currentValue": 550000,
  "totalReturn": 80000,
  "roi": "16.00",
  "propertyCount": 1,
  "locationDistribution": {
    "الرياض": 1
  },
  "typeDistribution": {
    "apartment": 1
  },
  "suggestions": [
    "🎯 أداء ممتاز! حافظ على استراتيجيتك الحالية",
    "📊 قم بتنويع المحفظة بإضافة عقارات في مواقع مختلفة"
  ]
}
```

---

### 🧠 تمارين القرارات

#### 1. تهيئة السيناريوهات
```http
POST /decisions/init
```

**Response:**
```json
{
  "message": "تم تهيئة السيناريوهات بنجاح"
}
```

#### 2. الحصول على سيناريو عشوائي
```http
GET /decisions/scenario?difficulty=intermediate
```

**Response:**
```json
{
  "id": "scenario_1",
  "title": "قرار استثماري عاجل",
  "description": "شركة تقنية تعلن عن ابتكار جديد",
  "difficulty": "beginner",
  "context": "شركة Apple أعلنت عن منتج ثوري...",
  "question": "ما هو أفضل قرار استثماري؟",
  "options": [
    {
      "id": "opt_1_a",
      "text": "الشراء الفوري للاستفادة من الزخم"
    },
    {
      "id": "opt_1_b",
      "text": "الانتظار لمدة أسبوع..."
    }
  ],
  "points": 100,
  "category": "stock_market"
}
```

#### 3. تقديم الحل
```http
POST /decisions/submit
```

**Body:**
```json
{
  "userId": "user_demo_123",
  "scenarioId": "scenario_1",
  "selectedOptionId": "opt_1_b",
  "timeTaken": 25.5
}
```

**Response:**
```json
{
  "success": true,
  "isCorrect": true,
  "score": 120,
  "explanation": "قرار ممتاز! التحليل الهادئ يؤدي لقرارات أفضل",
  "message": "🎉 إجابة صحيحة!"
}
```

#### 4. إحصائيات القرارات
```http
GET /decisions/stats/:userId
```

**Response:**
```json
{
  "totalAttempts": 25,
  "correctAttempts": 20,
  "totalScore": 2500,
  "accuracy": "80.00",
  "averageTime": 35.2,
  "byCategory": {
    "stock_market": {
      "attempts": 10,
      "correct": 8,
      "score": 1000
    }
  }
}
```

#### 5. التوصيات المخصصة
```http
GET /decisions/recommendations/:userId
```

**Response:**
```json
{
  "recommendations": [
    "🌟 أداء ممتاز! حاول السيناريوهات الأكثر تقدماً",
    "⏱️ حاول تحسين سرعة اتخاذ القرار مع الحفاظ على الدقة"
  ]
}
```

#### 6. تحليل الأنماط (مكافحة الغش)
```http
GET /decisions/analyze/:userId
```

**Response:**
```json
{
  "suspicious": false,
  "reasons": []
}
```

---

## 🔒 نظام الحماية

### 1. مكافحة التلاعب في التداول

```typescript
// تحقق من تكرار الصفقات
trade_count:${userId}:${minute} // max 10 في الدقيقة

// تحقق من الأحجام غير الطبيعية
avg_trade:${userId} // مقارنة مع المتوسط
```

### 2. مكافحة الغش في القرارات

```typescript
// دقة مشبوهة
if (accuracy > 95% && totalAttempts > 10) -> suspicious

// سرعة غير طبيعية
if (averageTime < 5 seconds) -> suspicious

// سلسلة نجاح طويلة
if (last 10 attempts all correct) -> suspicious
```

### 3. التخزين المؤقت للأسعار

```typescript
// حماية ضد استنزاف API
market:${symbol} // expires in 5 seconds
```

---

## 📊 تحليل الأداء

### مؤشرات التداول

```typescript
// معدل النجاح
winRate = (winningTrades / totalTrades) * 100

// أقصى خسارة
maxDrawdown = Math.max(...losses)

// نسبة المخاطرة/العائد
riskRewardRatio = avgWin / avgLoss
```

### تقييم القرارات

```typescript
// النقاط الأساسية
baseScore = scenario.points

// مكافأة الوقت
timeBonus = (30 - timeTaken) / 30 * baseScore * 0.2

// النقاط النهائية
finalScore = baseScore + timeBonus
```

---

## 🚀 الاستخدام في Frontend

### مثال كامل - فتح صفقة

```typescript
import { projectId, publicAnonKey } from './utils/supabase/info.tsx';

const API_URL = `https://${projectId}.supabase.co/functions/v1/make-server-1e8d5017`;

async function openTrade(userId, symbol, amount, direction) {
  try {
    const response = await fetch(`${API_URL}/trading/open`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${publicAnonKey}`
      },
      body: JSON.stringify({
        userId,
        simulationId: 'sim_stock_001',
        symbol,
        amount,
        direction
      })
    });

    const data = await response.json();
    
    if (data.error) {
      console.error('Error:', data.error);
      return;
    }

    console.log('Trade opened:', data.tradeId);
    console.log('New balance:', data.newBalance);
    
  } catch (error) {
    console.error('Network error:', error);
  }
}

// استخدام
openTrade('user_demo_123', 'AAPL', 10, 'buy');
```

---

## ⚠️ ملاحظات مهمة

### 1. بيئة التطوير
- ❌ **لا تستخدم في الإنتاج** - هذا نظام تعليمي فقط
- ❌ **لا تجمع بيانات حساسة** - PII أو معلومات مالية حقيقية
- ✅ **للمحاكاة والتعليم فقط**

### 2. الأمان
```typescript
// كل المستخدمين يستخدمون نفس الـ userId في Demo
const userId = 'user_demo_123';

// في الإنتاج، يجب استخدام Supabase Auth
const { data: { user } } = await supabase.auth.getUser();
```

### 3. التخزين
```typescript
// البيانات مؤقتة وقد تُحذف
// استخدم Supabase للتخزين الدائم
```

---

## 🎯 الميزات المتقدمة

### 1. محرك الأسعار الديناميكي
```typescript
// توليد تحركات سعرية واقعية
const volatility = 0.02;
const randomChange = (Math.random() - 0.5) * 2 * volatility;
const price = basePrice * (1 + randomChange);
```

### 2. محاكاة نمو العقارات
```typescript
// حساب الارتفاع السعري
const appreciation = price * (growthRate / 12) * monthsHeld;
const rentalIncome = price * rentalYield * (monthsHeld / 12);
```

### 3. نظام التوصيات الذكية
```typescript
// توصيات مخصصة حسب الأداء
if (roi < 5) suggestions.push('💡 معدل العائد منخفض...');
if (accuracy > 80) suggestions.push('🌟 أداء ممتاز...');
```

---

## 📞 الدعم والمساعدة

للمزيد من المعلومات:
- 📚 [Supabase Docs](https://supabase.com/docs)
- 🔧 [Edge Functions Guide](https://supabase.com/docs/guides/functions)
- 💬 [Community Support](https://supabase.com/docs/guides/getting-started)

---

**تم البناء بفخر باستخدام Supabase Edge Functions** ⚡
