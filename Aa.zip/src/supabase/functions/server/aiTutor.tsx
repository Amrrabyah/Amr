import * as kv from './kv_store.tsx';

interface UserProfile {
  userId: string;
  learningStyle: 'visual' | 'auditory' | 'kinesthetic';
  knowledgeLevel: number;
  weakAreas: string[];
  strongAreas: string[];
  complexity: 'beginner' | 'intermediate' | 'advanced';
}

interface ConversationEntry {
  timestamp: string;
  question: string;
  response: string;
  category: string;
}

// Financial knowledge base (rule-based AI)
const knowledgeBase = {
  // أساسيات التداول
  'ما هو التداول': {
    beginner: 'التداول هو عملية شراء وبيع الأسهم أو الأصول المالية بهدف تحقيق الربح. يشبه شراء منتج بسعر منخفض وبيعه بسعر أعلى، لكن في الأسواق المالية.',
    intermediate: 'التداول يشمل استراتيجيات متعددة: Day Trading (التداول اليومي)، Swing Trading (التداول المتأرجح)، و Position Trading (التداول طويل الأجل). كل منها يتطلب تحليل فني ومالي مختلف.',
    advanced: 'التداول الاحترافي يعتمد على تحليل السوق متعدد الطبقات: Technical Analysis (المؤشرات والرسوم البيانية)، Fundamental Analysis (البيانات المالية للشركات)، و Sentiment Analysis (تحليل المشاعر في السوق). يتطلب فهم عميق للرافعة المالية والمشتقات المالية.'
  },
  
  'ما هو الاستثمار': {
    beginner: 'الاستثمار هو وضع أموالك في أصول تنمو قيمتها مع الوقت، مثل الأسهم أو العقارات، لبناء ثروة على المدى الطويل.',
    intermediate: 'الاستثمار الناجح يعتمد على التنويع وتوزيع المحفظة بين أصول مختلفة (أسهم، سندات، عقارات، سلع). القاعدة الذهبية: لا تضع كل بيضك في سلة واحدة.',
    advanced: 'استراتيجيات الاستثمار المتقدمة تشمل: Value Investing (استثمار القيمة)، Growth Investing (استثمار النمو)، و Index Fund Investing (صناديق المؤشرات). يجب فهم مفاهيم مثل Beta، Alpha، Sharpe Ratio، و Modern Portfolio Theory.'
  },

  'كيف أبدأ': {
    beginner: 'ابدأ بتحديد أهدافك المالية، ثم تعلم الأساسيات من خلال دوراتنا التعليمية. ابدأ بمحاكي التداول لتجربة السوق بدون مخاطر، ثم انتقل تدريجياً للتداول الحقيقي برأس مال صغير.',
    intermediate: 'قم ببناء خطة استثمارية واضحة تحدد: نسبة المخاطرة، أنواع الأصول، استراتيجية الدخول والخروج. استخدم أدوات التحليل الفني والأساسي. ابدأ بحساب تجريبي لمدة 3 أشهر قبل التداول الحقيقي.',
    advanced: 'طور نظام تداول خاص بك يشمل: معايير دخول محددة، إدارة مخاطر صارمة (2% max per trade)، وسجل تداول مفصل. استخدم backtesting لاختبار استراتيجياتك، وطور edge خاص بك في السوق.'
  },

  'ما هي المخاطر': {
    beginner: 'المخاطر الأساسية: فقدان رأس المال، تقلبات السوق، والقرارات العاطفية. لذلك لا تستثمر مالاً تحتاجه في المدى القريب، ولا تستثمر أكثر مما تستطيع خسارته.',
    intermediate: 'أنواع المخاطر: Market Risk (مخاطر السوق)، Liquidity Risk (مخاطر السيولة)، Credit Risk (مخاطر الائتمان)، و Operational Risk. استخدم Stop-Loss orders وتنويع المحفظة للحد من المخاطر.',
    advanced: 'إدارة المخاطر المتقدمة تشمل: Position sizing بناءً على Kelly Criterion، Hedging strategies باستخدام Options، و Portfolio stress testing. فهم Black Swan events وكيفية الحماية منها باستخدام Tail Risk hedging.'
  },

  'التحليل الفني': {
    beginner: 'التحليل الفني هو دراسة حركة الأسعار والرسوم البيانية للتنبؤ بالاتجاهات المستقبلية. يعتمد على فكرة أن التاريخ يعيد نفسه وأن الأسعار تتحرك في أنماط.',
    intermediate: 'أدوات التحليل الفني الأساسية: Moving Averages (المتوسطات المتحركة)، RSI (مؤشر القوة النسبية)، MACD، و Fibonacci retracements. تعلم قراءة Candlestick patterns و Support/Resistance levels.',
    advanced: 'التحليل الفني المتقدم يشمل: Elliott Wave Theory، Ichimoku Cloud، Volume Profile، و Order Flow analysis. فهم Market Structure و Smart Money Concepts لتحديد مناطق السيولة المؤسسية.'
  },

  'إدارة المخاطر': {
    beginner: 'إدارة المخاطر تعني عدم المخاطرة بأكثر من 1-2% من رأس مالك في صفقة واحدة. استخدم أوامر Stop-Loss لحماية نفسك من الخسائر الكبيرة.',
    intermediate: 'قاعدة 1-2% Rule: إذا كان رأس مالك 10,000 ريال، لا تخاطر بأكثر من 100-200 ريال في صفقة واحدة. احسب Position Size بناءً على مسافة Stop-Loss. استخدم Risk-Reward Ratio لا يقل عن 1:2.',
    advanced: 'إدارة المخاطر المتقدمة: Portfolio heat (مجموع المخاطر في جميع الصفقات المفتوحة لا يتجاوز 6%)، Correlation analysis لتجنب التركيز، و Drawdown management. طور recovery plan لحالات الخسارة المتتالية.'
  },

  'علم النفس التجاري': {
    beginner: 'أكبر عدو للمتداول هو عواطفه: الخوف يمنعك من دخول الصفقات الجيدة، والطمع يجعلك تخاطر أكثر من اللازم. اتبع خطتك ولا تتداول بدافع الانتقام.',
    intermediate: 'المشاكل النفسية الشائعة: FOMO (الخوف من تفويت الفرصة)، Revenge Trading (التداول الانتقامي)، و Overconfidence. احتفظ بسجل تداول لتحليل أخطائك العاطفية. خذ استراحات منتظمة.',
    advanced: 'تطوير Trading Psychology قوي: التأمل اليومي، Journaling مفصل، و Performance review أسبوعي. فهم Cognitive Biases مثل Confirmation Bias و Anchoring. طور Emotional detachment من نتائج الصفقات الفردية.'
  }
};

// Pattern matching for questions
function matchQuestion(question: string): string | null {
  const q = question.toLowerCase().trim();
  
  // Remove question marks and common words
  const cleaned = q.replace(/[؟?]/g, '').trim();
  
  // Check for exact matches
  for (const key of Object.keys(knowledgeBase)) {
    if (cleaned.includes(key.toLowerCase())) {
      return key;
    }
  }
  
  // Check for keywords
  if (cleaned.includes('تداول') || cleaned.includes('trading')) return 'ما هو التداول';
  if (cleaned.includes('استثمار') || cleaned.includes('invest')) return 'ما هو الاستثمار';
  if (cleaned.includes('أبدأ') || cleaned.includes('بداية') || cleaned.includes('start')) return 'كيف أبدأ';
  if (cleaned.includes('مخاطر') || cleaned.includes('risk') || cleaned.includes('خطر')) return 'ما هي المخاطر';
  if (cleaned.includes('تحليل فني') || cleaned.includes('technical')) return 'التحليل الفني';
  if (cleaned.includes('إدارة') && cleaned.includes('مخاطر')) return 'إدارة المخاطر';
  if (cleaned.includes('نفس') || cleaned.includes('عاطف') || cleaned.includes('psychology')) return 'علم النفس التجاري';
  
  return null;
}

// Get user profile
async function getUserProfile(userId: string): Promise<UserProfile> {
  const profileKey = `ai_profile:${userId}`;
  const profileStr = await kv.get(profileKey);
  
  if (profileStr) {
    return JSON.parse(profileStr);
  }
  
  // Default profile
  return {
    userId,
    learningStyle: 'visual',
    knowledgeLevel: 1,
    weakAreas: [],
    strongAreas: [],
    complexity: 'beginner'
  };
}

// Update user profile
async function updateUserProfile(profile: UserProfile): Promise<void> {
  const profileKey = `ai_profile:${profile.userId}`;
  await kv.set(profileKey, JSON.stringify(profile));
}

// Generate AI response
export async function generateAIResponse(
  userId: string,
  question: string
): Promise<{
  response: string;
  category: string;
  suggestions: string[];
}> {
  try {
    // Get user profile
    const profile = await getUserProfile(userId);
    
    // Match question to knowledge base
    const matchedTopic = matchQuestion(question);
    
    let response: string;
    let category: string;
    
    if (matchedTopic && knowledgeBase[matchedTopic]) {
      // Get appropriate complexity level
      response = knowledgeBase[matchedTopic][profile.complexity];
      category = matchedTopic;
      
      // Update user profile based on question
      if (!profile.strongAreas.includes(matchedTopic)) {
        profile.strongAreas.push(matchedTopic);
        
        // Level up if asking advanced questions
        if (profile.complexity === 'beginner' && profile.strongAreas.length > 3) {
          profile.complexity = 'intermediate';
        } else if (profile.complexity === 'intermediate' && profile.strongAreas.length > 6) {
          profile.complexity = 'advanced';
        }
        
        await updateUserProfile(profile);
      }
    } else {
      // Fallback response
      response = 'شكراً على سؤالك! للأسف، لم أتمكن من فهم سؤالك بدقة. يمكنك إعادة صياغته أو اختيار أحد المواضيع التالية:\n\n' +
        '• ما هو التداول؟\n' +
        '• ما هو الاستثمار؟\n' +
        '• كيف أبدأ؟\n' +
        '• ما هي المخاطر؟\n' +
        '• التحليل الفني\n' +
        '• إدارة المخاطر\n' +
        '• علم النفس التجاري';
      category = 'general';
    }
    
    // Save conversation history
    const historyKey = `ai_history:${userId}`;
    const historyStr = await kv.get(historyKey);
    const history: ConversationEntry[] = historyStr ? JSON.parse(historyStr) : [];
    
    history.push({
      timestamp: new Date().toISOString(),
      question,
      response,
      category
    });
    
    // Keep only last 50 conversations
    if (history.length > 50) {
      history.shift();
    }
    
    await kv.set(historyKey, JSON.stringify(history));
    
    // Generate suggestions
    const suggestions = generateSuggestions(category, profile);
    
    return {
      response,
      category,
      suggestions
    };
  } catch (error) {
    console.error('Error generating AI response:', error);
    return {
      response: 'عذراً، حدث خطأ في معالجة سؤالك. حاول مرة أخرى.',
      category: 'error',
      suggestions: []
    };
  }
}

// Generate personalized suggestions
function generateSuggestions(category: string, profile: UserProfile): string[] {
  const suggestions: string[] = [];
  
  if (category === 'ما هو التداول') {
    suggestions.push('💡 ابدأ بمحاكي التداول لتجربة السوق بدون مخاطر');
    suggestions.push('📚 شاهد دورة "أساسيات التداول" في المكتبة');
  } else if (category === 'إدارة المخاطر') {
    suggestions.push('🎯 مارس إدارة المخاطر في محاكي التداول');
    suggestions.push('📊 احسب Position Size المناسب لصفقاتك');
  } else if (category === 'علم النفس التجاري') {
    suggestions.push('🧠 حل تمارين القرارات التجارية لتحسين ضبط النفس');
    suggestions.push('📝 احتفظ بسجل تداول لتحليل قراراتك');
  }
  
  // Add level-up suggestion
  if (profile.complexity === 'beginner' && profile.strongAreas.length >= 3) {
    suggestions.push('🌟 أنت مستعد للانتقال للمستوى المتوسط!');
  }
  
  return suggestions;
}

// Get conversation history
export async function getConversationHistory(
  userId: string,
  limit: number = 10
): Promise<ConversationEntry[]> {
  const historyKey = `ai_history:${userId}`;
  const historyStr = await kv.get(historyKey);
  
  if (!historyStr) {
    return [];
  }
  
  const history: ConversationEntry[] = JSON.parse(historyStr);
  return history.slice(-limit);
}

// Analyze learning progress
export async function analyzeLearningProgress(userId: string): Promise<{
  knowledgeLevel: number;
  strongAreas: string[];
  weakAreas: string[];
  recommendations: string[];
}> {
  const profile = await getUserProfile(userId);
  const historyKey = `ai_history:${userId}`;
  const historyStr = await kv.get(historyKey);
  
  const history: ConversationEntry[] = historyStr ? JSON.parse(historyStr) : [];
  
  // Analyze question patterns
  const categoryCount: Record<string, number> = {};
  for (const entry of history) {
    categoryCount[entry.category] = (categoryCount[entry.category] || 0) + 1;
  }
  
  // Determine weak areas (asked many times but still beginner)
  const weakAreas: string[] = [];
  for (const [category, count] of Object.entries(categoryCount)) {
    if (count > 5 && profile.complexity === 'beginner') {
      weakAreas.push(category);
    }
  }
  
  // Generate recommendations
  const recommendations: string[] = [];
  
  if (profile.strongAreas.length === 0) {
    recommendations.push('🎓 ابدأ بتعلم أساسيات التداول والاستثمار');
  }
  
  if (weakAreas.length > 0) {
    recommendations.push(`📚 ركز على تقوية معرفتك في: ${weakAreas.join('، ')}`);
  }
  
  if (profile.complexity === 'beginner' && history.length > 20) {
    recommendations.push('🚀 حان وقت الانتقال للمستوى المتوسط!');
  }
  
  if (history.length > 10 && !categoryCount['التحليل الفني']) {
    recommendations.push('📊 تعلم التحليل الفني لتحسين قراراتك');
  }
  
  return {
    knowledgeLevel: profile.knowledgeLevel,
    strongAreas: profile.strongAreas,
    weakAreas,
    recommendations
  };
}

// Quick tips generator
export function getQuickTip(category?: string): string {
  const tips = {
    general: [
      '💡 لا تستثمر مالاً تحتاجه في المدى القريب',
      '📊 التنويع يقلل المخاطر - لا تضع كل بيضك في سلة واحدة',
      '🎯 حدد أهدافك المالية قبل البدء',
      '📚 التعليم المستمر هو مفتاح النجاح في الأسواق المالية'
    ],
    trading: [
      '⏰ لا تتداول بدافع الملل أو الانتقام',
      '📉 Stop-Loss هو صديقك - استخدمه دائماً',
      '💪 الانضباط أهم من الذكاء في التداول',
      '🔍 انتظر الإعداد المثالي - الصبر يؤتي ثماره'
    ],
    psychology: [
      '🧘 خذ استراحة بعد سلسلة خسائر',
      '😌 لا تدع العواطف تتحكم في قراراتك',
      '📝 احتفظ بسجل تداول لتحليل أخطائك',
      '🎓 تعلم من أخطائك ولا تكررها'
    ]
  };
  
  const selectedTips = category && tips[category] ? tips[category] : tips.general;
  return selectedTips[Math.floor(Math.random() * selectedTips.length)];
}
