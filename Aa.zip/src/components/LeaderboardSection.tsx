import { motion } from 'motion/react';
import { Trophy, Medal, Award, TrendingUp, Zap } from 'lucide-react';

interface Leader {
  id: number;
  name: string;
  score: number;
  avatar: string;
  trend: 'up' | 'down' | 'same';
  achievements: number;
}

const leaders: Leader[] = [
  {
    id: 1,
    name: 'أحمد المالي',
    score: 12500,
    avatar: '👨‍💼',
    trend: 'up',
    achievements: 45,
  },
  {
    id: 2,
    name: 'فاطمة الخبيرة',
    score: 11800,
    avatar: '👩‍💼',
    trend: 'up',
    achievements: 42,
  },
  {
    id: 3,
    name: 'محمد المحلل',
    score: 10900,
    avatar: '👨‍🎓',
    trend: 'down',
    achievements: 38,
  },
  {
    id: 4,
    name: 'سارة المستثمرة',
    score: 9500,
    avatar: '👩‍🔬',
    trend: 'up',
    achievements: 35,
  },
  {
    id: 5,
    name: 'علي المتداول',
    score: 8700,
    avatar: '👨‍💻',
    trend: 'same',
    achievements: 30,
  },
];

export function LeaderboardSection() {
  return (
    <div className="space-y-8">
      {/* Winner's Podium */}
      <div className="relative h-96">
        <div className="absolute inset-0 flex items-end justify-center gap-8">
          {/* Second Place */}
          <motion.div
            className="flex flex-col items-center"
            initial={{ y: 100, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.2 }}
          >
            <motion.div
              className="relative mb-4"
              animate={{ y: [0, -10, 0] }}
              transition={{ duration: 2, repeat: Infinity, delay: 0.2 }}
            >
              <div className="w-24 h-24 rounded-full bg-gradient-to-br from-gray-300 to-gray-500 flex items-center justify-center text-4xl border-4 border-gray-400 shadow-xl">
                {leaders[1].avatar}
              </div>
              <div className="absolute -bottom-2 -right-2 w-10 h-10 rounded-full bg-gradient-to-br from-gray-300 to-gray-500 flex items-center justify-center font-bold text-white shadow-lg">
                2
              </div>
            </motion.div>
            <div
              className="w-32 rounded-t-2xl glass-gold relative overflow-hidden"
              style={{ height: '160px' }}
            >
              <motion.div
                className="absolute inset-0 bg-gradient-to-t from-gray-400/30 to-transparent"
                animate={{ opacity: [0.3, 0.6, 0.3] }}
                transition={{ duration: 2, repeat: Infinity }}
              />
              <div className="relative z-10 p-4 text-center">
                <div className="font-bold mb-1">{leaders[1].name}</div>
                <div className="text-2xl text-[#FFD700] font-bold">
                  {leaders[1].score.toLocaleString('ar-SA')}
                </div>
                <div className="text-xs opacity-70 mt-1">
                  🏆 {leaders[1].achievements}
                </div>
              </div>
            </div>
          </motion.div>

          {/* First Place */}
          <motion.div
            className="flex flex-col items-center"
            initial={{ y: 100, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0 }}
          >
            <motion.div
              className="relative mb-4"
              animate={{ y: [0, -15, 0], rotate: [0, 5, -5, 0] }}
              transition={{ duration: 2, repeat: Infinity }}
            >
              <div className="w-32 h-32 rounded-full bg-gradient-to-br from-[#FFD700] to-[#D4AF37] flex items-center justify-center text-5xl border-4 border-[#FFD700] shadow-2xl animate-pulse-gold">
                {leaders[0].avatar}
              </div>
              <motion.div
                className="absolute -top-8 left-1/2 transform -translate-x-1/2"
                animate={{ rotate: [0, 15, -15, 0] }}
                transition={{ duration: 2, repeat: Infinity }}
              >
                <div className="text-6xl">👑</div>
              </motion.div>
              <div className="absolute -bottom-3 -right-3 w-12 h-12 rounded-full bg-gradient-to-br from-[#FFD700] to-[#D4AF37] flex items-center justify-center font-bold text-2xl text-black shadow-xl">
                1
              </div>
            </motion.div>
            <div
              className="w-40 rounded-t-2xl glass-gold relative overflow-hidden"
              style={{ height: '200px' }}
            >
              <motion.div
                className="absolute inset-0 bg-gradient-to-t from-[#FFD700]/30 to-transparent"
                animate={{ opacity: [0.3, 0.6, 0.3] }}
                transition={{ duration: 2, repeat: Infinity }}
              />
              {/* Spotlight beams */}
              {[0, 1, 2].map((i) => (
                <motion.div
                  key={i}
                  className="absolute top-0 left-1/2 w-1 h-full bg-gradient-to-b from-[#FFD700] to-transparent"
                  style={{ transformOrigin: 'top' }}
                  animate={{
                    rotate: [-30 + i * 30, -40 + i * 30, -20 + i * 30],
                    opacity: [0.3, 0.6, 0.3],
                  }}
                  transition={{ duration: 3, repeat: Infinity, delay: i * 0.3 }}
                />
              ))}
              <div className="relative z-10 p-4 text-center">
                <div className="font-bold mb-1 text-lg">{leaders[0].name}</div>
                <div className="text-3xl text-[#FFD700] font-bold">
                  {leaders[0].score.toLocaleString('ar-SA')}
                </div>
                <div className="text-sm opacity-70 mt-2">
                  🏆 {leaders[0].achievements}
                </div>
              </div>
            </div>
          </motion.div>

          {/* Third Place */}
          <motion.div
            className="flex flex-col items-center"
            initial={{ y: 100, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.4 }}
          >
            <motion.div
              className="relative mb-4"
              animate={{ y: [0, -8, 0] }}
              transition={{ duration: 2, repeat: Infinity, delay: 0.4 }}
            >
              <div className="w-20 h-20 rounded-full bg-gradient-to-br from-[#CD7F32] to-[#8B4513] flex items-center justify-center text-3xl border-4 border-[#CD7F32] shadow-lg">
                {leaders[2].avatar}
              </div>
              <div className="absolute -bottom-2 -right-2 w-10 h-10 rounded-full bg-gradient-to-br from-[#CD7F32] to-[#8B4513] flex items-center justify-center font-bold text-white shadow-lg">
                3
              </div>
            </motion.div>
            <div
              className="w-28 rounded-t-2xl glass-gold relative overflow-hidden"
              style={{ height: '120px' }}
            >
              <motion.div
                className="absolute inset-0 bg-gradient-to-t from-[#CD7F32]/30 to-transparent"
                animate={{ opacity: [0.3, 0.6, 0.3] }}
                transition={{ duration: 2, repeat: Infinity }}
              />
              <div className="relative z-10 p-4 text-center">
                <div className="font-bold mb-1 text-sm">{leaders[2].name}</div>
                <div className="text-xl text-[#FFD700] font-bold">
                  {leaders[2].score.toLocaleString('ar-SA')}
                </div>
                <div className="text-xs opacity-70 mt-1">
                  🏆 {leaders[2].achievements}
                </div>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Rain effect */}
        <div className="absolute inset-0 pointer-events-none overflow-hidden">
          {Array.from({ length: 20 }).map((_, i) => (
            <motion.div
              key={i}
              className="absolute text-2xl"
              style={{
                left: `${Math.random() * 100}%`,
                top: -50,
              }}
              animate={{
                y: [0, 500],
                rotate: [0, 360],
                opacity: [0, 1, 0],
              }}
              transition={{
                duration: 3,
                repeat: Infinity,
                delay: i * 0.2,
                ease: 'linear',
              }}
            >
              {['🏆', '⭐', '💰', '🎖️'][Math.floor(Math.random() * 4)]}
            </motion.div>
          ))}
        </div>
      </div>

      {/* Rest of the leaderboard */}
      <div>
        <h3 className="text-[#FFD700] mb-6 flex items-center gap-3">
          <Trophy className="w-8 h-8" />
          بقية المتصدرين
        </h3>
        <div className="space-y-3">
          {leaders.slice(3).map((leader, index) => (
            <motion.div
              key={leader.id}
              className="glass-gold rounded-2xl p-6 flex items-center justify-between group hover:bg-[#FFD700]/10 transition-colors"
              initial={{ x: -100, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ x: 10, scale: 1.02 }}
            >
              <div className="flex items-center gap-6">
                {/* Rank */}
                <motion.div
                  className="w-12 h-12 rounded-xl glass flex items-center justify-center font-bold text-xl text-[#FFD700]"
                  whileHover={{ rotate: [0, -10, 10, 0] }}
                >
                  {index + 4}
                </motion.div>

                {/* Avatar */}
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-[#FFD700]/30 to-[#D4AF37]/30 flex items-center justify-center text-3xl border-2 border-[#FFD700]/50">
                  {leader.avatar}
                </div>

                {/* Info */}
                <div>
                  <div className="font-bold mb-1">{leader.name}</div>
                  <div className="flex items-center gap-4 text-sm opacity-70">
                    <span>🏆 {leader.achievements} إنجاز</span>
                    <span className="flex items-center gap-1">
                      {leader.trend === 'up' && (
                        <TrendingUp className="w-4 h-4 text-green-500" />
                      )}
                      {leader.trend === 'down' && (
                        <TrendingUp className="w-4 h-4 text-red-500 transform rotate-180" />
                      )}
                      {leader.trend === 'same' && <span className="text-gray-500">—</span>}
                    </span>
                  </div>
                </div>
              </div>

              {/* Score */}
              <motion.div
                className="text-3xl font-bold text-[#FFD700]"
                whileHover={{ scale: 1.1 }}
              >
                {leader.score.toLocaleString('ar-SA')}
              </motion.div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Daily Challenges */}
      <div>
        <h3 className="text-[#FFD700] mb-6 flex items-center gap-3">
          <Zap className="w-8 h-8" />
          التحديات اليومية
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[
            {
              icon: '🎯',
              title: 'تحدي التداول السريع',
              reward: '+500 نقطة',
              progress: 3,
              total: 5,
            },
            {
              icon: '📚',
              title: 'أكمل 3 دروس',
              reward: '+300 نقطة',
              progress: 1,
              total: 3,
            },
            {
              icon: '🏆',
              title: 'حقق 80% دقة',
              reward: '+1000 نقطة',
              progress: 78,
              total: 80,
            },
          ].map((challenge, index) => (
            <motion.div
              key={index}
              className="glass-gold rounded-2xl p-6 relative overflow-hidden"
              initial={{ scale: 0, rotate: -180 }}
              animate={{ scale: 1, rotate: 0 }}
              transition={{ delay: index * 0.1, type: 'spring' }}
              whileHover={{ y: -5 }}
            >
              {/* Vintage typewriter effect */}
              <div className="absolute top-0 left-0 w-full h-1 bg-[#FFD700]" />
              <div className="absolute bottom-0 left-0 w-full h-1 bg-[#FFD700]" />

              <div className="text-5xl mb-4">{challenge.icon}</div>
              <h4 className="mb-2">{challenge.title}</h4>
              <div className="text-sm text-[#FFD700] mb-4">{challenge.reward}</div>

              {/* Progress */}
              <div className="relative h-3 bg-black/50 rounded-full overflow-hidden mb-2">
                <motion.div
                  className="absolute inset-y-0 right-0 rounded-full bg-gradient-to-l from-[#FFD700] to-[#D4AF37]"
                  initial={{ width: 0 }}
                  animate={{ width: `${(challenge.progress / challenge.total) * 100}%` }}
                  transition={{ duration: 1, delay: index * 0.2 }}
                />
              </div>
              <div className="text-xs text-center opacity-70">
                {challenge.progress} / {challenge.total}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
