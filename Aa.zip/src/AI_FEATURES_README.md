# 🤖 دليل ميزات الذكاء الاصطناعي - أكاديمية الذهب المالية

## 🌟 نظرة عامة

تم إضافة نظام AI متكامل يشمل:
- ✅ **المساعد التعليمي الذكي** (AI Tutor)
- ✅ **نظام التوصيات المخصصة** (Recommendation Engine)
- ✅ **تحليل الأداء الذكي** (Performance Analytics)
- ✅ **كشف المخاطر التلقائي** (Risk Detection)

---

## 🧠 1. المساعد التعليمي الذكي (AI Tutor)

### الميزات

#### قاعدة معرفية شاملة
- 7 مواضيع رئيسية في التداول والاستثمار
- إجابات تتكيف مع مستوى المستخدم (مبتدئ/متوسط/متقدم)
- تتبع التقدم التعليمي تلقائياً

#### المواضيع المغطاة:
1. **ما هو التداول** - أساسيات التداول والفرق بين الأنواع
2. **ما هو الاستثمار** - استراتيجيات الاستثمار طويل الأجل
3. **كيف أبدأ** - خطوات البداية ونصائح عملية
4. **ما هي المخاطر** - فهم وإدارة المخاطر المالية
5. **التحليل الفني** - قراءة الرسوم البيانية والمؤشرات
6. **إدارة المخاطر** - حماية رأس المال وحساب Position Size
7. **علم النفس التجاري** - التحكم في العواطف والانضباط

### كيفية الاستخدام

```typescript
// في Frontend
import { AITutorWidget } from './components/AITutorWidget';

// داخل المكون
<AITutorWidget />

// أو استخدام API مباشرة
const response = await fetch(`${API_URL}/ai/tutor/ask`, {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${publicAnonKey}`
  },
  body: JSON.stringify({
    userId: 'user_demo_123',
    question: 'ما هو التداول؟'
  })
});

const data = await response.json();
console.log(data.response); // الإجابة
console.log(data.suggestions); // اقتراحات إضافية
```

### نظام التقدم التلقائي

```javascript
// يرفع المستوى تلقائياً
beginner -> intermediate (بعد 3 مواضيع)
intermediate -> advanced (بعد 6 مواضيع)

// تتبع نقاط القوة والضعف
strongAreas: ['ما هو التداول', 'كيف أبدأ']
weakAreas: ['التحليل الفني'] // مواضيع تحتاج مراجعة
```

### API Endpoints

```http
# اسأل المساعد
POST /ai/tutor/ask
Body: { userId, question }
Response: { response, category, suggestions }

# سجل المحادثات
GET /ai/tutor/history/:userId?limit=10
Response: { history: [...] }

# تحليل التقدم
GET /ai/tutor/progress/:userId
Response: { knowledgeLevel, strongAreas, weakAreas, recommendations }

# نصيحة سريعة
GET /ai/tutor/tip?category=trading
Response: { tip: "..." }
```

---

## 📚 2. نظام التوصيات المخصصة

### خوارزمية التوصيات

يستخدم نظام تسجيل نقاط متقدم:

```typescript
similarityScore = 
  (difficulty_match × 0.30) +      // مطابقة المستوى
  (category_interest × 0.40) +     // الاهتمام بالفئة
  (tag_matching × 0.20) +          // مطابقة الكلمات المفتاحية
  (content_rating × 0.10)          // تقييم المحتوى
```

### مكتبة المحتوى

10+ محتويات تعليمية:
- 📖 دورات تدريبية (Courses)
- 🎥 فيديوهات تعليمية (Videos)
- 📝 مقالات (Articles)
- 📊 اختبارات (Quizzes)

### مسارات التعلم المقترحة

```typescript
// الحصول على مسار تعليمي مخصص
GET /ai/learning-path/:userId/:goal

// الأهداف المتاحة:
- trading           // التداول
- investing         // الاستثمار
- risk_management   // إدارة المخاطر
- technical_analysis // التحليل الفني

// Response:
{
  path: [...ContentItem],
  estimatedDuration: 360, // بالدقائق
  description: "مسار تعليمي شامل..."
}
```

### تتبع النشاط

```typescript
// تسجيل نشاط المستخدم
POST /ai/track
Body: {
  userId,
  activityType: 'complete_course', // أو watch_video, read_article
  contentId: 'course_1',
  category: 'trading',
  timeSpent: 120 // بالدقائق
}

// يقوم النظام تلقائياً بـ:
// 1. تحديث الاهتمامات
// 2. حساب الوقت المستغرق في كل فئة
// 3. تحسين التوصيات المستقبلية
```

### API Endpoints

```http
# توصيات مخصصة
GET /ai/recommendations/:userId?limit=5
Response: { recommendations: [...], reasons: [...] }

# المحتوى الرائج
GET /ai/trending?limit=5
Response: { trending: [...] }

# البحث في المحتوى
GET /ai/search?q=تداول&type=course&difficulty=beginner
Response: { results: [...] }
```

---

## 📊 3. تحليل الأداء الذكي

### مؤشرات التداول

```typescript
interface TradingMetrics {
  winRate: number;           // معدل النجاح (%)
  totalTrades: number;       // إجمالي الصفقات
  profitFactor: number;      // نسبة الربح/الخسارة
  maxDrawdown: number;       // أقصى خسارة
  sharpeRatio: number;       // العائد المعدل بالمخاطرة
  averageWin: number;        // متوسط الربح
  averageLoss: number;       // متوسط الخسارة
}

// مثال: Profit Factor = 2.5
// معناه: كل 1$ خسارة يقابله 2.50$ ربح
```

### مؤشرات التعلم

```typescript
interface LearningMetrics {
  coursesCompleted: number;  // الدورات المكتملة
  quizScore: number;         // دقة الإجابات (%)
  studyTime: number;         // وقت الدراسة (دقائق)
  consistency: number;       // الانتظام (أيام نشطة/30 يوم)
}
```

### نظام التقييم الشامل

```typescript
// حساب التقييم النهائي (A+ إلى C)
gradeScore = 
  (winRate × 0.30) +          // أداء التداول
  (profitFactor × 0.20) +     // ربحية الاستراتيجية
  (quizScore × 0.20) +        // استيعاب المفاهيم
  (consistency × 0.15) +      // الانتظام
  ((100 - riskScore) × 0.15)  // إدارة المخاطر

// التقييمات:
A+ (90-100): ممتاز
A  (80-89):  جيد جداً
B+ (70-79):  جيد
B  (60-69):  مقبول
C  (<60):    يحتاج تحسين
```

### API Endpoints

```http
# تقرير الأداء الشامل
GET /ai/analytics/report/:userId/:simulationId
Response: {
  metrics: { tradingPerformance, learningProgress, riskProfile },
  insights: [...],     // رؤى تلقائية
  recommendations: [...], // توصيات للتحسين
  grade: "A+ ممتاز"
}

# ملخص النشاط
GET /ai/analytics/summary/:userId?period=week
Response: {
  tradesCount: 25,
  profitLoss: 1250.50,
  studyTime: 180,
  lessonsCompleted: 8,
  activeDays: 5
}
```

---

## 🛡️ 4. كشف المخاطر التلقائي

### أنماط المخاطر المكتشفة

#### 1. Overtrading (التداول المفرط)
```typescript
if (tradesLast24h > 20) {
  riskScore += 25;
  warning: "⚠️ Overtrading: أكثر من 20 صفقة في 24 ساعة"
}
```

#### 2. Revenge Trading (التداول الانتقامي)
```typescript
// صفقات سريعة بعد الخسارة (< 5 دقائق)
if (quickTradesAfterLoss >= 3) {
  riskScore += 30;
  warning: "🔴 Revenge Trading: تداول انتقامي محتمل - خذ استراحة!"
}
```

#### 3. سلسلة خسائر طويلة
```typescript
if (consecutiveLosses >= 5) {
  riskScore += 20;
  warning: "📉 سلسلة خسائر طويلة: راجع استراتيجيتك"
}
```

#### 4. خسارة كبيرة في صفقة واحدة
```typescript
if (maxDrawdown > 2000) {
  riskScore += 25;
  warning: "💸 خسارة كبيرة: راجع إدارة المخاطر"
}
```

#### 5. تذبذب عالي في النتائج
```typescript
if (standardDeviation > avgProfit × 3) {
  riskScore += 15;
  warning: "📊 تذبذب عالي: ركز على الاتساق"
}
```

### مستويات الخطر

```typescript
riskLevel = {
  0-29:   'low'       // ✅ أداء جيد
  30-49:  'medium'    // ⚡ راقب قراراتك
  50-69:  'high'      // ⚠️ كن حذراً
  70+:    'very_high' // 🚨 توقف وراجع استراتيجيتك
}
```

### API Endpoint

```http
GET /ai/analytics/risk/:userId/:simulationId
Response: {
  riskScore: 45,
  riskLevel: "medium",
  indicators: [
    "⚡ تداول نشط جداً: راقب قراراتك",
    "📊 تذبذب عالي في النتائج: ركز على الاتساق"
  ]
}
```

---

## 💡 أمثلة الاستخدام الكامل

### 1. دمج المساعد الذكي

```tsx
import { useState } from 'react';
import { AITutorWidget } from './components/AITutorWidget';

function App() {
  const [isAIOpen, setIsAIOpen] = useState(false);

  return (
    <>
      {/* زر فتح المساعد */}
      <button onClick={() => setIsAIOpen(true)}>
        💬 اسأل المساعد
      </button>

      {/* نافذة المساعد */}
      {isAIOpen && (
        <div className="ai-panel">
          <AITutorWidget />
        </div>
      )}
    </>
  );
}
```

### 2. عرض التوصيات

```tsx
import { useEffect, useState } from 'react';

function RecommendationsPanel({ userId }) {
  const [recommendations, setRecommendations] = useState([]);

  useEffect(() => {
    fetch(`${API_URL}/ai/recommendations/${userId}`)
      .then(res => res.json())
      .then(data => setRecommendations(data.recommendations));
  }, [userId]);

  return (
    <div>
      <h3>محتوى مقترح لك</h3>
      {recommendations.map(rec => (
        <div key={rec.id}>
          <h4>{rec.title}</h4>
          <p>{rec.description}</p>
          <span>{rec.duration} دقيقة</span>
        </div>
      ))}
    </div>
  );
}
```

### 3. لوحة تحليل الأداء

```tsx
import { useEffect, useState } from 'react';

function PerformanceDashboard({ userId, simulationId }) {
  const [report, setReport] = useState(null);

  useEffect(() => {
    fetch(`${API_URL}/ai/analytics/report/${userId}/${simulationId}`)
      .then(res => res.json())
      .then(data => setReport(data));
  }, [userId, simulationId]);

  if (!report) return <div>جاري التحميل...</div>;

  return (
    <div>
      {/* التقييم */}
      <div className="grade">
        <h2>{report.grade}</h2>
      </div>

      {/* المؤشرات */}
      <div className="metrics">
        <div>معدل النجاح: {report.metrics.tradingPerformance.winRate}%</div>
        <div>عامل الربح: {report.metrics.tradingPerformance.profitFactor}</div>
        <div>الدقة في الاختبارات: {report.metrics.learningProgress.quizScore}%</div>
      </div>

      {/* الرؤى */}
      <div className="insights">
        <h3>رؤى تلقائية</h3>
        {report.insights.map((insight, i) => (
          <div key={i}>{insight}</div>
        ))}
      </div>

      {/* التوصيات */}
      <div className="recommendations">
        <h3>توصيات للتحسين</h3>
        {report.recommendations.map((rec, i) => (
          <div key={i}>{rec}</div>
        ))}
      </div>

      {/* تحذيرات المخاطر */}
      {report.metrics.riskProfile.riskLevel === 'high' && (
        <div className="risk-alert">
          {report.metrics.riskProfile.indicators.map((indicator, i) => (
            <div key={i}>{indicator}</div>
          ))}
        </div>
      )}
    </div>
  );
}
```

---

## 🎯 خارطة طريق الميزات المستقبلية

### قريباً
- [ ] **تحليل النصوص بـ NLP** - فهم أعمق للأسئلة
- [ ] **توصيات صوتية** - ردود صوتية من المساعد
- [ ] **Chatbot متعدد اللغات** - دعم الإنجليزية والعربية

### المستقبل
- [ ] **تكامل GPT-4** - إجابات أكثر تطوراً
- [ ] **التعلم التعزيزي** - تحسين الاستراتيجيات تلقائياً
- [ ] **نماذج تنبؤية** - توقع أداء المستخدم
- [ ] **رؤية حاسوبية** - تحليل الرسوم البيانية

---

## 🔒 الأمان والخصوصية

### حماية البيانات
✅ لا يتم جمع معلومات شخصية حساسة (PII)  
✅ جميع البيانات للمحاكاة التعليمية فقط  
✅ لا يتم تخزين معلومات مالية حقيقية  
✅ النظام للتعليم والتدريب فقط  

### Anti-Cheat في القرارات
✅ كشف الدقة المشبوهة (> 95%)  
✅ كشف السرعة غير الطبيعية (< 5 ثوان)  
✅ كشف سلاسل النجاح الطويلة (10 متتالية)  

---

## 📞 الدعم الفني

للمشاكل أو الاستفسارات:
- 📧 راجع `/BACKEND_README.md` للتوثيق الكامل
- 🔧 تحقق من Console للأخطاء
- 💬 اختبر الـ API endpoints يدوياً

---

**تم البناء بحب باستخدام Supabase Edge Functions & Rule-Based AI** 🤖✨
