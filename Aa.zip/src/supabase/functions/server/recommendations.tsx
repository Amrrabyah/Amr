import * as kv from './kv_store.tsx';

interface UserActivity {
  userId: string;
  completedCourses: string[];
  watchedVideos: string[];
  practiceScores: Record<string, number>;
  timeSpent: Record<string, number>;
  interests: string[];
}

interface ContentItem {
  id: string;
  title: string;
  type: 'course' | 'video' | 'article' | 'quiz';
  category: string;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  tags: string[];
  rating: number;
  duration: number;
}

// Content library
const contentLibrary: ContentItem[] = [
  {
    id: 'course_1',
    title: 'أساسيات التداول للمبتدئين',
    type: 'course',
    category: 'trading',
    difficulty: 'beginner',
    tags: ['تداول', 'أساسيات', 'أسهم'],
    rating: 4.8,
    duration: 120
  },
  {
    id: 'course_2',
    title: 'التحليل الفني المتقدم',
    type: 'course',
    category: 'technical_analysis',
    difficulty: 'advanced',
    tags: ['تحليل فني', 'مؤشرات', 'رسوم بيانية'],
    rating: 4.9,
    duration: 180
  },
  {
    id: 'course_3',
    title: 'إدارة المخاطر في التداول',
    type: 'course',
    category: 'risk_management',
    difficulty: 'intermediate',
    tags: ['مخاطر', 'إدارة', 'حماية رأس المال'],
    rating: 4.7,
    duration: 90
  },
  {
    id: 'video_1',
    title: 'كيف تقرأ الرسوم البيانية',
    type: 'video',
    category: 'technical_analysis',
    difficulty: 'beginner',
    tags: ['رسوم بيانية', 'شموع يابانية', 'تحليل'],
    rating: 4.6,
    duration: 15
  },
  {
    id: 'video_2',
    title: 'استراتيجيات التنويع في المحفظة',
    type: 'video',
    category: 'portfolio_management',
    difficulty: 'intermediate',
    tags: ['تنويع', 'محفظة', 'استثمار'],
    rating: 4.5,
    duration: 20
  },
  {
    id: 'article_1',
    title: 'علم النفس في التداول',
    type: 'article',
    category: 'psychology',
    difficulty: 'beginner',
    tags: ['نفسية', 'عواطف', 'انضباط'],
    rating: 4.8,
    duration: 10
  },
  {
    id: 'article_2',
    title: 'فهم السوق الصاعد والهابط',
    type: 'article',
    category: 'market_analysis',
    difficulty: 'beginner',
    tags: ['سوق', 'اتجاهات', 'تحليل'],
    rating: 4.7,
    duration: 8
  },
  {
    id: 'quiz_1',
    title: 'اختبار أساسيات التداول',
    type: 'quiz',
    category: 'trading',
    difficulty: 'beginner',
    tags: ['اختبار', 'تقييم', 'أساسيات'],
    rating: 4.5,
    duration: 15
  },
  {
    id: 'course_4',
    title: 'الاستثمار العقاري الذكي',
    type: 'course',
    category: 'real_estate',
    difficulty: 'intermediate',
    tags: ['عقارات', 'استثمار', 'عائد'],
    rating: 4.6,
    duration: 150
  },
  {
    id: 'video_3',
    title: 'أخطاء المتداولين المبتدئين',
    type: 'video',
    category: 'trading',
    difficulty: 'beginner',
    tags: ['أخطاء', 'نصائح', 'تداول'],
    rating: 4.9,
    duration: 12
  }
];

// Get user activity
async function getUserActivity(userId: string): Promise<UserActivity> {
  const activityKey = `activity:${userId}`;
  const activityStr = await kv.get(activityKey);
  
  if (activityStr) {
    return JSON.parse(activityStr);
  }
  
  return {
    userId,
    completedCourses: [],
    watchedVideos: [],
    practiceScores: {},
    timeSpent: {},
    interests: []
  };
}

// Calculate similarity score between user and content
function calculateSimilarity(
  userActivity: UserActivity,
  content: ContentItem,
  userComplexity: 'beginner' | 'intermediate' | 'advanced'
): number {
  let score = 0;
  
  // Difficulty match (30% weight)
  if (content.difficulty === userComplexity) {
    score += 30;
  } else if (
    (userComplexity === 'intermediate' && content.difficulty === 'beginner') ||
    (userComplexity === 'advanced' && content.difficulty === 'intermediate')
  ) {
    score += 15; // Related difficulty
  }
  
  // Category interest (40% weight)
  const categoryTime = userActivity.timeSpent[content.category] || 0;
  const totalTime = Object.values(userActivity.timeSpent).reduce((a, b) => a + b, 0) || 1;
  const categoryInterest = (categoryTime / totalTime) * 40;
  score += categoryInterest;
  
  // Tag matching (20% weight)
  const matchingTags = content.tags.filter(tag => 
    userActivity.interests.some(interest => 
      tag.includes(interest) || interest.includes(tag)
    )
  ).length;
  score += (matchingTags / content.tags.length) * 20;
  
  // Rating (10% weight)
  score += (content.rating / 5) * 10;
  
  // Penalty for already completed
  if (userActivity.completedCourses.includes(content.id)) {
    score *= 0.1;
  }
  
  return score;
}

// Generate recommendations
export async function generateRecommendations(
  userId: string,
  limit: number = 5
): Promise<{
  recommendations: ContentItem[];
  reasons: string[];
}> {
  try {
    // Get user data
    const activity = await getUserActivity(userId);
    const profileKey = `ai_profile:${userId}`;
    const profileStr = await kv.get(profileKey);
    const profile = profileStr ? JSON.parse(profileStr) : { complexity: 'beginner' };
    
    // Calculate scores for all content
    const scoredContent = contentLibrary.map(content => ({
      content,
      score: calculateSimilarity(activity, content, profile.complexity)
    }));
    
    // Sort by score and get top recommendations
    const recommendations = scoredContent
      .sort((a, b) => b.score - a.score)
      .slice(0, limit)
      .map(item => item.content);
    
    // Generate reasons
    const reasons = recommendations.map(rec => {
      const reasonParts: string[] = [];
      
      if (rec.difficulty === profile.complexity) {
        reasonParts.push('مناسب لمستواك');
      }
      
      if (activity.timeSpent[rec.category]) {
        reasonParts.push('بناءً على اهتمامك بـ' + rec.category);
      }
      
      if (rec.rating >= 4.7) {
        reasonParts.push('تقييم ممتاز');
      }
      
      return reasonParts.join(' • ');
    });
    
    return {
      recommendations,
      reasons
    };
  } catch (error) {
    console.error('Error generating recommendations:', error);
    return {
      recommendations: contentLibrary.slice(0, limit),
      reasons: []
    };
  }
}

// Track user activity
export async function trackActivity(
  userId: string,
  activityType: 'complete_course' | 'watch_video' | 'read_article' | 'take_quiz',
  contentId: string,
  category: string,
  timeSpent: number
): Promise<void> {
  const activity = await getUserActivity(userId);
  
  // Update based on activity type
  if (activityType === 'complete_course') {
    if (!activity.completedCourses.includes(contentId)) {
      activity.completedCourses.push(contentId);
    }
  } else if (activityType === 'watch_video') {
    if (!activity.watchedVideos.includes(contentId)) {
      activity.watchedVideos.push(contentId);
    }
  }
  
  // Update time spent
  activity.timeSpent[category] = (activity.timeSpent[category] || 0) + timeSpent;
  
  // Update interests (top 5 categories)
  const sortedCategories = Object.entries(activity.timeSpent)
    .sort(([, a], [, b]) => b - a)
    .slice(0, 5)
    .map(([cat]) => cat);
  
  activity.interests = sortedCategories;
  
  // Save
  const activityKey = `activity:${userId}`;
  await kv.set(activityKey, JSON.stringify(activity));
}

// Get personalized learning path
export async function getLearningPath(
  userId: string,
  goal: 'trading' | 'investing' | 'risk_management' | 'technical_analysis'
): Promise<{
  path: ContentItem[];
  estimatedDuration: number;
  description: string;
}> {
  const profileKey = `ai_profile:${userId}`;
  const profileStr = await kv.get(profileKey);
  const profile = profileStr ? JSON.parse(profileStr) : { complexity: 'beginner' };
  
  // Define learning paths
  const paths: Record<string, ContentItem[]> = {
    trading: contentLibrary.filter(c => 
      c.category === 'trading' && 
      (c.difficulty === profile.complexity || c.difficulty === 'beginner')
    ),
    investing: contentLibrary.filter(c => 
      ['portfolio_management', 'real_estate', 'market_analysis'].includes(c.category)
    ),
    risk_management: contentLibrary.filter(c => 
      c.category === 'risk_management' || c.tags.includes('مخاطر')
    ),
    technical_analysis: contentLibrary.filter(c => 
      c.category === 'technical_analysis'
    )
  };
  
  const path = paths[goal] || [];
  const estimatedDuration = path.reduce((sum, item) => sum + item.duration, 0);
  
  const descriptions: Record<string, string> = {
    trading: 'مسار تعليمي شامل لإتقان فنون التداول في الأسواق المالية',
    investing: 'تعلم بناء محفظة استثمارية متنوعة وناجحة',
    risk_management: 'إتقان فن حماية رأس المال وإدارة المخاطر',
    technical_analysis: 'تعلم قراءة الرسوم البيانية واتخاذ قرارات مبنية على التحليل'
  };
  
  return {
    path,
    estimatedDuration,
    description: descriptions[goal] || 'مسار تعليمي مخصص'
  };
}

// Get trending content
export async function getTrendingContent(limit: number = 5): Promise<ContentItem[]> {
  // In a real system, this would track view counts
  // For now, return highest rated content
  return contentLibrary
    .sort((a, b) => b.rating - a.rating)
    .slice(0, limit);
}

// Search content
export async function searchContent(
  query: string,
  filters?: {
    type?: string;
    difficulty?: string;
    category?: string;
  }
): Promise<ContentItem[]> {
  const q = query.toLowerCase();
  
  let results = contentLibrary.filter(content => {
    // Text search
    const matchesQuery = 
      content.title.toLowerCase().includes(q) ||
      content.tags.some(tag => tag.includes(q)) ||
      content.category.includes(q);
    
    if (!matchesQuery) return false;
    
    // Apply filters
    if (filters?.type && content.type !== filters.type) return false;
    if (filters?.difficulty && content.difficulty !== filters.difficulty) return false;
    if (filters?.category && content.category !== filters.category) return false;
    
    return true;
  });
  
  return results;
}
