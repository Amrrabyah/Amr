import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ParticleBackground } from './components/ParticleBackground';
import { Navigation } from './components/Navigation';
import { GoldProgressBar } from './components/GoldProgressBar';
import { ThreeDCard } from './components/ThreeDCard';
import { EnhancedTradingSimulator } from './components/EnhancedTradingSimulator';
import { DecisionScenarioGame } from './components/DecisionScenarioGame';
import { ProfileSection } from './components/ProfileSection';
import { LibrarySection } from './components/LibrarySection';
import { LeaderboardSection } from './components/LeaderboardSection';
import { AITutorWidget } from './components/AITutorWidget';
import { Sparkles, TrendingUp, Target, Zap, X } from 'lucide-react';

const cardData = [
  {
    id: 1,
    title: 'أساسيات التداول',
    description: 'ابدأ رحلتك في عالم الأسواق المالية',
    progress: 65,
    icon: 'trending' as const,
    color: '#00D4FF',
  },
  {
    id: 2,
    title: 'المكتبة التعليمية',
    description: 'أكثر من 100 درس ودورة تدريبية',
    progress: 40,
    icon: 'book' as const,
    color: '#FF6B6B',
  },
  {
    id: 3,
    title: 'الإنجازات',
    description: 'احصل على شارات وكافآت حصرية',
    progress: 80,
    icon: 'award' as const,
    color: '#FFD700',
  },
  {
    id: 4,
    title: 'التحديات اليومية',
    description: 'اختبر مهاراتك وزد نقاطك',
    progress: 55,
    icon: 'target' as const,
    color: '#4ECDC4',
  },
];

export default function App() {
  const [currentSection, setCurrentSection] = useState('home');
  const [xp, setXp] = useState(18750);
  const [isAIOpen, setIsAIOpen] = useState(false);

  return (
    <div className="min-h-screen relative overflow-x-hidden">
      {/* Particle Background */}
      <ParticleBackground />

      {/* Navigation */}
      <Navigation
        currentSection={currentSection}
        onSectionChange={setCurrentSection}
      />

      {/* Main Content */}
      <div className="relative z-10 pt-32 px-8 pb-16">
        <div className="max-w-7xl mx-auto">
          <AnimatePresence mode="wait">
            {currentSection === 'home' && (
              <motion.div
                key="home"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.5 }}
                className="space-y-12"
              >
                {/* Hero Section */}
                <motion.div
                  className="text-center mb-16"
                  initial={{ scale: 0.9, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ delay: 0.2 }}
                >
                  <motion.div
                    className="inline-block mb-6"
                    animate={{ rotate: [0, 10, -10, 0] }}
                    transition={{ duration: 3, repeat: Infinity }}
                  >
                    <Sparkles className="w-20 h-20 text-[#FFD700]" />
                  </motion.div>
                  <h1 className="text-[#FFD700] mb-4">
                    مرحباً في أكاديمية الذهب المالية
                  </h1>
                  <p className="text-xl opacity-80 max-w-2xl mx-auto">
                    منصة تعليمية فاخرة لإتقان فنون الاستثمار والتداول في الأسواق المالية
                  </p>

                  {/* Floating decorative elements */}
                  {[
                    { emoji: '💰', delay: 0 },
                    { emoji: '📈', delay: 1 },
                    { emoji: '🏆', delay: 2 },
                    { emoji: '⭐', delay: 3 },
                  ].map((item, i) => (
                    <motion.div
                      key={i}
                      className="absolute text-4xl"
                      style={{
                        left: `${20 + i * 20}%`,
                        top: `${10 + (i % 2) * 10}%`,
                      }}
                      animate={{
                        y: [0, -20, 0],
                        rotate: [0, 10, -10, 0],
                        scale: [1, 1.2, 1],
                      }}
                      transition={{
                        duration: 3,
                        repeat: Infinity,
                        delay: item.delay,
                      }}
                    >
                      {item.emoji}
                    </motion.div>
                  ))}
                </motion.div>

                {/* Progress Bar */}
                <motion.div
                  initial={{ y: 50, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: 0.3 }}
                >
                  <GoldProgressBar progress={75} level={25} xp={xp} maxXp={25000} />
                </motion.div>

                {/* 3D Cards Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  {cardData.map((card, index) => (
                    <motion.div
                      key={card.id}
                      initial={{ opacity: 0, y: 50 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.4 + index * 0.1 }}
                    >
                      <ThreeDCard card={card} />
                    </motion.div>
                  ))}
                </div>

                {/* Quick Stats */}
                <motion.div
                  className="grid grid-cols-1 md:grid-cols-4 gap-6"
                  initial={{ y: 50, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: 0.8 }}
                >
                  {[
                    { label: 'دروس مكتملة', value: '42', icon: '📚', color: '#00D4FF' },
                    { label: 'صفقات ناجحة', value: '156', icon: '💹', color: '#00FF00' },
                    { label: 'شارات محققة', value: '28', icon: '🏆', color: '#FFD700' },
                    { label: 'أيام متتالية', value: '15', icon: '🔥', color: '#FF6B6B' },
                  ].map((stat, index) => (
                    <motion.div
                      key={index}
                      className="glass-gold rounded-2xl p-6 text-center relative overflow-hidden"
                      whileHover={{ scale: 1.05, y: -5 }}
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      transition={{ delay: 0.9 + index * 0.1, type: 'spring' }}
                    >
                      <motion.div
                        className="absolute inset-0 opacity-10"
                        style={{ backgroundColor: stat.color }}
                        animate={{
                          scale: [1, 1.2, 1],
                          opacity: [0.1, 0.2, 0.1],
                        }}
                        transition={{ duration: 2, repeat: Infinity }}
                      />
                      <div className="relative z-10">
                        <motion.div
                          className="text-5xl mb-3"
                          animate={{ rotate: [0, 10, -10, 0] }}
                          transition={{ duration: 2, repeat: Infinity, delay: index * 0.2 }}
                        >
                          {stat.icon}
                        </motion.div>
                        <div className="text-3xl font-bold mb-2" style={{ color: stat.color }}>
                          {stat.value}
                        </div>
                        <div className="text-sm opacity-70">{stat.label}</div>
                      </div>
                    </motion.div>
                  ))}
                </motion.div>

                {/* Call to Action */}
                <motion.div
                  className="glass-gold rounded-3xl p-12 text-center relative overflow-hidden"
                  initial={{ scale: 0.9, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ delay: 1.2 }}
                  whileHover={{ scale: 1.02 }}
                >
                  <motion.div
                    className="absolute inset-0"
                    style={{
                      background:
                        'radial-gradient(circle at 50% 50%, rgba(255,215,0,0.2), transparent)',
                    }}
                    animate={{
                      scale: [1, 1.5, 1],
                      opacity: [0.3, 0.5, 0.3],
                    }}
                    transition={{ duration: 3, repeat: Infinity }}
                  />
                  <div className="relative z-10">
                    <h2 className="text-[#FFD700] mb-4">
                      ابدأ رحلتك نحو الحرية المالية
                    </h2>
                    <p className="text-lg opacity-80 mb-8 max-w-2xl mx-auto">
                      انضم إلى آلاف المتعلمين الذين حققوا أهدافهم المالية من خلال منصتنا
                    </p>
                    <motion.button
                      className="glass rounded-2xl px-12 py-4 text-lg font-bold text-[#FFD700] relative overflow-hidden group"
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      onClick={() => setCurrentSection('trading')}
                    >
                      <motion.div
                        className="absolute inset-0 bg-[#FFD700]"
                        initial={{ scale: 0, opacity: 0 }}
                        whileHover={{ scale: 1, opacity: 0.2 }}
                        transition={{ duration: 0.3 }}
                      />
                      <span className="relative z-10 flex items-center gap-3">
                        <TrendingUp className="w-6 h-6" />
                        ابدأ المحاكاة الآن
                      </span>
                    </motion.button>
                  </div>
                </motion.div>
              </motion.div>
            )}

            {currentSection === 'trading' && (
              <motion.div
                key="trading"
                initial={{ opacity: 0, x: 100 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -100 }}
                transition={{ duration: 0.5 }}
              >
                <div className="mb-8">
                  <h2 className="text-[#FFD700] mb-2">محاكاة التداول المالي</h2>
                  <p className="opacity-80">
                    اختبر مهاراتك في بيئة تداول واقعية بدون مخاطر
                  </p>
                </div>
                <EnhancedTradingSimulator />
                
                {/* Decision Scenarios */}
                <div className="mt-12">
                  <h2 className="text-[#FFD700] mb-4">تمارين القرارات التجارية</h2>
                  <p className="opacity-80 mb-8">
                    اختبر قدرتك على اتخاذ القرارات الصحيحة في سيناريوهات حقيقية
                  </p>
                  <DecisionScenarioGame />
                </div>
              </motion.div>
            )}

            {currentSection === 'library' && (
              <motion.div
                key="library"
                initial={{ opacity: 0, x: 100 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -100 }}
                transition={{ duration: 0.5 }}
              >
                <div className="mb-8">
                  <h2 className="text-[#FFD700] mb-2">المكتبة التعليمية</h2>
                  <p className="opacity-80">
                    استكشف مجموعة واسعة من الدورات والمقالات والفيديوهات
                  </p>
                </div>
                <LibrarySection />
              </motion.div>
            )}

            {currentSection === 'profile' && (
              <motion.div
                key="profile"
                initial={{ opacity: 0, x: 100 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -100 }}
                transition={{ duration: 0.5 }}
              >
                <div className="mb-8">
                  <h2 className="text-[#FFD700] mb-2">الملف الشخصي</h2>
                  <p className="opacity-80">
                    تابع تقدمك وإنجازاتك ومهاراتك المكتسبة
                  </p>
                </div>
                <ProfileSection />
              </motion.div>
            )}

            {currentSection === 'leaderboard' && (
              <motion.div
                key="leaderboard"
                initial={{ opacity: 0, x: 100 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -100 }}
                transition={{ duration: 0.5 }}
              >
                <div className="mb-8">
                  <h2 className="text-[#FFD700] mb-2">لوحة المتصدرين</h2>
                  <p className="opacity-80">
                    تنافس مع أفضل المتعلمين وحقق المركز الأول
                  </p>
                </div>
                <LeaderboardSection />
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* AI Assistant - Floating crystal */}
      <motion.div
        className="fixed bottom-8 left-8 z-50"
        initial={{ scale: 0, rotate: -180 }}
        animate={{ scale: 1, rotate: 0 }}
        transition={{ delay: 1, type: 'spring' }}
      >
        <motion.button
          className="glass-gold rounded-2xl p-4 relative overflow-hidden group"
          whileHover={{ scale: 1.1, rotate: 5 }}
          whileTap={{ scale: 0.9 }}
          onClick={() => setIsAIOpen(!isAIOpen)}
          animate={{
            y: [0, -10, 0],
            boxShadow: [
              '0 0 20px rgba(255,215,0,0.3)',
              '0 0 40px rgba(255,215,0,0.6)',
              '0 0 20px rgba(255,215,0,0.3)',
            ],
          }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          <motion.div
            className="absolute inset-0 bg-[#FFD700]"
            animate={{ rotate: [0, 360] }}
            transition={{ duration: 10, repeat: Infinity, ease: 'linear' }}
            style={{ opacity: 0.1 }}
          />
          <div className="relative z-10 flex items-center gap-3">
            <Zap className="w-6 h-6 text-[#FFD700]" />
            <span className="font-bold">المساعد الذكي</span>
          </div>
        </motion.button>

        {/* Pulse rings */}
        {[0, 1, 2].map((i) => (
          <motion.div
            key={i}
            className="absolute inset-0 border-2 border-[#FFD700] rounded-2xl pointer-events-none"
            animate={{
              scale: [1, 2, 2],
              opacity: [0.5, 0.3, 0],
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              delay: i * 0.6,
            }}
          />
        ))}
      </motion.div>

      {/* AI Tutor Widget (Floating Panel) */}
      <AnimatePresence>
        {isAIOpen && (
          <motion.div
            className="fixed bottom-28 left-8 z-50 w-96 h-[600px] glass-gold rounded-3xl shadow-2xl overflow-hidden"
            initial={{ scale: 0, opacity: 0, y: 100 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0, opacity: 0, y: 100 }}
            transition={{ type: 'spring', duration: 0.5 }}
          >
            <div className="absolute top-4 left-4 z-10">
              <motion.button
                className="glass rounded-full p-2"
                onClick={() => setIsAIOpen(false)}
                whileHover={{ scale: 1.1, rotate: 90 }}
                whileTap={{ scale: 0.9 }}
              >
                <X className="w-5 h-5 text-[#FFD700]" />
              </motion.button>
            </div>
            <AITutorWidget />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}